/**
 * controllers/attachmentController.js
 * -----------------------------------------------------------------------
 * Policy File Attachments (NEW REQUIREMENT #5).
 * One attachment slot per policy - uploading again for the same policy
 * replaces the existing file (both the DB row via upsert and the old
 * physical file on disk, removed best-effort after the DB write
 * succeeds).
 *
 * Routes (see routes/policyRoutes.js):
 *   POST   /api/policies/:id/attachment        upload or replace
 *   GET    /api/policies/:id/attachment         metadata (file_name, uploaded_at, ...)
 *   GET    /api/policies/:id/attachment/file    raw file bytes (view/download)
 *   DELETE /api/policies/:id/attachment         delete
 * -----------------------------------------------------------------------
 */

const fs = require('fs');
const path = require('path');
const db = require('../db');
const { UPLOAD_DIR } = require('../middleware/upload');

/**
 * POST /api/policies/:id/attachment
 * multer (uploadPolicyAttachment.single('file')) must run before this,
 * so req.file is already written to disk by the time we get here.
 */
const uploadAttachment = async (req, res) => {
  try {
    const policyId = req.params.id;

    if (!req.file) {
      return res.status(400).json({
        success: false,
        message: 'กรุณาเลือกไฟล์ที่ต้องการอัปโหลด (PDF, รูปภาพ, หรือ DOCX)'
      });
    }

    // Look up any existing attachment so we can remove the old physical
    // file after the new one is safely recorded in the database.
    const existing = await db.query(
      'SELECT file_path FROM policy_attachment WHERE policy_id = $1',
      [policyId]
    );

    const result = await db.query(
      `INSERT INTO policy_attachment (policy_id, file_name, file_path, mime_type, file_size)
       VALUES ($1, $2, $3, $4, $5)
       ON CONFLICT (policy_id) DO UPDATE SET
         file_name = EXCLUDED.file_name,
         file_path = EXCLUDED.file_path,
         mime_type = EXCLUDED.mime_type,
         file_size = EXCLUDED.file_size,
         uploaded_at = NOW()
       RETURNING attachment_id, policy_id, file_name, mime_type, file_size, uploaded_at`,
      [policyId, req.file.originalname, req.file.filename, req.file.mimetype, req.file.size]
    );

    // Best-effort cleanup of the previous file - never block the
    // response on this, a stray orphaned file is not worth failing
    // the request that already succeeded.
    if (existing.rows.length > 0 && existing.rows[0].file_path !== req.file.filename) {
      const oldPath = path.join(UPLOAD_DIR, existing.rows[0].file_path);
      fs.unlink(oldPath, (err) => {
        if (err && err.code !== 'ENOENT') {
          console.error('[attachmentController.uploadAttachment] Failed to remove old file:', err.message);
        }
      });
    }

    return res.status(existing.rows.length > 0 ? 200 : 201).json({
      success: true,
      message: existing.rows.length > 0 ? 'แทนที่ไฟล์แนบเรียบร้อยแล้ว' : 'อัปโหลดไฟล์แนบเรียบร้อยแล้ว',
      data: result.rows[0]
    });
  } catch (error) {
    // If the DB write failed after multer already wrote the file to
    // disk, remove the orphaned upload so it doesn't linger forever.
    if (req.file) {
      fs.unlink(path.join(UPLOAD_DIR, req.file.filename), () => {});
    }
    console.error('[attachmentController.uploadAttachment] Error:', error.message);
    return res.status(500).json({
      success: false,
      message: 'Internal server error while uploading the attachment.'
    });
  }
};

/**
 * GET /api/policies/:id/attachment
 * Metadata only. Returns data: null (not a 404) when the policy simply
 * has no attachment yet - that's a normal state, not an error.
 */
const getAttachmentInfo = async (req, res) => {
  try {
    const policyId = req.params.id;

    const result = await db.query(
      `SELECT attachment_id, policy_id, file_name, mime_type, file_size, uploaded_at
       FROM policy_attachment WHERE policy_id = $1`,
      [policyId]
    );

    return res.status(200).json({
      success: true,
      data: result.rows[0] || null
    });
  } catch (error) {
    console.error('[attachmentController.getAttachmentInfo] Error:', error.message);
    return res.status(500).json({
      success: false,
      message: 'Internal server error while fetching attachment info.'
    });
  }
};

/**
 * GET /api/policies/:id/attachment/file
 * Streams the raw file. The frontend decides "view" (open the returned
 * blob in a new tab) vs "download" (force-save via an anchor's download
 * attribute) - both hit this same endpoint.
 */
const getAttachmentFile = async (req, res) => {
  try {
    const policyId = req.params.id;

    const result = await db.query(
      'SELECT file_name, file_path, mime_type FROM policy_attachment WHERE policy_id = $1',
      [policyId]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({
        success: false,
        message: 'ไม่พบไฟล์แนบสำหรับกรมธรรม์นี้'
      });
    }

    const attachment = result.rows[0];
    const absolutePath = path.join(UPLOAD_DIR, attachment.file_path);

    if (!fs.existsSync(absolutePath)) {
      return res.status(404).json({
        success: false,
        message: 'ไม่พบไฟล์บนเซิร์ฟเวอร์ (อาจถูกลบไปแล้ว)'
      });
    }

    res.setHeader('Content-Type', attachment.mime_type || 'application/octet-stream');
    return res.sendFile(absolutePath);
  } catch (error) {
    console.error('[attachmentController.getAttachmentFile] Error:', error.message);
    return res.status(500).json({
      success: false,
      message: 'Internal server error while retrieving the attachment file.'
    });
  }
};

/**
 * DELETE /api/policies/:id/attachment
 */
const deleteAttachment = async (req, res) => {
  try {
    const policyId = req.params.id;

    const result = await db.query(
      'DELETE FROM policy_attachment WHERE policy_id = $1 RETURNING file_path',
      [policyId]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({
        success: false,
        message: 'ไม่พบไฟล์แนบสำหรับกรมธรรม์นี้'
      });
    }

    const filePath = path.join(UPLOAD_DIR, result.rows[0].file_path);
    fs.unlink(filePath, (err) => {
      if (err && err.code !== 'ENOENT') {
        console.error('[attachmentController.deleteAttachment] Failed to remove file:', err.message);
      }
    });

    return res.status(200).json({
      success: true,
      message: 'ลบไฟล์แนบเรียบร้อยแล้ว'
    });
  } catch (error) {
    console.error('[attachmentController.deleteAttachment] Error:', error.message);
    return res.status(500).json({
      success: false,
      message: 'Internal server error while deleting the attachment.'
    });
  }
};

module.exports = {
  uploadAttachment,
  getAttachmentInfo,
  getAttachmentFile,
  deleteAttachment
};
