/**
 * controllers/vehicleController.js
 * -----------------------------------------------------------------------
 * Vehicle management. Ownership follows the parent customer's agent_id:
 *  - Admin: full access
 *  - Agent: only for vehicles belonging to customers they own
 * -----------------------------------------------------------------------
 */

const db = require('../db');

/**
 * POST /api/vehicles
 * Body must include customer_id. Ownership is checked inline here since
 * there is no :id route param yet at creation time.
 */
const createVehicle = async (req, res) => {
  try {
    const {
      customer_id, license_plate, plate_province, brand, model,
      production_year, color, chassis_no, engine_no
    } = req.body;

    if (!customer_id || !license_plate || !plate_province || !brand || !model) {
      return res.status(400).json({
        success: false,
        message: 'customer_id, license_plate, plate_province, brand, and model are required.'
      });
    }

    const customerResult = await db.query(
      'SELECT customer_id, agent_id FROM customer WHERE customer_id = $1',
      [customer_id]
    );

    if (customerResult.rows.length === 0) {
      return res.status(404).json({
        success: false,
        message: 'Customer not found.'
      });
    }

    const customer = customerResult.rows[0];
    const isAdmin = req.user.role === 'Admin';
    const isOwner = customer.agent_id === req.user.agent_id;

    if (!isAdmin && !isOwner) {
      return res.status(403).json({
        success: false,
        message: 'Forbidden: You can only add vehicles to customers you own.'
      });
    }

    const result = await db.query(
      `INSERT INTO vehicle
        (customer_id, license_plate, plate_province, brand, model, production_year, color, chassis_no, engine_no)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
       RETURNING *`,
      [
        customer_id, license_plate, plate_province, brand, model,
        production_year || null, color || null, chassis_no || null, engine_no || null
      ]
    );

    return res.status(201).json({
      success: true,
      message: 'Vehicle added successfully.',
      data: result.rows[0]
    });
  } catch (error) {
    console.error('[vehicleController.createVehicle] Error:', error.message);
    return res.status(500).json({
      success: false,
      message: 'Internal server error while adding vehicle.'
    });
  }
};

/**
 * PUT /api/vehicles/:id
 * Protected by verifyToken + checkVehicleOwnerOrAdmin.
 */
const updateVehicle = async (req, res) => {
  try {
    const { id } = req.params;
    const {
      license_plate, plate_province, brand, model,
      production_year, color, chassis_no, engine_no
    } = req.body;

    const fields = [];
    const values = [];
    let paramIndex = 1;

    const addField = (column, value) => {
      fields.push(`${column} = $${paramIndex}`);
      values.push(value);
      paramIndex += 1;
    };

    if (license_plate !== undefined) addField('license_plate', license_plate);
    if (plate_province !== undefined) addField('plate_province', plate_province);
    if (brand !== undefined) addField('brand', brand);
    if (model !== undefined) addField('model', model);
    if (production_year !== undefined) addField('production_year', production_year);
    if (color !== undefined) addField('color', color);
    if (chassis_no !== undefined) addField('chassis_no', chassis_no);
    if (engine_no !== undefined) addField('engine_no', engine_no);

    if (fields.length === 0) {
      return res.status(400).json({
        success: false,
        message: 'No valid fields provided for update.'
      });
    }

    values.push(id);

    const result = await db.query(
      `UPDATE vehicle SET ${fields.join(', ')} WHERE vehicle_id = $${paramIndex} RETURNING *`,
      values
    );

    if (result.rows.length === 0) {
      return res.status(404).json({
        success: false,
        message: 'Vehicle not found.'
      });
    }

    return res.status(200).json({
      success: true,
      message: 'Vehicle updated successfully.',
      data: result.rows[0]
    });
  } catch (error) {
    console.error('[vehicleController.updateVehicle] Error:', error.message);
    return res.status(500).json({
      success: false,
      message: 'Internal server error while updating vehicle.'
    });
  }
};

/**
 * DELETE /api/vehicles/:id
 * Protected by verifyToken + checkVehicleOwnerOrAdmin.
 * Cascades to delete related policies (ON DELETE CASCADE in schema).
 */
const deleteVehicle = async (req, res) => {
  try {
    const { id } = req.params;

    const result = await db.query(
      'DELETE FROM vehicle WHERE vehicle_id = $1 RETURNING vehicle_id',
      [id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({
        success: false,
        message: 'Vehicle not found.'
      });
    }

    return res.status(200).json({
      success: true,
      message: 'Vehicle and its associated policies were deleted successfully.'
    });
  } catch (error) {
    console.error('[vehicleController.deleteVehicle] Error:', error.message);
    return res.status(500).json({
      success: false,
      message: 'Internal server error while deleting vehicle.'
    });
  }
};

module.exports = {
  createVehicle,
  updateVehicle,
  deleteVehicle
};
