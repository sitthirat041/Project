/**
 * controllers/dashboardController.js
 * -----------------------------------------------------------------------
 * Sales Dashboard (#9), Reminder System (#10) and summary stats.
 *
 * VISIBILITY RULES
 *  - Sales are returned as two views:
 *      personal : only the caller's own sales (agent_id = caller)
 *      team     : everyone's sales, visible to ALL authenticated users
 *                 (aggregate figures + per-agent ranking, no record details)
 *  - Commission is sensitive: Agents only see commission for their own
 *    sales. In the team view, commission is null for other agents'
 *    rows / totals unless the caller is Admin.
 *  - Reminders and stat cards are scoped: Admin sees everything and an
 *    owner column; an Agent sees only their own records.
 *
 * COMMISSION
 *  Commission = premium * commission_rate, using the rate snapshotted on
 *  the policy when it was sold (migration 008). COALESCE falls back to
 *  the company's current rate for any row that has no snapshot.
 *
 * Sales figures combine Motor (policy) and Non-Motor (non_motor_policy)
 * via UNION, using start/coverage-start date as the "sale date".
 * Renewal tracking only exists on Motor policies, so renewal_count is
 * always 0 for Non-Motor - documented limitation.
 * -----------------------------------------------------------------------
 */

const db = require('../db');
const { agentScope } = require('../middleware/access');

const COMBINED_SALES_QUERY = `
  SELECT
    'Motor' AS category, p.premium, p.company_id, co1.company_name,
    COALESCE(p.commission_rate, co1.commission_rate) AS commission_rate,
    c.agent_id, ag1.first_name AS agent_first_name, ag1.last_name AS agent_last_name,
    p.start_date AS sale_date, p.renewal_status, p.status
  FROM policy p
  INNER JOIN vehicle v ON p.vehicle_id = v.vehicle_id
  INNER JOIN customer c ON v.customer_id = c.customer_id
  LEFT JOIN company co1 ON p.company_id = co1.company_id
  LEFT JOIN agent ag1 ON c.agent_id = ag1.agent_id
  WHERE p.start_date IS NOT NULL AND EXTRACT(YEAR FROM p.start_date) = $1

  UNION ALL

  SELECT
    'Non-Motor' AS category, nm.premium, nm.company_id, co2.company_name,
    COALESCE(nm.commission_rate, co2.commission_rate) AS commission_rate,
    nm.agent_id, ag2.first_name AS agent_first_name, ag2.last_name AS agent_last_name,
    nm.coverage_start AS sale_date, NULL AS renewal_status, nm.status
  FROM non_motor_policy nm
  LEFT JOIN company co2 ON nm.company_id = co2.company_id
  LEFT JOIN agent ag2 ON nm.agent_id = ag2.agent_id
  WHERE nm.coverage_start IS NOT NULL AND EXTRACT(YEAR FROM nm.coverage_start) = $1
`;

function aggregate(rows, includeCommission = true) {
  const premium = rows.reduce((sum, r) => sum + Number(r.premium || 0), 0);
  const commission = rows.reduce((sum, r) => sum + (Number(r.premium || 0) * Number(r.commission_rate || 0)), 0);
  return {
    premium: Math.round(premium * 100) / 100,
    commission: includeCommission ? Math.round(commission * 100) / 100 : null,
    policy_count: rows.length,
    renewal_count: rows.filter((r) => r.renewal_status === 'Renewed').length
  };
}

/**
 * Groups rows and aggregates each group. `commissionAllowed(key)` decides
 * per group whether commission may be shown to the caller.
 */
function topGroups(rows, keyFn, labelFn, limit, commissionAllowed = () => true) {
  const groups = new Map();
  rows.forEach((r) => {
    const key = keyFn(r);
    if (!key) return;
    if (!groups.has(key)) groups.set(key, { label: labelFn(r), rows: [] });
    groups.get(key).rows.push(r);
  });
  return Array.from(groups.entries())
    .map(([key, { label, rows: groupRows }]) => ({
      key, label, ...aggregate(groupRows, commissionAllowed(key))
    }))
    .sort((a, b) => b.premium - a.premium)
    .slice(0, limit);
}

/** Builds the full set of dashboard widgets for one slice of sales rows. */
function buildView({ yearRows, month, includeCommission, commissionAllowedForAgent, withAgents }) {
  const monthOf = (r) => (r.sale_date ? new Date(r.sale_date).getMonth() + 1 : null);
  const periodRows = month ? yearRows.filter((r) => monthOf(r) === month) : yearRows;

  const summary = {
    motor: aggregate(periodRows.filter((r) => r.category === 'Motor'), includeCommission),
    nonMotor: aggregate(periodRows.filter((r) => r.category === 'Non-Motor'), includeCommission),
    total: aggregate(periodRows, includeCommission)
  };

  const byCompany = topGroups(
    periodRows,
    (r) => r.company_id,
    (r) => r.company_name || 'ไม่ระบุบริษัท',
    10,
    () => includeCommission
  );

  const monthlyTrend = Array.from({ length: 12 }, (_, i) => {
    const m = i + 1;
    const agg = aggregate(yearRows.filter((r) => monthOf(r) === m), false);
    return { month: m, premium: agg.premium, policy_count: agg.policy_count };
  });

  const typeBreakdown = [
    { type: 'Motor', premium: summary.motor.premium, policy_count: summary.motor.policy_count },
    { type: 'Non-Motor', premium: summary.nonMotor.premium, policy_count: summary.nonMotor.policy_count }
  ];

  const view = { summary, byCompany, monthlyTrend, typeBreakdown };

  if (withAgents) {
    view.byAgent = topGroups(
      periodRows,
      (r) => r.agent_id,
      (r) => `${r.agent_first_name || ''} ${r.agent_last_name || ''}`.trim() || 'ไม่ระบุตัวแทน',
      10,
      commissionAllowedForAgent
    );
  }
  return view;
}

/**
 * GET /api/dashboard/sales?year=YYYY&month=1-12(optional)
 * Returns { personal, team } - see header for visibility rules.
 */
const getSalesDashboard = async (req, res) => {
  try {
    const year = parseInt(req.query.year, 10) || new Date().getFullYear();
    const month = req.query.month ? parseInt(req.query.month, 10) : null;

    if (month !== null && (month < 1 || month > 12)) {
      return res.status(400).json({ success: false, message: 'month must be between 1 and 12.' });
    }

    const result = await db.query(COMBINED_SALES_QUERY, [year]);
    const allRows = result.rows;
    const me = req.user.agent_id;
    const isAdmin = req.user.role === 'Admin';

    const personal = buildView({
      yearRows: allRows.filter((r) => r.agent_id === me),
      month,
      includeCommission: true,
      withAgents: false
    });

    const team = buildView({
      yearRows: allRows,
      month,
      // Team totals / per-company commission only for Admin.
      includeCommission: isAdmin,
      // Per-agent commission: Admin sees all, an Agent sees only their own row.
      commissionAllowedForAgent: (agentKey) => isAdmin || agentKey === me,
      withAgents: true
    });

    return res.status(200).json({
      success: true,
      data: {
        period: { year, month },
        viewer: { agent_id: me, role: req.user.role },
        personal,
        team
      }
    });
  } catch (error) {
    console.error('[dashboardController.getSalesDashboard] Error:', error.message);
    return res.status(500).json({
      success: false,
      message: 'Internal server error while building the sales dashboard.'
    });
  }
};

/**
 * GET /api/dashboard/reminders
 * Every Motor / พรบ. / Vehicle Tax / Non-Motor item expiring within 90
 * days. Admin sees all (with owner name); an Agent sees only their own.
 */
const getReminders = async (req, res) => {
  try {
    const scope = agentScope(req);
    const params = scope === null ? [] : [scope];
    const motorScope = scope === null ? '' : 'AND c.agent_id = $1';
    const nmScope = scope === null ? '' : 'AND nm.agent_id = $1';

    const [motor, compulsory, tax, nonMotor] = await Promise.all([
      db.query(`
        SELECT
          p.policy_id AS id, 'Motor' AS category, p.policy_number AS reference,
          p.end_date AS expiry_date, (p.end_date - CURRENT_DATE) AS days_remaining,
          c.customer_id, c.first_name AS customer_first_name, c.last_name AS customer_last_name,
          c.phone AS customer_phone, v.license_plate, co.company_name,
          c.agent_id, ag.first_name AS agent_first_name, ag.last_name AS agent_last_name
        FROM policy p
        INNER JOIN vehicle v ON p.vehicle_id = v.vehicle_id
        INNER JOIN customer c ON v.customer_id = c.customer_id
        LEFT JOIN agent ag ON c.agent_id = ag.agent_id
        LEFT JOIN company co ON p.company_id = co.company_id
        WHERE p.end_date BETWEEN CURRENT_DATE AND (CURRENT_DATE + INTERVAL '90 days')
          ${motorScope}
      `, params),
      db.query(`
        SELECT
          vc.compliance_id AS id, 'CompulsoryInsurance' AS category, NULL AS reference,
          vc.expiry_date, (vc.expiry_date - CURRENT_DATE) AS days_remaining,
          c.customer_id, c.first_name AS customer_first_name, c.last_name AS customer_last_name,
          c.phone AS customer_phone, v.license_plate, co.company_name,
          c.agent_id, ag.first_name AS agent_first_name, ag.last_name AS agent_last_name
        FROM vehicle_compliance vc
        INNER JOIN vehicle v ON vc.vehicle_id = v.vehicle_id
        INNER JOIN customer c ON v.customer_id = c.customer_id
        LEFT JOIN agent ag ON c.agent_id = ag.agent_id
        LEFT JOIN company co ON vc.company_id = co.company_id
        WHERE vc.compliance_type = 'CompulsoryInsurance'
          AND vc.expiry_date BETWEEN CURRENT_DATE AND (CURRENT_DATE + INTERVAL '90 days')
          ${motorScope}
      `, params),
      db.query(`
        SELECT
          vc.compliance_id AS id, 'VehicleTax' AS category, NULL AS reference,
          vc.expiry_date, (vc.expiry_date - CURRENT_DATE) AS days_remaining,
          c.customer_id, c.first_name AS customer_first_name, c.last_name AS customer_last_name,
          c.phone AS customer_phone, v.license_plate, co.company_name,
          c.agent_id, ag.first_name AS agent_first_name, ag.last_name AS agent_last_name
        FROM vehicle_compliance vc
        INNER JOIN vehicle v ON vc.vehicle_id = v.vehicle_id
        INNER JOIN customer c ON v.customer_id = c.customer_id
        LEFT JOIN agent ag ON c.agent_id = ag.agent_id
        LEFT JOIN company co ON vc.company_id = co.company_id
        WHERE vc.compliance_type = 'VehicleTax'
          AND vc.expiry_date BETWEEN CURRENT_DATE AND (CURRENT_DATE + INTERVAL '90 days')
          ${motorScope}
      `, params),
      db.query(`
        SELECT
          nm.non_motor_id AS id, 'NonMotor' AS category, nm.policy_number AS reference,
          nm.coverage_end AS expiry_date, (nm.coverage_end - CURRENT_DATE) AS days_remaining,
          NULL AS customer_id, nm.customer_name AS customer_name_direct,
          nm.phone AS customer_phone, NULL AS license_plate, co.company_name,
          nm.agent_id, ag.first_name AS agent_first_name, ag.last_name AS agent_last_name
        FROM non_motor_policy nm
        LEFT JOIN agent ag ON nm.agent_id = ag.agent_id
        LEFT JOIN company co ON nm.company_id = co.company_id
        WHERE nm.coverage_end BETWEEN CURRENT_DATE AND (CURRENT_DATE + INTERVAL '90 days')
          ${nmScope}
      `, params)
    ]);

    const normalize = (rows, hasNameParts) => rows.map((r) => ({
      id: r.id,
      category: r.category,
      reference: r.reference,
      expiry_date: r.expiry_date,
      days_remaining: r.days_remaining,
      customer_id: r.customer_id || null,
      customer_name: hasNameParts
        ? `${r.customer_first_name || ''} ${r.customer_last_name || ''}`.trim()
        : r.customer_name_direct,
      customer_phone: r.customer_phone,
      license_plate: r.license_plate,
      company_name: r.company_name,
      agent_id: r.agent_id,
      agent_name: `${r.agent_first_name || ''} ${r.agent_last_name || ''}`.trim() || '-'
    }));

    const items = [
      ...normalize(motor.rows, true),
      ...normalize(compulsory.rows, true),
      ...normalize(tax.rows, true),
      ...normalize(nonMotor.rows, false)
    ].sort((a, b) => a.days_remaining - b.days_remaining);

    return res.status(200).json({
      success: true,
      maxDays: 90,
      count: items.length,
      data: items
    });
  } catch (error) {
    console.error('[dashboardController.getReminders] Error:', error.message);
    return res.status(500).json({
      success: false,
      message: 'Internal server error while building reminders.'
    });
  }
};

/**
 * GET /api/dashboard/stats
 * Summary cards, scoped to the caller (Admin = everything).
 * "Expiring in 30 days" now counts Motor AND Non-Motor, matching how
 * "Active Policies" already counted both.
 */
const getDashboardStats = async (req, res) => {
  try {
    const scope = agentScope(req);
    const params = scope === null ? [] : [scope];

    const custScope = scope === null ? '' : 'WHERE c.agent_id = $1';
    const motorScope = scope === null ? '' : 'AND c.agent_id = $1';
    const nmScope = scope === null ? '' : 'AND nm.agent_id = $1';

    const motorFrom = `FROM policy p
      INNER JOIN vehicle v ON p.vehicle_id = v.vehicle_id
      INNER JOIN customer c ON v.customer_id = c.customer_id`;

    const result = await db.query(`
      SELECT
        (SELECT COUNT(*) FROM customer c ${custScope}) AS total_customers,
        (SELECT COUNT(*) ${motorFrom} WHERE p.status = 'Active' ${motorScope}) AS active_motor_policies,
        (SELECT COUNT(*) FROM non_motor_policy nm WHERE nm.status = 'Active' ${nmScope}) AS active_non_motor_policies,
        (SELECT COUNT(*) ${motorFrom}
           WHERE p.end_date BETWEEN CURRENT_DATE AND (CURRENT_DATE + INTERVAL '30 days') ${motorScope}) AS expiring_motor_30,
        (SELECT COUNT(*) FROM non_motor_policy nm
           WHERE nm.coverage_end BETWEEN CURRENT_DATE AND (CURRENT_DATE + INTERVAL '30 days') ${nmScope}) AS expiring_non_motor_30,
        (SELECT COUNT(*) ${motorFrom} WHERE p.renewal_status = 'Pending' ${motorScope}) AS pending_renewal
    `, params);

    const row = result.rows[0];
    const activeMotor = parseInt(row.active_motor_policies, 10);
    const activeNonMotor = parseInt(row.active_non_motor_policies, 10);

    return res.status(200).json({
      success: true,
      data: {
        total_customers: parseInt(row.total_customers, 10),
        active_motor_policies: activeMotor,
        active_non_motor_policies: activeNonMotor,
        active_policies: activeMotor + activeNonMotor,
        expiring_30_days: parseInt(row.expiring_motor_30, 10) + parseInt(row.expiring_non_motor_30, 10),
        pending_renewal: parseInt(row.pending_renewal, 10)
      }
    });
  } catch (error) {
    console.error('[dashboardController.getDashboardStats] Error:', error.message);
    return res.status(500).json({
      success: false,
      message: 'Internal server error while fetching dashboard stats.'
    });
  }
};

module.exports = { getSalesDashboard, getReminders, getDashboardStats };
