/**
 * controllers/complianceController.js
 * -----------------------------------------------------------------------
 * Compulsory Insurance (พรบ.) & Vehicle Tax (NEW REQUIREMENT #7).
 * Both share the same shape (Status, Start Date, Expiry Date, Reminder,
 * Company, Price, Notes) and are stored in one table discriminated by
 * compliance_type. Ownership follows vehicle -> customer -> agent_id,
 * same as policies.
 * -----------------------------------------------------------------------
 */

const db = require('../db');
const { agentScope } = require('../middleware/access');
const { isValidDateOrder, isNonNegativeNumberOrEmpty } = require('../utils/validators');

const VALID_TYPES = ['CompulsoryInsurance', 'VehicleTax'];

/**
 * GET /api/vehicles/:id/compliance
 * Lists every พรบ. / Vehicle Tax record for a vehicle (both types,
 * newest expiry first). Viewing is unrestricted for any authenticated
 * user, consistent with the rest of the app.
 */
const listComplianceForVehicle = async (req, res) => {
  try {
    const vehicleId = req.params.id;

    const result = await db.query(
      `SELECT
         vc.compliance_id, vc.vehicle_id, vc.compliance_type, vc.status,
         vc.start_date, vc.expiry_date, vc.reminder, vc.price, vc.notes,
         (vc.expiry_date - CURRENT_DATE) AS days_remaining,
         co.company_id, co.company_name
       FROM vehicle_compliance vc
       LEFT JOIN company co ON vc.company_id = co.company_id
       WHERE vc.vehicle_id = $1
       ORDER BY vc.expiry_date DESC`,
      [vehicleId]
    );

    return res.status(200).json({ success: true, data: result.rows });
  } catch (error) {
    console.error('[complianceController.listComplianceForVehicle] Error:', error.message);
    return res.status(500).json({
      success: false,
      message: 'Internal server error while fetching compliance records.'
    });
  }
};

/**
 * POST /api/compliance
 * Body must include vehicle_id + compliance_type. Ownership is checked
 * inline here since there is no :id route param yet at creation time.
 */
const createCompliance = async (req, res) => {
  try {
    const {
      vehicle_id, compliance_type, status, start_date, expiry_date,
      reminder, company_id, price, notes
    } = req.body;

    if (!vehicle_id || !compliance_type || !expiry_date) {
      return res.status(400).json({
        success: false,
        message: 'vehicle_id, compliance_type, and expiry_date are required.'
      });
    }

    if (!VALID_TYPES.includes(compliance_type)) {
      return res.status(400).json({
        success: false,
        message: `compliance_type must be one of: ${VALID_TYPES.join(', ')}`
      });
    }

    if (!isValidDateOrder(start_date, expiry_date)) {
      return res.status(400).json({
        success: false,
        message: 'expiry_date must be on or after start_date.'
      });
    }

    if (!isNonNegativeNumberOrEmpty(price)) {
      return res.status(400).json({
        success: false,
        message: 'price must be a non-negative number.'
      });
    }

    const vehicleResult = await db.query(
      `SELECT v.vehicle_id, c.agent_id
       FROM vehicle v
       INNER JOIN customer c ON v.customer_id = c.customer_id
       WHERE v.vehicle_id = $1`,
      [vehicle_id]
    );

    if (vehicleResult.rows.length === 0) {
      return res.status(404).json({ success: false, message: 'Vehicle not found.' });
    }

    const vehicle = vehicleResult.rows[0];
    const isAdmin = req.user.role === 'Admin';
    const isOwner = vehicle.agent_id === req.user.agent_id;

    if (!isAdmin && !isOwner) {
      return res.status(403).json({
        success: false,
        message: 'Forbidden: You do not have permission to add records for this vehicle.'
      });
    }

    const result = await db.query(
      `INSERT INTO vehicle_compliance
        (vehicle_id, compliance_type, status, start_date, expiry_date, reminder, company_id, price, notes)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
       RETURNING *`,
      [
        vehicle_id, compliance_type, status || 'Active', start_date || null, expiry_date,
        reminder !== undefined ? reminder : true, company_id || null, price || 0, notes || null
      ]
    );

    return res.status(201).json({
      success: true,
      message: 'บันทึกข้อมูลเรียบร้อยแล้ว',
      data: result.rows[0]
    });
  } catch (error) {
    console.error('[complianceController.createCompliance] Error:', error.message);
    return res.status(500).json({
      success: false,
      message: 'Internal server error while creating the compliance record.'
    });
  }
};

/**
 * PUT /api/compliance/:id
 * Dynamically builds the SET clause so partial updates work cleanly.
 */
const updateCompliance = async (req, res) => {
  try {
    const { id } = req.params;
    const {
      status, start_date, expiry_date, reminder, company_id, price, notes
    } = req.body;

    const fields = [];
    const values = [];
    let paramIndex = 1;

    // Cross-field check only when both dates are present in this request -
    // a single-field partial update (e.g. only `notes` changing) has
    // nothing to compare against without an extra SELECT, so it's
    // skipped in that case.
    if (!isValidDateOrder(start_date, expiry_date)) {
      return res.status(400).json({ success: false, message: 'expiry_date must be on or after start_date.' });
    }
    if (!isNonNegativeNumberOrEmpty(price)) {
      return res.status(400).json({ success: false, message: 'price must be a non-negative number.' });
    }

    const addField = (column, value) => {
      fields.push(`${column} = $${paramIndex}`);
      values.push(value);
      paramIndex += 1;
    };

    if (status !== undefined) addField('status', status);
    if (start_date !== undefined) addField('start_date', start_date);
    if (expiry_date !== undefined) addField('expiry_date', expiry_date);
    if (reminder !== undefined) addField('reminder', reminder);
    if (company_id !== undefined) addField('company_id', company_id);
    if (price !== undefined) addField('price', price);
    if (notes !== undefined) addField('notes', notes);

    if (fields.length === 0) {
      return res.status(400).json({ success: false, message: 'No fields provided to update.' });
    }

    values.push(id);
    const result = await db.query(
      `UPDATE vehicle_compliance SET ${fields.join(', ')} WHERE compliance_id = $${paramIndex} RETURNING *`,
      values
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ success: false, message: 'Compliance record not found.' });
    }

    return res.status(200).json({
      success: true,
      message: 'แก้ไขข้อมูลเรียบร้อยแล้ว',
      data: result.rows[0]
    });
  } catch (error) {
    console.error('[complianceController.updateCompliance] Error:', error.message);
    return res.status(500).json({
      success: false,
      message: 'Internal server error while updating the compliance record.'
    });
  }
};

/**
 * DELETE /api/compliance/:id
 */
const deleteCompliance = async (req, res) => {
  try {
    const { id } = req.params;

    const result = await db.query(
      'DELETE FROM vehicle_compliance WHERE compliance_id = $1 RETURNING compliance_id',
      [id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ success: false, message: 'Compliance record not found.' });
    }

    return res.status(200).json({ success: true, message: 'ลบข้อมูลเรียบร้อยแล้ว' });
  } catch (error) {
    console.error('[complianceController.deleteCompliance] Error:', error.message);
    return res.status(500).json({
      success: false,
      message: 'Internal server error while deleting the compliance record.'
    });
  }
};

/**
 * GET /api/compliance/expiring
 * พรบ. / Vehicle Tax records expiring within 30 days (both types).
 * Mirrors customerController.getExpiringPolicies for symmetry - reused
 * by the Reminder System in Phase E.
 */
const listExpiringCompliance = async (req, res) => {
  try {
    const params = [];
    const scope = agentScope(req);
    let scopeClause = '';
    if (scope !== null) {
      params.push(scope);
      scopeClause = `AND c.agent_id = $${params.length}`;
    }

    const result = await db.query(
      `SELECT
         vc.compliance_id, vc.vehicle_id, vc.compliance_type, vc.status,
         vc.start_date, vc.expiry_date, vc.reminder, vc.price, vc.notes,
         (vc.expiry_date - CURRENT_DATE) AS days_remaining,
         v.license_plate, v.plate_province,
         c.customer_id, c.first_name AS customer_first_name, c.last_name AS customer_last_name,
         c.phone AS customer_phone,
         c.agent_id, ag.first_name AS agent_first_name, ag.last_name AS agent_last_name,
         co.company_id, co.company_name
       FROM vehicle_compliance vc
       INNER JOIN vehicle v ON vc.vehicle_id = v.vehicle_id
       INNER JOIN customer c ON v.customer_id = c.customer_id
       LEFT JOIN agent ag ON c.agent_id = ag.agent_id
       LEFT JOIN company co ON vc.company_id = co.company_id
       WHERE vc.expiry_date BETWEEN CURRENT_DATE AND (CURRENT_DATE + INTERVAL '30 days')
         ${scopeClause}
       ORDER BY vc.expiry_date ASC`,
      params
    );

    return res.status(200).json({ success: true, count: result.rows.length, data: result.rows });
  } catch (error) {
    console.error('[complianceController.listExpiringCompliance] Error:', error.message);
    return res.status(500).json({
      success: false,
      message: 'Internal server error while fetching expiring compliance records.'
    });
  }
};

module.exports = {
  listComplianceForVehicle,
  createCompliance,
  updateCompliance,
  deleteCompliance,
  listExpiringCompliance
};
