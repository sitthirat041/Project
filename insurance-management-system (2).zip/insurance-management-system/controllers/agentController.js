/**
 * controllers/agentController.js
 * -----------------------------------------------------------------------
 * Admin-only agent management: list, create, update, and delete agents.
 * Passwords are always hashed with bcrypt (salt round 10) before storage
 * and are never returned in any response.
 * -----------------------------------------------------------------------
 */

const bcrypt = require('bcryptjs');
const db = require('../db');

const AGENT_SAFE_COLUMNS = `
  agent_id, agent_code, first_name, last_name, phone, email, username, role, status
`;

/**
 * GET /api/agents
 * Admin only. Returns all agents with a computed customer_count.
 */
const listAgents = async (req, res) => {
  try {
    const result = await db.query(`
      SELECT
        a.agent_id, a.agent_code, a.first_name, a.last_name, a.phone,
        a.email, a.username, a.role, a.status,
        COUNT(c.customer_id)::int AS customer_count,
        (SELECT COUNT(*)::int FROM non_motor_policy nm WHERE nm.agent_id = a.agent_id) AS non_motor_count
      FROM agent a
      LEFT JOIN customer c ON c.agent_id = a.agent_id
      GROUP BY a.agent_id
      ORDER BY a.agent_id ASC
    `);

    return res.status(200).json({
      success: true,
      count: result.rows.length,
      data: result.rows
    });
  } catch (error) {
    console.error('[agentController.listAgents] Error:', error.message);
    return res.status(500).json({
      success: false,
      message: 'Internal server error while fetching agents.'
    });
  }
};

/**
 * POST /api/agents
 * Admin only. Creates a new agent with a bcrypt-hashed password.
 */
const createAgent = async (req, res) => {
  try {
    const { agent_code, first_name, last_name, phone, email, username, password, role, status } = req.body;

    if (!agent_code || !first_name || !last_name || !username || !password) {
      return res.status(400).json({
        success: false,
        message: 'agent_code, first_name, last_name, username, and password are required.'
      });
    }

    if (role && !['Admin', 'Agent'].includes(role)) {
      return res.status(400).json({
        success: false,
        message: "role must be either 'Admin' or 'Agent'."
      });
    }

    const passwordHash = await bcrypt.hash(password, 10);

    const result = await db.query(
      `INSERT INTO agent
        (agent_code, first_name, last_name, phone, email, username, password, role, status)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
       RETURNING ${AGENT_SAFE_COLUMNS}`,
      [
        agent_code, first_name, last_name, phone || null, email || null,
        username, passwordHash, role || 'Agent', status || 'Active'
      ]
    );

    return res.status(201).json({
      success: true,
      message: 'Agent created successfully.',
      data: result.rows[0]
    });
  } catch (error) {
    if (error.code === '23505') {
      return res.status(409).json({
        success: false,
        message: 'agent_code or username already exists. Please choose a different value.'
      });
    }
    console.error('[agentController.createAgent] Error:', error.message);
    return res.status(500).json({
      success: false,
      message: 'Internal server error while creating agent.'
    });
  }
};

/**
 * PUT /api/agents/:id
 * Admin only. Updates agent details. Password is only updated if a new
 * one is provided (re-hashed with bcrypt).
 */
const updateAgent = async (req, res) => {
  try {
    const { id } = req.params;
    const { agent_code, first_name, last_name, phone, email, username, password, role, status } = req.body;

    if (role && !['Admin', 'Agent'].includes(role)) {
      return res.status(400).json({
        success: false,
        message: "role must be either 'Admin' or 'Agent'."
      });
    }
    if (status && !['Active', 'Inactive'].includes(status)) {
      return res.status(400).json({
        success: false,
        message: "status must be either 'Active' or 'Inactive'."
      });
    }

    const fields = [];
    const values = [];
    let paramIndex = 1;

    const addField = (column, value) => {
      fields.push(`${column} = $${paramIndex}`);
      values.push(value);
      paramIndex += 1;
    };

    if (agent_code !== undefined) addField('agent_code', agent_code);
    if (first_name !== undefined) addField('first_name', first_name);
    if (last_name !== undefined) addField('last_name', last_name);
    if (phone !== undefined) addField('phone', phone);
    if (email !== undefined) addField('email', email);
    if (username !== undefined) addField('username', username);
    if (role !== undefined) addField('role', role);
    if (status !== undefined) addField('status', status);

    if (password) {
      const passwordHash = await bcrypt.hash(password, 10);
      addField('password', passwordHash);
    }

    if (fields.length === 0) {
      return res.status(400).json({
        success: false,
        message: 'No valid fields provided for update.'
      });
    }

    values.push(id);

    const result = await db.query(
      `UPDATE agent SET ${fields.join(', ')} WHERE agent_id = $${paramIndex} RETURNING ${AGENT_SAFE_COLUMNS}`,
      values
    );

    if (result.rows.length === 0) {
      return res.status(404).json({
        success: false,
        message: 'Agent not found.'
      });
    }

    return res.status(200).json({
      success: true,
      message: 'Agent updated successfully.',
      data: result.rows[0]
    });
  } catch (error) {
    if (error.code === '23505') {
      return res.status(409).json({
        success: false,
        message: 'agent_code or username already exists. Please choose a different value.'
      });
    }
    console.error('[agentController.updateAgent] Error:', error.message);
    return res.status(500).json({
      success: false,
      message: 'Internal server error while updating agent.'
    });
  }
};

/**
 * DELETE /api/agents/:id
 * Admin only. Fails with a friendly 409 if the agent still has
 * customers assigned (foreign key constraint), suggesting the Admin
 * reassign those customers or set the agent to Inactive instead.
 */
const deleteAgent = async (req, res) => {
  try {
    const { id } = req.params;

    if (req.user.agent_id === parseInt(id, 10)) {
      return res.status(400).json({
        success: false,
        message: 'You cannot delete your own account while logged in.'
      });
    }

    const result = await db.query(
      'DELETE FROM agent WHERE agent_id = $1 RETURNING agent_id',
      [id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({
        success: false,
        message: 'Agent not found.'
      });
    }

    return res.status(200).json({
      success: true,
      message: 'Agent deleted successfully.'
    });
  } catch (error) {
    if (error.code === '23503') {
      return res.status(409).json({
        success: false,
        message: 'This agent still has customers or Non-Motor records assigned. Transfer that work to another agent first, or set the agent to Inactive instead of deleting.'
      });
    }
    console.error('[agentController.deleteAgent] Error:', error.message);
    return res.status(500).json({
      success: false,
      message: 'Internal server error while deleting agent.'
    });
  }
};

/**
 * POST /api/agents/:id/transfer
 * Admin only. Body: { to_agent_id }. Moves ALL customers (and, through
 * them, their vehicles/policies/พรบ./tax) plus all Non-Motor records
 * from agent :id to to_agent_id in one transaction. Used when an agent
 * leaves, since Agents can only see their own work.
 */
const transferAgentWork = async (req, res) => {
  const fromId = parseInt(req.params.id, 10);
  const toId = parseInt(req.body.to_agent_id, 10);

  if (Number.isNaN(fromId) || Number.isNaN(toId)) {
    return res.status(400).json({ success: false, message: 'to_agent_id is required.' });
  }
  if (fromId === toId) {
    return res.status(400).json({ success: false, message: 'Source and target agent must be different.' });
  }

  const client = await db.pool.connect();
  try {
    const target = await client.query(
      "SELECT agent_id, status FROM agent WHERE agent_id = $1",
      [toId]
    );
    if (target.rows.length === 0) {
      return res.status(404).json({ success: false, message: 'Target agent not found.' });
    }
    if (target.rows[0].status !== 'Active') {
      return res.status(400).json({ success: false, message: 'Target agent must be Active.' });
    }
    const source = await client.query('SELECT agent_id FROM agent WHERE agent_id = $1', [fromId]);
    if (source.rows.length === 0) {
      return res.status(404).json({ success: false, message: 'Source agent not found.' });
    }

    await client.query('BEGIN');
    const customers = await client.query(
      'UPDATE customer SET agent_id = $1 WHERE agent_id = $2',
      [toId, fromId]
    );
    const nonMotor = await client.query(
      'UPDATE non_motor_policy SET agent_id = $1 WHERE agent_id = $2',
      [toId, fromId]
    );
    await client.query('COMMIT');

    return res.status(200).json({
      success: true,
      message: 'Transferred successfully.',
      data: { customers: customers.rowCount, non_motor: nonMotor.rowCount }
    });
  } catch (error) {
    await client.query('ROLLBACK').catch(() => {});
    console.error('[agentController.transferAgentWork] Error:', error.message);
    return res.status(500).json({
      success: false,
      message: 'Internal server error while transferring agent work.'
    });
  } finally {
    client.release();
  }
};

module.exports = {
  transferAgentWork,
  listAgents,
  createAgent,
  updateAgent,
  deleteAgent
};
