/**
 * controllers/customerController.js
 * -----------------------------------------------------------------------
 * Handles customer-related business logic:
 *  - Global search across customer / agent / vehicle / policy / company
 *  - Get single customer detail
 *  - Create customer (Agent auto-bound to req.user.agent_id)
 *  - Update customer (protected by checkCustomerOwnerOrAdmin)
 *  - Delete customer (protected by checkCustomerOwnerOrAdmin)
 *  - List policies expiring within 30 days (Dashboard widget)
 * -----------------------------------------------------------------------
 */

const db = require('../db');
const { agentScope, searchAgentFilter } = require('../middleware/access');

/**
 * GET /api/customers/search?q=keyword
 * Admin sees every customer; an Agent sees only customers they own.
 * Searches across customer name, phone, license plate, and policy number.
 */
const searchCustomers = async (req, res) => {
  try {
    const keyword = (req.query.q || '').trim();

    const searchPattern = `%${keyword}%`;

    const params = [keyword, searchPattern];
    const scope = searchAgentFilter(req);
    let scopeClause = '';
    if (scope !== null) {
      params.push(scope);
      scopeClause = `AND c.agent_id = $${params.length}`;
    }

    const queryText = `
      SELECT
        c.customer_id,
        c.title,
        c.first_name        AS customer_first_name,
        c.last_name         AS customer_last_name,
        c.phone             AS customer_phone,
        c.line_id,
        c.email              AS customer_email,
        c.address,
        c.occupation,
        c.created_at,
        a.agent_id,
        a.agent_code,
        a.first_name         AS agent_first_name,
        a.last_name          AS agent_last_name,
        v.vehicle_id,
        v.license_plate,
        v.plate_province,
        v.brand               AS vehicle_brand,
        v.model                AS vehicle_model,
        v.production_year,
        v.color,
        p.policy_id,
        p.policy_number,
        p.insurance_type,
        p.premium,
        p.start_date,
        p.end_date,
        p.renewal_status,
        p.status              AS policy_status,
        p.notes               AS policy_notes,
        co.company_id,
        co.company_name,
        (p.end_date - CURRENT_DATE) AS days_remaining
      FROM customer c
      LEFT JOIN agent a    ON c.agent_id = a.agent_id
      LEFT JOIN vehicle v  ON v.customer_id = c.customer_id
      LEFT JOIN policy p   ON p.vehicle_id = v.vehicle_id
      LEFT JOIN company co ON p.company_id = co.company_id
      WHERE
        (($1 = '') OR (
          (c.first_name || ' ' || c.last_name) ILIKE $2
          OR c.phone ILIKE $2
          OR v.license_plate ILIKE $2
          OR p.policy_number ILIKE $2
        ))
        ${scopeClause}
      ORDER BY c.customer_id DESC, p.end_date ASC
    `;

    const result = await db.query(queryText, params);

    return res.status(200).json({
      success: true,
      count: result.rows.length,
      data: result.rows
    });
  } catch (error) {
    console.error('[customerController.searchCustomers] Error:', error.message);
    return res.status(500).json({
      success: false,
      message: 'Internal server error while searching customers.'
    });
  }
};

/**
 * GET /api/customers/:id
 * Fetch a single customer with related agent, vehicles, and policies.
 * Route is guarded by canViewCustomer: Admin, or the owning Agent only.
 */
const getCustomerById = async (req, res) => {
  try {
    const { id } = req.params;

    const customerResult = await db.query(
      `SELECT
         c.customer_id, c.title, c.first_name, c.last_name, c.phone,
         c.line_id, c.email, c.address, c.occupation, c.created_at,
         a.agent_id, a.agent_code, a.first_name AS agent_first_name,
         a.last_name AS agent_last_name
       FROM customer c
       LEFT JOIN agent a ON c.agent_id = a.agent_id
       WHERE c.customer_id = $1`,
      [id]
    );

    if (customerResult.rows.length === 0) {
      return res.status(404).json({
        success: false,
        message: 'Customer not found.'
      });
    }

    const vehiclesResult = await db.query(
      `SELECT
         v.vehicle_id, v.license_plate, v.plate_province, v.brand, v.model,
         v.production_year, v.color, v.chassis_no, v.engine_no,
         p.policy_id, p.policy_number, p.insurance_type, p.premium,
         p.start_date, p.end_date, p.renewal_status, p.status AS policy_status, p.notes,
         co.company_id, co.company_name,
         (p.end_date - CURRENT_DATE) AS days_remaining,
         pa.attachment_id, pa.file_name AS attachment_file_name,
         pa.mime_type AS attachment_mime_type, pa.file_size AS attachment_file_size,
         pa.uploaded_at AS attachment_uploaded_at
       FROM vehicle v
       LEFT JOIN policy p ON p.vehicle_id = v.vehicle_id
       LEFT JOIN company co ON p.company_id = co.company_id
       LEFT JOIN policy_attachment pa ON pa.policy_id = p.policy_id
       WHERE v.customer_id = $1
       ORDER BY v.vehicle_id ASC`,
      [id]
    );

    // พรบ. / Vehicle Tax records (NEW REQUIREMENT #7) - fetched as a
    // separate query keyed by vehicle_id rather than joined into the
    // query above, since a vehicle can have several compliance records
    // (renewed yearly) and joining would multiply the vehicle/policy
    // rows above.
    const vehicleIds = vehiclesResult.rows.map((v) => v.vehicle_id);
    let complianceByVehicle = {};
    if (vehicleIds.length > 0) {
      const complianceResult = await db.query(
        `SELECT
           vc.compliance_id, vc.vehicle_id, vc.compliance_type, vc.status,
           vc.start_date, vc.expiry_date, vc.reminder, vc.price, vc.notes,
           (vc.expiry_date - CURRENT_DATE) AS days_remaining,
           co.company_id, co.company_name
         FROM vehicle_compliance vc
         LEFT JOIN company co ON vc.company_id = co.company_id
         WHERE vc.vehicle_id = ANY($1::int[])
         ORDER BY vc.expiry_date DESC`,
        [vehicleIds]
      );
      complianceResult.rows.forEach((row) => {
        if (!complianceByVehicle[row.vehicle_id]) complianceByVehicle[row.vehicle_id] = [];
        complianceByVehicle[row.vehicle_id].push(row);
      });
    }

    const vehicles = vehiclesResult.rows.map((v) => ({
      ...v,
      compliance: complianceByVehicle[v.vehicle_id] || []
    }));

    return res.status(200).json({
      success: true,
      data: {
        ...customerResult.rows[0],
        vehicles
      }
    });
  } catch (error) {
    console.error('[customerController.getCustomerById] Error:', error.message);
    return res.status(500).json({
      success: false,
      message: 'Internal server error while fetching customer.'
    });
  }
};

/**
 * POST /api/customers
 * Both Admin and Agent can create a customer.
 * For Agent role, customer.agent_id is auto-bound to req.user.agent_id.
 * For Admin role, agent_id may optionally be provided in the request body
 * to assign the new customer to a specific agent; defaults to the admin's own id.
 */
const createCustomer = async (req, res) => {
  try {
    const { title, first_name, last_name, phone, line_id, email, address, occupation } = req.body;

    if (!first_name || !last_name || !phone) {
      return res.status(400).json({
        success: false,
        message: 'first_name, last_name, and phone are required fields.'
      });
    }

    let agentId = req.user.agent_id;

    if (req.user.role === 'Admin' && req.body.agent_id) {
      agentId = req.body.agent_id;
    }

    // Agents cannot see other agents' customers, so guard against creating
    // a duplicate of one - without revealing who owns it or any details.
    const duplicate = await db.query(
      'SELECT 1 FROM customer WHERE phone = $1 AND agent_id IS DISTINCT FROM $2 LIMIT 1',
      [phone, agentId]
    );
    if (duplicate.rows.length > 0) {
      return res.status(409).json({
        success: false,
        message: 'มีลูกค้าเบอร์โทรนี้อยู่ในระบบแล้ว (อยู่ภายใต้ตัวแทนท่านอื่น) กรุณาติดต่อผู้ดูแลระบบ'
      });
    }

    const result = await db.query(
      `INSERT INTO customer
        (agent_id, title, first_name, last_name, phone, line_id, email, address, occupation)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
       RETURNING *`,
      [agentId, title || null, first_name, last_name, phone, line_id || null, email || null, address || null, occupation || null]
    );

    return res.status(201).json({
      success: true,
      message: 'Customer created successfully.',
      data: result.rows[0]
    });
  } catch (error) {
    console.error('[customerController.createCustomer] Error:', error.message);
    return res.status(500).json({
      success: false,
      message: 'Internal server error while creating customer.'
    });
  }
};

/**
 * PUT /api/customers/:id
 * Protected by verifyToken + checkCustomerOwnerOrAdmin.
 * Admin can also reassign the owning agent (customer.agent_id).
 * Uses parameterized (prepared statement) queries to prevent SQL injection.
 */
const updateCustomer = async (req, res) => {
  try {
    const { id } = req.params;
    const { title, first_name, last_name, phone, line_id, email, address, occupation, agent_id } = req.body;

    const fields = [];
    const values = [];
    let paramIndex = 1;

    const addField = (column, value) => {
      fields.push(`${column} = $${paramIndex}`);
      values.push(value);
      paramIndex += 1;
    };

    if (title !== undefined) addField('title', title);
    if (first_name !== undefined) addField('first_name', first_name);
    if (last_name !== undefined) addField('last_name', last_name);
    if (phone !== undefined) addField('phone', phone);
    if (line_id !== undefined) addField('line_id', line_id);
    if (email !== undefined) addField('email', email);
    if (address !== undefined) addField('address', address);
    if (occupation !== undefined) addField('occupation', occupation);

    // Only Admin is allowed to reassign the owning agent.
    if (agent_id !== undefined) {
      if (req.user.role !== 'Admin') {
        return res.status(403).json({
          success: false,
          message: 'Forbidden: Only Admin can reassign the responsible agent for a customer.'
        });
      }
      addField('agent_id', agent_id);
    }

    if (fields.length === 0) {
      return res.status(400).json({
        success: false,
        message: 'No valid fields provided for update.'
      });
    }

    values.push(id);

    const queryText = `
      UPDATE customer
      SET ${fields.join(', ')}
      WHERE customer_id = $${paramIndex}
      RETURNING *
    `;

    const result = await db.query(queryText, values);

    if (result.rows.length === 0) {
      return res.status(404).json({
        success: false,
        message: 'Customer not found.'
      });
    }

    return res.status(200).json({
      success: true,
      message: 'Customer updated successfully.',
      data: result.rows[0]
    });
  } catch (error) {
    console.error('[customerController.updateCustomer] Error:', error.message);
    return res.status(500).json({
      success: false,
      message: 'Internal server error while updating customer.'
    });
  }
};

/**
 * DELETE /api/customers/:id
 * Protected by verifyToken + checkCustomerOwnerOrAdmin.
 */
const deleteCustomer = async (req, res) => {
  try {
    const { id } = req.params;

    const result = await db.query(
      'DELETE FROM customer WHERE customer_id = $1 RETURNING customer_id',
      [id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({
        success: false,
        message: 'Customer not found.'
      });
    }

    return res.status(200).json({
      success: true,
      message: 'Customer deleted successfully.'
    });
  } catch (error) {
    console.error('[customerController.deleteCustomer] Error:', error.message);
    return res.status(500).json({
      success: false,
      message: 'Internal server error while deleting customer.'
    });
  }
};

/**
 * GET /api/policies/expiring
 * Returns policies expiring within the next 30 days (inclusive), for the
 * Dashboard "Expiring Soon" widget. Admin sees all; an Agent sees only
 * policies of customers they own.
 */
const getExpiringPolicies = async (req, res) => {
  try {
    const params = [];
    const scope = agentScope(req);
    let scopeClause = '';
    if (scope !== null) {
      params.push(scope);
      scopeClause = `AND c.agent_id = $${params.length}`;
    }

    const queryText = `
      SELECT
        p.policy_id,
        p.policy_number,
        p.insurance_type,
        p.premium,
        p.start_date,
        p.end_date,
        p.renewal_status,
        p.status AS policy_status,
        p.notes AS policy_notes,
        (p.end_date - CURRENT_DATE) AS days_remaining,
        v.vehicle_id,
        v.license_plate,
        v.plate_province,
        v.brand AS vehicle_brand,
        v.model AS vehicle_model,
        c.customer_id,
        c.first_name AS customer_first_name,
        c.last_name AS customer_last_name,
        c.phone AS customer_phone,
        a.agent_id,
        a.first_name AS agent_first_name,
        a.last_name AS agent_last_name,
        co.company_id,
        co.company_name
      FROM policy p
      INNER JOIN vehicle v   ON p.vehicle_id = v.vehicle_id
      INNER JOIN customer c  ON v.customer_id = c.customer_id
      LEFT JOIN agent a      ON c.agent_id = a.agent_id
      LEFT JOIN company co   ON p.company_id = co.company_id
      WHERE p.end_date >= CURRENT_DATE
        AND p.end_date <= (CURRENT_DATE + INTERVAL '30 days')
        AND p.status = 'Active'
        ${scopeClause}
      ORDER BY p.end_date ASC
    `;

    const result = await db.query(queryText, params);

    return res.status(200).json({
      success: true,
      count: result.rows.length,
      data: result.rows
    });
  } catch (error) {
    console.error('[customerController.getExpiringPolicies] Error:', error.message);
    return res.status(500).json({
      success: false,
      message: 'Internal server error while fetching expiring policies.'
    });
  }
};

module.exports = {
  searchCustomers,
  getCustomerById,
  createCustomer,
  updateCustomer,
  deleteCustomer,
  getExpiringPolicies
};
