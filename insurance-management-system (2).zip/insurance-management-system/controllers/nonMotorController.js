/**
 * controllers/nonMotorController.js
 * -----------------------------------------------------------------------
 * Non-Motor Insurance module (NEW REQUIREMENT #8): Fire, Health,
 * Personal Accident, Marine Cargo, Travel, Others. Records are NOT tied
 * to the existing `customer` table - an agent can capture a lead's
 * name/address/phone directly. Ownership follows agent_id on the record
 * itself (same pattern as customer ownership, just one hop shorter).
 *
 * Attachment handling (view/download/replace/delete) mirrors
 * attachmentController.js but against non_motor_attachment /
 * uploadNonMotorAttachment.
 * -----------------------------------------------------------------------
 */

const fs = require('fs');
const path = require('path');
const db = require('../db');
const { agentScope, searchAgentFilter } = require('../middleware/access');
const { NON_MOTOR_UPLOAD_DIR } = require('../middleware/upload');
const { isValidDateOrder, isNonNegativeNumberOrEmpty } = require('../utils/validators');

const VALID_TYPES = ['Fire', 'Health', 'Personal Accident', 'Marine Cargo', 'Travel', 'Others'];

/**
 * GET /api/non-motor/search?q=&type=&status=
 * Admin sees every record; an Agent sees only records they own
 * (nm.agent_id). Rows include the owning agent's name.
 */
const searchNonMotor = async (req, res) => {
  try {
    const { q, type, status } = req.query;

    const conditions = [];
    const params = [];

    if (q && q.trim()) {
      params.push(`%${q.trim()}%`);
      conditions.push(`(nm.customer_name ILIKE $${params.length} OR nm.phone ILIKE $${params.length} OR nm.policy_number ILIKE $${params.length} OR nm.beneficiary ILIKE $${params.length})`);
    }
    if (type && VALID_TYPES.includes(type)) {
      params.push(type);
      conditions.push(`nm.insurance_type = $${params.length}`);
    }
    if (status && ['Active', 'Expired'].includes(status)) {
      params.push(status);
      conditions.push(`nm.status = $${params.length}`);
    }

    const scope = searchAgentFilter(req);
    if (scope !== null) {
      params.push(scope);
      conditions.push(`nm.agent_id = $${params.length}`);
    }

    const whereClause = conditions.length > 0 ? `WHERE ${conditions.join(' AND ')}` : '';

    const result = await db.query(
      `SELECT
         nm.non_motor_id, nm.agent_id, nm.customer_name, nm.address, nm.phone,
         nm.insurance_type, nm.policy_number, nm.premium,
         nm.coverage_start, nm.coverage_end, nm.source, nm.broker, nm.direct_company,
         nm.beneficiary, nm.sum_insured, nm.coverage_limit,
         nm.status, nm.notes, nm.created_at,
         (nm.coverage_end - CURRENT_DATE) AS days_remaining,
         co.company_id, co.company_name,
         ag.first_name AS agent_first_name, ag.last_name AS agent_last_name,
         na.attachment_id, na.file_name AS attachment_file_name, na.uploaded_at AS attachment_uploaded_at
       FROM non_motor_policy nm
       LEFT JOIN company co ON nm.company_id = co.company_id
       LEFT JOIN agent ag ON nm.agent_id = ag.agent_id
       LEFT JOIN non_motor_attachment na ON na.non_motor_id = nm.non_motor_id
       ${whereClause}
       ORDER BY nm.coverage_end ASC`,
      params
    );

    return res.status(200).json({ success: true, count: result.rows.length, data: result.rows });
  } catch (error) {
    console.error('[nonMotorController.searchNonMotor] Error:', error.message);
    return res.status(500).json({
      success: false,
      message: 'Internal server error while searching non-motor records.'
    });
  }
};

/**
 * GET /api/non-motor/:id
 * Route is guarded by canViewNonMotor (Admin or owning Agent only).
 */
const getNonMotorById = async (req, res) => {
  try {
    const { id } = req.params;

    const result = await db.query(
      `SELECT
         nm.*, (nm.coverage_end - CURRENT_DATE) AS days_remaining,
         co.company_name,
         ag.first_name AS agent_first_name, ag.last_name AS agent_last_name,
         na.attachment_id, na.file_name AS attachment_file_name,
         na.mime_type AS attachment_mime_type, na.file_size AS attachment_file_size,
         na.uploaded_at AS attachment_uploaded_at
       FROM non_motor_policy nm
       LEFT JOIN company co ON nm.company_id = co.company_id
       LEFT JOIN agent ag ON nm.agent_id = ag.agent_id
       LEFT JOIN non_motor_attachment na ON na.non_motor_id = nm.non_motor_id
       WHERE nm.non_motor_id = $1`,
      [id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ success: false, message: 'Non-motor record not found.' });
    }

    return res.status(200).json({ success: true, data: result.rows[0] });
  } catch (error) {
    console.error('[nonMotorController.getNonMotorById] Error:', error.message);
    return res.status(500).json({
      success: false,
      message: 'Internal server error while fetching the non-motor record.'
    });
  }
};

/**
 * POST /api/non-motor
 * For Agent role, agent_id is auto-bound to req.user.agent_id (same
 * pattern as createCustomer). Admin may optionally assign to a
 * specific agent via the request body.
 */
const createNonMotor = async (req, res) => {
  try {
    const {
      customer_name, address, phone, insurance_type, company_id, policy_number,
      premium, coverage_start, coverage_end, source, broker, direct_company,
      beneficiary, sum_insured, coverage_limit,
      status, notes
    } = req.body;

    if (!customer_name || !insurance_type || !coverage_end) {
      return res.status(400).json({
        success: false,
        message: 'customer_name, insurance_type, and coverage_end are required.'
      });
    }

    if (!VALID_TYPES.includes(insurance_type)) {
      return res.status(400).json({
        success: false,
        message: `insurance_type must be one of: ${VALID_TYPES.join(', ')}`
      });
    }

    if (!isValidDateOrder(coverage_start, coverage_end)) {
      return res.status(400).json({
        success: false,
        message: 'coverage_end must be on or after coverage_start.'
      });
    }

    if (!isNonNegativeNumberOrEmpty(premium)) {
      return res.status(400).json({
        success: false,
        message: 'premium must be a non-negative number.'
      });
    }

    let agentId = req.user.agent_id;
    if (req.user.role === 'Admin' && req.body.agent_id) {
      agentId = req.body.agent_id;
    }

    const result = await db.query(
      `INSERT INTO non_motor_policy
        (agent_id, customer_name, address, phone, insurance_type, company_id, policy_number,
         premium, coverage_start, coverage_end, source, broker, direct_company,
         beneficiary, sum_insured, coverage_limit, status, notes, commission_rate)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16, $17, $18,
               (SELECT commission_rate FROM company WHERE company_id = $6))
       RETURNING *`,
      [
        agentId, customer_name, address || null, phone || null, insurance_type,
        company_id || null, policy_number || null, premium || 0,
        coverage_start || null, coverage_end, source || null, broker || null,
        direct_company || null, beneficiary || null, sum_insured || null,
        coverage_limit || null, status || 'Active', notes || null
      ]
    );

    return res.status(201).json({
      success: true,
      message: 'บันทึกกรมธรรม์ Non-Motor เรียบร้อยแล้ว',
      data: result.rows[0]
    });
  } catch (error) {
    console.error('[nonMotorController.createNonMotor] Error:', error.message);
    return res.status(500).json({
      success: false,
      message: 'Internal server error while creating the non-motor record.'
    });
  }
};

/**
 * PUT /api/non-motor/:id
 */
const updateNonMotor = async (req, res) => {
  try {
    const { id } = req.params;
    const {
      customer_name, address, phone, insurance_type, company_id, policy_number,
      premium, coverage_start, coverage_end, source, broker, direct_company,
      beneficiary, sum_insured, coverage_limit,
      status, notes
    } = req.body;

    if (insurance_type !== undefined && !VALID_TYPES.includes(insurance_type)) {
      return res.status(400).json({
        success: false,
        message: `insurance_type must be one of: ${VALID_TYPES.join(', ')}`
      });
    }
    if (!isValidDateOrder(coverage_start, coverage_end)) {
      return res.status(400).json({
        success: false,
        message: 'coverage_end must be on or after coverage_start.'
      });
    }
    if (!isNonNegativeNumberOrEmpty(premium)) {
      return res.status(400).json({
        success: false,
        message: 'premium must be a non-negative number.'
      });
    }

    const fields = [];
    const values = [];
    let paramIndex = 1;
    const addField = (column, value) => {
      fields.push(`${column} = $${paramIndex}`);
      values.push(value);
      paramIndex += 1;
    };

    if (req.body.agent_id !== undefined) {
      if (req.user.role !== 'Admin') {
        return res.status(403).json({
          success: false,
          message: 'Forbidden: Only Admin can reassign the responsible agent.'
        });
      }
      addField('agent_id', req.body.agent_id);
    }
    if (customer_name !== undefined) addField('customer_name', customer_name);
    if (address !== undefined) addField('address', address);
    if (phone !== undefined) addField('phone', phone);
    if (insurance_type !== undefined) addField('insurance_type', insurance_type);
    if (company_id !== undefined) {
      addField('company_id', company_id || null);
      fields.push(`commission_rate = (SELECT commission_rate FROM company WHERE company_id = $${paramIndex - 1})`);
    }
    if (policy_number !== undefined) addField('policy_number', policy_number);
    if (premium !== undefined) addField('premium', premium);
    if (coverage_start !== undefined) addField('coverage_start', coverage_start);
    if (coverage_end !== undefined) addField('coverage_end', coverage_end);
    if (source !== undefined) addField('source', source);
    if (broker !== undefined) addField('broker', broker);
    if (direct_company !== undefined) addField('direct_company', direct_company);
    if (beneficiary !== undefined) addField('beneficiary', beneficiary);
    if (sum_insured !== undefined) addField('sum_insured', sum_insured);
    if (coverage_limit !== undefined) addField('coverage_limit', coverage_limit);
    if (status !== undefined) addField('status', status);
    if (notes !== undefined) addField('notes', notes);

    if (fields.length === 0) {
      return res.status(400).json({ success: false, message: 'No fields provided to update.' });
    }

    values.push(id);
    const result = await db.query(
      `UPDATE non_motor_policy SET ${fields.join(', ')} WHERE non_motor_id = $${paramIndex} RETURNING *`,
      values
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ success: false, message: 'Non-motor record not found.' });
    }

    return res.status(200).json({
      success: true,
      message: 'แก้ไขกรมธรรม์ Non-Motor เรียบร้อยแล้ว',
      data: result.rows[0]
    });
  } catch (error) {
    console.error('[nonMotorController.updateNonMotor] Error:', error.message);
    return res.status(500).json({
      success: false,
      message: 'Internal server error while updating the non-motor record.'
    });
  }
};

/**
 * DELETE /api/non-motor/:id
 * Also removes the attachment file on disk, if any (the DB row cascades
 * automatically via the FK, but the physical file needs an explicit
 * cleanup - same pattern as policyController.deletePolicy).
 */
const deleteNonMotor = async (req, res) => {
  try {
    const { id } = req.params;

    const attachment = await db.query(
      'SELECT file_path FROM non_motor_attachment WHERE non_motor_id = $1',
      [id]
    );

    const result = await db.query(
      'DELETE FROM non_motor_policy WHERE non_motor_id = $1 RETURNING non_motor_id',
      [id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ success: false, message: 'Non-motor record not found.' });
    }

    if (attachment.rows.length > 0) {
      const filePath = path.join(NON_MOTOR_UPLOAD_DIR, attachment.rows[0].file_path);
      fs.unlink(filePath, (err) => {
        if (err && err.code !== 'ENOENT') {
          console.error('[nonMotorController.deleteNonMotor] Failed to remove attachment file:', err.message);
        }
      });
    }

    return res.status(200).json({ success: true, message: 'ลบกรมธรรม์ Non-Motor เรียบร้อยแล้ว' });
  } catch (error) {
    console.error('[nonMotorController.deleteNonMotor] Error:', error.message);
    return res.status(500).json({
      success: false,
      message: 'Internal server error while deleting the non-motor record.'
    });
  }
};

/* ---------------------------------------------------------------------
   Attachment handling (upload/replace, metadata, file, delete) - mirrors
   attachmentController.js but against non_motor_attachment.
   --------------------------------------------------------------------- */

const uploadNonMotorAttachmentFile = async (req, res) => {
  try {
    const nonMotorId = req.params.id;

    if (!req.file) {
      return res.status(400).json({
        success: false,
        message: 'กรุณาเลือกไฟล์ที่ต้องการอัปโหลด (PDF, รูปภาพ, หรือ DOCX)'
      });
    }

    const existing = await db.query(
      'SELECT file_path FROM non_motor_attachment WHERE non_motor_id = $1',
      [nonMotorId]
    );

    const result = await db.query(
      `INSERT INTO non_motor_attachment (non_motor_id, file_name, file_path, mime_type, file_size)
       VALUES ($1, $2, $3, $4, $5)
       ON CONFLICT (non_motor_id) DO UPDATE SET
         file_name = EXCLUDED.file_name,
         file_path = EXCLUDED.file_path,
         mime_type = EXCLUDED.mime_type,
         file_size = EXCLUDED.file_size,
         uploaded_at = NOW()
       RETURNING attachment_id, non_motor_id, file_name, mime_type, file_size, uploaded_at`,
      [nonMotorId, req.file.originalname, req.file.filename, req.file.mimetype, req.file.size]
    );

    if (existing.rows.length > 0 && existing.rows[0].file_path !== req.file.filename) {
      const oldPath = path.join(NON_MOTOR_UPLOAD_DIR, existing.rows[0].file_path);
      fs.unlink(oldPath, (err) => {
        if (err && err.code !== 'ENOENT') {
          console.error('[nonMotorController.uploadNonMotorAttachmentFile] Failed to remove old file:', err.message);
        }
      });
    }

    return res.status(existing.rows.length > 0 ? 200 : 201).json({
      success: true,
      message: existing.rows.length > 0 ? 'แทนที่ไฟล์แนบเรียบร้อยแล้ว' : 'อัปโหลดไฟล์แนบเรียบร้อยแล้ว',
      data: result.rows[0]
    });
  } catch (error) {
    if (req.file) {
      fs.unlink(path.join(NON_MOTOR_UPLOAD_DIR, req.file.filename), () => {});
    }
    console.error('[nonMotorController.uploadNonMotorAttachmentFile] Error:', error.message);
    return res.status(500).json({
      success: false,
      message: 'Internal server error while uploading the attachment.'
    });
  }
};

const getNonMotorAttachmentFile = async (req, res) => {
  try {
    const nonMotorId = req.params.id;

    const result = await db.query(
      'SELECT file_name, file_path, mime_type FROM non_motor_attachment WHERE non_motor_id = $1',
      [nonMotorId]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ success: false, message: 'ไม่พบไฟล์แนบสำหรับรายการนี้' });
    }

    const attachment = result.rows[0];
    const absolutePath = path.join(NON_MOTOR_UPLOAD_DIR, attachment.file_path);

    if (!fs.existsSync(absolutePath)) {
      return res.status(404).json({ success: false, message: 'ไม่พบไฟล์บนเซิร์ฟเวอร์ (อาจถูกลบไปแล้ว)' });
    }

    res.setHeader('Content-Type', attachment.mime_type || 'application/octet-stream');
    return res.sendFile(absolutePath);
  } catch (error) {
    console.error('[nonMotorController.getNonMotorAttachmentFile] Error:', error.message);
    return res.status(500).json({
      success: false,
      message: 'Internal server error while retrieving the attachment file.'
    });
  }
};

const deleteNonMotorAttachment = async (req, res) => {
  try {
    const nonMotorId = req.params.id;

    const result = await db.query(
      'DELETE FROM non_motor_attachment WHERE non_motor_id = $1 RETURNING file_path',
      [nonMotorId]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ success: false, message: 'ไม่พบไฟล์แนบสำหรับรายการนี้' });
    }

    const filePath = path.join(NON_MOTOR_UPLOAD_DIR, result.rows[0].file_path);
    fs.unlink(filePath, (err) => {
      if (err && err.code !== 'ENOENT') {
        console.error('[nonMotorController.deleteNonMotorAttachment] Failed to remove file:', err.message);
      }
    });

    return res.status(200).json({ success: true, message: 'ลบไฟล์แนบเรียบร้อยแล้ว' });
  } catch (error) {
    console.error('[nonMotorController.deleteNonMotorAttachment] Error:', error.message);
    return res.status(500).json({
      success: false,
      message: 'Internal server error while deleting the attachment.'
    });
  }
};

module.exports = {
  searchNonMotor,
  getNonMotorById,
  createNonMotor,
  updateNonMotor,
  deleteNonMotor,
  uploadNonMotorAttachmentFile,
  getNonMotorAttachmentFile,
  deleteNonMotorAttachment
};
