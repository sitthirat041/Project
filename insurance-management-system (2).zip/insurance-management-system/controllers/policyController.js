/**
 * controllers/policyController.js
 * -----------------------------------------------------------------------
 * Policy management. Ownership follows vehicle -> customer -> agent_id:
 *  - Admin: full access
 *  - Agent: only for policies on vehicles belonging to customers they own
 * -----------------------------------------------------------------------
 */

const db = require('../db');
const { agentScope, searchAgentFilter } = require('../middleware/access');
const fs = require('fs');
const path = require('path');
const { UPLOAD_DIR } = require('../middleware/upload');
const { isValidDateOrder, isNonNegativeNumberOrEmpty } = require('../utils/validators');

/**
 * POST /api/policies
 * Body must include vehicle_id. Ownership is checked inline here since
 * there is no :id route param yet at creation time.
 */
const createPolicy = async (req, res) => {
  try {
    const {
      vehicle_id, company_id, policy_number, insurance_type, premium,
      start_date, end_date, renewal_status, status, notes
    } = req.body;

    if (!vehicle_id || !policy_number || !insurance_type || !start_date || !end_date) {
      return res.status(400).json({
        success: false,
        message: 'vehicle_id, policy_number, insurance_type, start_date, and end_date are required.'
      });
    }

    if (!isValidDateOrder(start_date, end_date)) {
      return res.status(400).json({
        success: false,
        message: 'end_date must be on or after start_date.'
      });
    }

    if (!isNonNegativeNumberOrEmpty(premium)) {
      return res.status(400).json({
        success: false,
        message: 'premium must be a non-negative number.'
      });
    }

    const vehicleResult = await db.query(
      `SELECT v.vehicle_id, c.agent_id
       FROM vehicle v
       INNER JOIN customer c ON v.customer_id = c.customer_id
       WHERE v.vehicle_id = $1`,
      [vehicle_id]
    );

    if (vehicleResult.rows.length === 0) {
      return res.status(404).json({
        success: false,
        message: 'Vehicle not found.'
      });
    }

    const vehicle = vehicleResult.rows[0];
    const isAdmin = req.user.role === 'Admin';
    const isOwner = vehicle.agent_id === req.user.agent_id;

    if (!isAdmin && !isOwner) {
      return res.status(403).json({
        success: false,
        message: 'Forbidden: You can only add policies to vehicles of customers you own.'
      });
    }

    const result = await db.query(
      `INSERT INTO policy
        (vehicle_id, company_id, policy_number, insurance_type, premium, start_date, end_date, renewal_status, status, notes, commission_rate)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10,
               (SELECT commission_rate FROM company WHERE company_id = $2))
       RETURNING *`,
      [
        vehicle_id, company_id || null, policy_number, insurance_type,
        premium || 0, start_date, end_date, renewal_status || 'Pending', status || 'Active', notes || null
      ]
    );

    return res.status(201).json({
      success: true,
      message: 'Policy created successfully.',
      data: result.rows[0]
    });
  } catch (error) {
    console.error('[policyController.createPolicy] Error:', error.message);
    return res.status(500).json({
      success: false,
      message: 'Internal server error while creating policy.'
    });
  }
};

/**
 * PUT /api/policies/:id
 * Protected by verifyToken + checkPolicyOwnerOrAdmin.
 */
const updatePolicy = async (req, res) => {
  try {
    const { id } = req.params;
    const {
      company_id, policy_number, insurance_type, premium,
      start_date, end_date, renewal_status, status, notes
    } = req.body;

    if (renewal_status && !['Pending', 'Renewed', 'Not Renewed'].includes(renewal_status)) {
      return res.status(400).json({
        success: false,
        message: "renewal_status must be 'Pending', 'Renewed', or 'Not Renewed'."
      });
    }
    if (status && !['Active', 'Expired'].includes(status)) {
      return res.status(400).json({
        success: false,
        message: "status must be 'Active' or 'Expired'."
      });
    }
    if (!isValidDateOrder(start_date, end_date)) {
      return res.status(400).json({
        success: false,
        message: 'end_date must be on or after start_date.'
      });
    }
    if (!isNonNegativeNumberOrEmpty(premium)) {
      return res.status(400).json({
        success: false,
        message: 'premium must be a non-negative number.'
      });
    }

    const fields = [];
    const values = [];
    let paramIndex = 1;

    const addField = (column, value) => {
      fields.push(`${column} = $${paramIndex}`);
      values.push(value);
      paramIndex += 1;
    };

    if (company_id !== undefined) {
      addField('company_id', company_id || null);
      // Company changed -> snapshot the new company's current rate.
      fields.push(`commission_rate = (SELECT commission_rate FROM company WHERE company_id = $${paramIndex - 1})`);
    }
    if (policy_number !== undefined) addField('policy_number', policy_number);
    if (insurance_type !== undefined) addField('insurance_type', insurance_type);
    if (premium !== undefined) addField('premium', premium);
    if (start_date !== undefined) addField('start_date', start_date);
    if (end_date !== undefined) addField('end_date', end_date);
    if (renewal_status !== undefined) addField('renewal_status', renewal_status);
    if (status !== undefined) addField('status', status);
    if (notes !== undefined) addField('notes', notes);

    if (fields.length === 0) {
      return res.status(400).json({
        success: false,
        message: 'No valid fields provided for update.'
      });
    }

    values.push(id);

    const result = await db.query(
      `UPDATE policy SET ${fields.join(', ')} WHERE policy_id = $${paramIndex} RETURNING *`,
      values
    );

    if (result.rows.length === 0) {
      return res.status(404).json({
        success: false,
        message: 'Policy not found.'
      });
    }

    return res.status(200).json({
      success: true,
      message: 'Policy updated successfully.',
      data: result.rows[0]
    });
  } catch (error) {
    console.error('[policyController.updatePolicy] Error:', error.message);
    return res.status(500).json({
      success: false,
      message: 'Internal server error while updating policy.'
    });
  }
};

/**
 * DELETE /api/policies/:id
 * Protected by verifyToken + checkPolicyOwnerOrAdmin.
 */
const deletePolicy = async (req, res) => {
  try {
    const { id } = req.params;

    // Look up any attachment first so we can remove the physical file -
    // the FK's ON DELETE CASCADE will remove the policy_attachment row,
    // but it can't touch the file sitting on disk.
    const attachment = await db.query(
      'SELECT file_path FROM policy_attachment WHERE policy_id = $1',
      [id]
    );

    const result = await db.query(
      'DELETE FROM policy WHERE policy_id = $1 RETURNING policy_id',
      [id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({
        success: false,
        message: 'Policy not found.'
      });
    }

    if (attachment.rows.length > 0) {
      const filePath = path.join(UPLOAD_DIR, attachment.rows[0].file_path);
      fs.unlink(filePath, (err) => {
        if (err && err.code !== 'ENOENT') {
          console.error('[policyController.deletePolicy] Failed to remove attachment file:', err.message);
        }
      });
    }

    return res.status(200).json({
      success: true,
      message: 'Policy deleted successfully.'
    });
  } catch (error) {
    console.error('[policyController.deletePolicy] Error:', error.message);
    return res.status(500).json({
      success: false,
      message: 'Internal server error while deleting policy.'
    });
  }
};

/**
 * GET /api/policies/search-by-month
 * -----------------------------------------------------------------------
 * Supports NEW REQUIREMENT #2 (Policy Expiration Search).
 * Finds every policy whose end_date falls in a given calendar month
 * (1-12), optionally narrowed to a specific year. Sortable via
 * sort_by / sort_dir query params against a whitelist of columns to
 * avoid SQL injection through ORDER BY.
 * Admin sees all policies; an Agent sees only policies of customers
 * they own. Each row carries the owning agent so Admin can see whose job it is.
 * -----------------------------------------------------------------------
 */
const searchPoliciesByMonth = async (req, res) => {
  try {
    // month is now OPTIONAL - omitted or empty means "All Months",
    // returning every policy (still respecting the year filter/sort).
    const params = [];
    let monthClause = '';
    if (req.query.month !== undefined && req.query.month !== '') {
      const month = parseInt(req.query.month, 10);
      if (!month || month < 1 || month > 12) {
        return res.status(400).json({
          success: false,
          message: 'month must be between 1 and 12, or omitted for all months.'
        });
      }
      params.push(month);
      monthClause = `AND EXTRACT(MONTH FROM p.end_date) = $${params.length}`;
    }

    let yearClause = '';
    if (req.query.year !== undefined && req.query.year !== '') {
      const year = parseInt(req.query.year, 10);
      if (!Number.isNaN(year)) {
        params.push(year);
        yearClause = `AND EXTRACT(YEAR FROM p.end_date) = $${params.length}`;
      }
    }

    let scopeClause = '';
    const scope = searchAgentFilter(req);
    if (scope !== null) {
      params.push(scope);
      scopeClause = `AND c.agent_id = $${params.length}`;
    }

    // Whitelist maps the frontend's sort key to a safe SQL expression -
    // never interpolate req.query.sort_by directly into the query.
    const sortableColumns = {
      customer_name: 'c.first_name',
      phone: 'c.phone',
      vehicle: 'v.license_plate',
      policy_number: 'p.policy_number',
      company_name: 'co.company_name',
      end_date: 'p.end_date',
      days_remaining: 'days_remaining'
    };
    const sortColumn = sortableColumns[req.query.sort_by] || 'p.end_date';
    const sortDirection = req.query.sort_dir === 'desc' ? 'DESC' : 'ASC';

    const queryText = `
      SELECT
        p.policy_id,
        p.policy_number,
        p.insurance_type,
        p.premium,
        p.start_date,
        p.end_date,
        p.status AS policy_status,
        p.renewal_status,
        p.notes,
        (p.end_date - CURRENT_DATE) AS days_remaining,
        v.vehicle_id,
        v.license_plate,
        v.plate_province,
        v.brand AS vehicle_brand,
        v.model AS vehicle_model,
        v.production_year AS vehicle_production_year,
        v.color AS vehicle_color,
        c.customer_id,
        c.first_name AS customer_first_name,
        c.last_name AS customer_last_name,
        c.phone AS customer_phone,
        c.agent_id,
        ag.first_name AS agent_first_name,
        ag.last_name AS agent_last_name,
        co.company_id,
        co.company_name,
        pa.attachment_id,
        pa.file_name AS attachment_file_name,
        pa.uploaded_at AS attachment_uploaded_at
      FROM policy p
      INNER JOIN vehicle v   ON p.vehicle_id = v.vehicle_id
      INNER JOIN customer c  ON v.customer_id = c.customer_id
      LEFT JOIN agent ag     ON c.agent_id = ag.agent_id
      LEFT JOIN company co   ON p.company_id = co.company_id
      LEFT JOIN policy_attachment pa ON pa.policy_id = p.policy_id
      WHERE 1=1
      ${monthClause}
      ${yearClause}
      ${scopeClause}
      ORDER BY ${sortColumn} ${sortDirection}
    `;

    const result = await db.query(queryText, params);

    return res.status(200).json({
      success: true,
      count: result.rows.length,
      data: result.rows
    });
  } catch (error) {
    console.error('[policyController.searchPoliciesByMonth] Error:', error.message);
    return res.status(500).json({
      success: false,
      message: 'Internal server error while searching policies by month.'
    });
  }
};

module.exports = {
  createPolicy,
  updatePolicy,
  deletePolicy,
  searchPoliciesByMonth
};
