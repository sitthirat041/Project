/**
 * controllers/authController.js
 * -----------------------------------------------------------------------
 * Handles authentication logic: agent login, password verification via
 * bcrypt, and JWT issuance.
 * -----------------------------------------------------------------------
 */

const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const db = require('../db');
require('dotenv').config();

/**
 * POST /api/auth/login
 * Body: { username, password }
 */
const login = async (req, res) => {
  try {
    const { username, password } = req.body;

    if (!username || !password) {
      return res.status(400).json({
        success: false,
        message: 'Username and password are required.'
      });
    }

    const result = await db.query(
      `SELECT agent_id, agent_code, first_name, last_name, phone, email,
              username, password, role, status
       FROM agent
       WHERE username = $1`,
      [username]
    );

    if (result.rows.length === 0) {
      return res.status(401).json({
        success: false,
        message: 'Invalid username or password.'
      });
    }

    const agent = result.rows[0];

    if (agent.status !== 'Active') {
      return res.status(403).json({
        success: false,
        message: 'This account has been deactivated. Please contact an administrator.'
      });
    }

    const isPasswordValid = await bcrypt.compare(password, agent.password);

    if (!isPasswordValid) {
      return res.status(401).json({
        success: false,
        message: 'Invalid username or password.'
      });
    }

    const tokenPayload = {
      agent_id: agent.agent_id,
      agent_code: agent.agent_code,
      role: agent.role,
      first_name: agent.first_name,
      last_name: agent.last_name
    };

    const token = jwt.sign(tokenPayload, process.env.JWT_SECRET, {
      expiresIn: process.env.JWT_EXPIRES_IN || '8h'
    });

    return res.status(200).json({
      success: true,
      message: 'Login successful.',
      data: {
        token,
        agent: tokenPayload
      }
    });
  } catch (error) {
    console.error('[authController.login] Error:', error.message);
    return res.status(500).json({
      success: false,
      message: 'Internal server error during login.'
    });
  }
};

/**
 * GET /api/auth/me
 * Returns the currently authenticated agent's profile (based on JWT payload).
 * Protected route - requires verifyToken middleware.
 */
const getProfile = async (req, res) => {
  try {
    const result = await db.query(
      `SELECT agent_id, agent_code, first_name, last_name, phone, email,
              username, role, status
       FROM agent
       WHERE agent_id = $1`,
      [req.user.agent_id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({
        success: false,
        message: 'Agent not found.'
      });
    }

    return res.status(200).json({
      success: true,
      data: result.rows[0]
    });
  } catch (error) {
    console.error('[authController.getProfile] Error:', error.message);
    return res.status(500).json({
      success: false,
      message: 'Internal server error while fetching profile.'
    });
  }
};

module.exports = {
  login,
  getProfile
};
