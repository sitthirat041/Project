/**
 * controllers/companyController.js
 * -----------------------------------------------------------------------
 * Insurance company reference data ("master data"). Any authenticated
 * agent may list or add a company, since this is shared picklist data
 * with no per-agent ownership. Updating commission_rate is Admin-only
 * (see routes/companyRoutes.js) since it affects every agent's
 * commission figures on the Sales Dashboard (NEW REQUIREMENT #9).
 * -----------------------------------------------------------------------
 */

const db = require('../db');

/**
 * GET /api/companies
 */
const listCompanies = async (req, res) => {
  try {
    const result = await db.query(
      'SELECT company_id, company_name, phone, email, address, commission_rate FROM company ORDER BY company_name ASC'
    );

    return res.status(200).json({
      success: true,
      count: result.rows.length,
      data: result.rows
    });
  } catch (error) {
    console.error('[companyController.listCompanies] Error:', error.message);
    return res.status(500).json({
      success: false,
      message: 'Internal server error while fetching companies.'
    });
  }
};

/**
 * POST /api/companies
 */
const createCompany = async (req, res) => {
  try {
    const { company_name, phone, email, address, commission_rate } = req.body;

    if (!company_name) {
      return res.status(400).json({
        success: false,
        message: 'company_name is required.'
      });
    }

    const result = await db.query(
      `INSERT INTO company (company_name, phone, email, address, commission_rate)
       VALUES ($1, $2, $3, $4, $5)
       RETURNING *`,
      [company_name, phone || null, email || null, address || null, commission_rate ?? 0.10]
    );

    return res.status(201).json({
      success: true,
      message: 'Company added successfully.',
      data: result.rows[0]
    });
  } catch (error) {
    console.error('[companyController.createCompany] Error:', error.message);
    return res.status(500).json({
      success: false,
      message: 'Internal server error while adding company.'
    });
  }
};

/**
 * PUT /api/companies/:id
 * Admin-only (see routes/companyRoutes.js). Primarily used to set the
 * negotiated commission_rate per company for accurate Sales Dashboard
 * commission figures.
 */
const updateCompany = async (req, res) => {
  try {
    const { id } = req.params;
    const { company_name, phone, email, address, commission_rate } = req.body;

    const fields = [];
    const values = [];
    let paramIndex = 1;
    const addField = (column, value) => {
      fields.push(`${column} = $${paramIndex}`);
      values.push(value);
      paramIndex += 1;
    };

    if (company_name !== undefined) addField('company_name', company_name);
    if (phone !== undefined) addField('phone', phone);
    if (email !== undefined) addField('email', email);
    if (address !== undefined) addField('address', address);
    if (commission_rate !== undefined) addField('commission_rate', commission_rate);

    if (fields.length === 0) {
      return res.status(400).json({ success: false, message: 'No fields provided to update.' });
    }

    values.push(id);
    const result = await db.query(
      `UPDATE company SET ${fields.join(', ')} WHERE company_id = $${paramIndex} RETURNING *`,
      values
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ success: false, message: 'Company not found.' });
    }

    return res.status(200).json({
      success: true,
      message: 'Company updated successfully.',
      data: result.rows[0]
    });
  } catch (error) {
    console.error('[companyController.updateCompany] Error:', error.message);
    return res.status(500).json({
      success: false,
      message: 'Internal server error while updating company.'
    });
  }
};

module.exports = {
  listCompanies,
  createCompany,
  updateCompany
};
