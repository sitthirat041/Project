/**
 * server.js
 * -----------------------------------------------------------------------
 * Main Express application entry point.
 *  - Loads environment variables
 *  - Configures CORS and JSON body parsing
 *  - Mounts modular routers
 *  - Provides a health check endpoint
 *  - Registers 404 and global error-handling middleware
 * -----------------------------------------------------------------------
 */

require('dotenv').config();
const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const { createRateLimiter } = require('./middleware/rateLimiter');

const authRoutes = require('./routes/authRoutes');
const customerRoutes = require('./routes/customerRoutes');
const policyRoutes = require('./routes/policyRoutes');
const agentRoutes = require('./routes/agentRoutes');
const vehicleRoutes = require('./routes/vehicleRoutes');
const companyRoutes = require('./routes/companyRoutes');
const complianceRoutes = require('./routes/complianceRoutes');
const nonMotorRoutes = require('./routes/nonMotorRoutes');
const dashboardRoutes = require('./routes/dashboardRoutes');

const app = express();

// -------------------------------------------------------------------
// Global Middleware
// -------------------------------------------------------------------
// Security headers. The API serves JSON/files only (frontend is hosted
// separately), so cross-origin resource policy must allow the frontend
// origin to read responses such as attachment downloads.
app.use(helmet({ crossOriginResourcePolicy: { policy: 'cross-origin' } }));

// CORS: no wildcard fallback. In production CORS_ORIGIN MUST be set
// (comma-separated list allowed); in development it defaults to the
// local static-server origin used by the frontend.
const corsOrigin = process.env.CORS_ORIGIN
  ? process.env.CORS_ORIGIN.split(',').map((o) => o.trim())
  : null;
if (!corsOrigin && process.env.NODE_ENV === 'production') {
  console.error('[Server] FATAL: CORS_ORIGIN must be set when NODE_ENV=production.');
  process.exit(1);
}
app.use(cors({
  origin: corsOrigin || 'http://localhost:5500',
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization']
}));
// General API rate limit (login has its own stricter limiter).
app.use('/api', createRateLimiter({
  windowMs: 60 * 1000,
  max: 300,
  message: 'มีการเรียกใช้งานถี่เกินไป กรุณาลองใหม่อีกครั้งในอีกสักครู่'
}));
app.use(express.json({ limit: '1mb' }));
app.use(express.urlencoded({ extended: true }));

// -------------------------------------------------------------------
// Health check
// -------------------------------------------------------------------
app.get('/api/health', (req, res) => {
  res.status(200).json({
    success: true,
    message: 'Insurance Management System API is running.',
    timestamp: new Date().toISOString()
  });
});

// -------------------------------------------------------------------
// Routes
// -------------------------------------------------------------------
app.use('/api/auth', authRoutes);
app.use('/api/customers', customerRoutes);
app.use('/api/policies', policyRoutes);
app.use('/api/agents', agentRoutes);
app.use('/api/vehicles', vehicleRoutes);
app.use('/api/companies', companyRoutes);
app.use('/api/compliance', complianceRoutes);
app.use('/api/non-motor', nonMotorRoutes);
app.use('/api/dashboard', dashboardRoutes);

// -------------------------------------------------------------------
// 404 Handler - must come after all valid routes
// -------------------------------------------------------------------
app.use((req, res, next) => {
  res.status(404).json({
    success: false,
    message: `Route not found: ${req.method} ${req.originalUrl}`
  });
});

// -------------------------------------------------------------------
// Global Error Handling Middleware - must have 4 arguments to be
// recognized by Express as an error handler.
// -------------------------------------------------------------------
app.use((err, req, res, next) => {
  console.error('[Global Error Handler]', err.stack || err.message);

  const statusCode = err.statusCode || 500;

  res.status(statusCode).json({
    success: false,
    message: err.message || 'An unexpected internal server error occurred.'
  });
});

// -------------------------------------------------------------------
// Start Server
// -------------------------------------------------------------------
const PORT = process.env.PORT || 5000;

app.listen(PORT, () => {
  console.log(`[Server] Insurance Management System API running on port ${PORT}`);
  console.log(`[Server] Environment: ${process.env.NODE_ENV || 'development'}`);
});

module.exports = app;
