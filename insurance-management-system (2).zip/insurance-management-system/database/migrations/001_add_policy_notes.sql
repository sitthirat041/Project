-- =====================================================================
-- Migration 001: Add Notes field to policy
-- -----------------------------------------------------------------------
-- Safe to run against an existing database with data already in it —
-- uses IF NOT EXISTS so it will not error (or lose data) if it has
-- already been applied.
--
-- Run with:
--   psql -U <user> -d <database> -f database/migrations/001_add_policy_notes.sql
-- =====================================================================

ALTER TABLE policy ADD COLUMN IF NOT EXISTS notes TEXT;
