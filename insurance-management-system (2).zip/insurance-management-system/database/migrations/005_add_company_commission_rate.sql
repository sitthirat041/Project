-- =====================================================================
-- Migration 005: Company Commission Rate
-- -----------------------------------------------------------------------
-- Supports NEW REQUIREMENT #9 (Monthly/Yearly Sales Dashboard).
-- Commission is not tracked per-policy in this system; it is estimated
-- as premium * company.commission_rate, using each insurance company's
-- standard negotiated rate. Default 10% for existing companies - update
-- with real rates per company after this migration runs.
--
-- Safe to run against an existing database with data already in it.
--
-- Run with:
--   psql -U <user> -d <database> -f database/migrations/005_add_company_commission_rate.sql
-- =====================================================================

ALTER TABLE company ADD COLUMN IF NOT EXISTS commission_rate NUMERIC(5,4) NOT NULL DEFAULT 0.10;
