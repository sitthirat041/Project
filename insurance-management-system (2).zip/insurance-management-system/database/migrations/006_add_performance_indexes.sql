-- =====================================================================
-- Migration 006: Additional Performance Indexes
-- -----------------------------------------------------------------------
-- Supports NEW REQUIREMENT #11 (Database Improvements). Adds indexes on
-- columns that are frequently filtered/grouped by but weren't indexed
-- yet - identified from the queries added in Phases B, D, and E:
--   - policy.company_id / policy.status: grouped by company_id in the
--     Sales Dashboard, filtered by status in several list views
--   - non_motor_policy.status: filtered in the search endpoint
--   - vehicle_compliance.company_id: grouped by company in future
--     compliance reporting
--
-- Safe to run against an existing database with data already in it.
--
-- Run with:
--   psql -U <user> -d <database> -f database/migrations/006_add_performance_indexes.sql
-- =====================================================================

CREATE INDEX IF NOT EXISTS idx_policy_company_id ON policy(company_id);
CREATE INDEX IF NOT EXISTS idx_policy_status ON policy(status);
CREATE INDEX IF NOT EXISTS idx_non_motor_status ON non_motor_policy(status);
CREATE INDEX IF NOT EXISTS idx_vehicle_compliance_company_id ON vehicle_compliance(company_id);
