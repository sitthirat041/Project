-- =====================================================================
-- Migration 002: Policy File Attachments
-- -----------------------------------------------------------------------
-- Adds a policy_attachment table supporting a single file attachment
-- per policy (PDF, image, or DOCX). "Replace" is implemented as an
-- upsert against the UNIQUE(policy_id) constraint below, so uploading
-- again for the same policy overwrites the previous attachment record
-- (the old physical file is removed by the application layer).
--
-- Safe to run against an existing database with data already in it.
--
-- Run with:
--   psql -U <user> -d <database> -f database/migrations/002_add_policy_attachment.sql
-- =====================================================================

CREATE TABLE IF NOT EXISTS policy_attachment (
    attachment_id   SERIAL PRIMARY KEY,
    policy_id       INTEGER NOT NULL UNIQUE REFERENCES policy(policy_id) ON DELETE CASCADE,
    file_name       VARCHAR(255) NOT NULL,
    file_path       VARCHAR(500) NOT NULL,
    mime_type       VARCHAR(150),
    file_size       INTEGER,
    uploaded_at     TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_policy_attachment_policy_id ON policy_attachment(policy_id);
