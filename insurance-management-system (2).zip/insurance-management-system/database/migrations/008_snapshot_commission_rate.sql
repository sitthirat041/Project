-- 008: Snapshot commission rate on each sale.
-- Before: commission was computed from company.commission_rate at report time,
-- so changing a company's rate silently rewrote all historical commission.
-- After: the rate in force when the policy is created is stored on the policy.

ALTER TABLE policy            ADD COLUMN IF NOT EXISTS commission_rate NUMERIC(5,4);
ALTER TABLE non_motor_policy  ADD COLUMN IF NOT EXISTS commission_rate NUMERIC(5,4);

-- Backfill existing rows with the company's current rate (best available).
UPDATE policy p
   SET commission_rate = co.commission_rate
  FROM company co
 WHERE p.company_id = co.company_id AND p.commission_rate IS NULL;

UPDATE non_motor_policy nm
   SET commission_rate = co.commission_rate
  FROM company co
 WHERE nm.company_id = co.company_id AND nm.commission_rate IS NULL;
