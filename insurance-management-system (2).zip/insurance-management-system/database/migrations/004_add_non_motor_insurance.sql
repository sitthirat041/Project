-- =====================================================================
-- Migration 004: Non-Motor Insurance Module
-- -----------------------------------------------------------------------
-- Supports NEW REQUIREMENT #8. Non-motor customers (Fire, Health,
-- Personal Accident, Marine Cargo, Travel, Others) are NOT required to
-- already exist in the `customer` table - agents can capture a lead's
-- name/address/phone directly, matching the fields the spec calls for.
-- Ownership follows agent_id directly on the record (no vehicle/customer
-- chain to walk, unlike motor policies).
--
-- policy_number and premium are not explicitly listed in the spec but
-- are included because they're needed for real-world record-keeping and
-- for the Monthly/Yearly Sales Dashboard (requirement #9) to report
-- Non-Motor premium/commission alongside Motor.
--
-- Safe to run against an existing database with data already in it.
--
-- Run with:
--   psql -U <user> -d <database> -f database/migrations/004_add_non_motor_insurance.sql
-- =====================================================================

CREATE TABLE IF NOT EXISTS non_motor_policy (
    non_motor_id    SERIAL PRIMARY KEY,
    agent_id        INTEGER NOT NULL REFERENCES agent(agent_id),
    customer_name   VARCHAR(200) NOT NULL,
    address         TEXT,
    phone           VARCHAR(20),
    insurance_type  VARCHAR(30) NOT NULL CHECK (insurance_type IN
                        ('Fire', 'Health', 'Personal Accident', 'Marine Cargo', 'Travel', 'Others')),
    company_id      INTEGER REFERENCES company(company_id),
    policy_number   VARCHAR(100),
    premium         NUMERIC(10,2) DEFAULT 0,
    coverage_start  DATE,
    coverage_end    DATE NOT NULL,
    source          VARCHAR(100),
    broker          VARCHAR(150),
    direct_company  VARCHAR(150),
    status          VARCHAR(20) CHECK (status IN ('Active', 'Expired')) DEFAULT 'Active',
    notes           TEXT,
    created_at      TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_non_motor_agent_id ON non_motor_policy(agent_id);
CREATE INDEX IF NOT EXISTS idx_non_motor_coverage_end ON non_motor_policy(coverage_end);
CREATE INDEX IF NOT EXISTS idx_non_motor_customer_name ON non_motor_policy(customer_name);
CREATE INDEX IF NOT EXISTS idx_non_motor_phone ON non_motor_policy(phone);
CREATE INDEX IF NOT EXISTS idx_non_motor_insurance_type ON non_motor_policy(insurance_type);

-- One attachment slot per Non-Motor record, mirroring policy_attachment.
CREATE TABLE IF NOT EXISTS non_motor_attachment (
    attachment_id   SERIAL PRIMARY KEY,
    non_motor_id    INTEGER NOT NULL UNIQUE REFERENCES non_motor_policy(non_motor_id) ON DELETE CASCADE,
    file_name       VARCHAR(255) NOT NULL,
    file_path       VARCHAR(500) NOT NULL,
    mime_type       VARCHAR(150),
    file_size       INTEGER,
    uploaded_at     TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_non_motor_attachment_non_motor_id ON non_motor_attachment(non_motor_id);
