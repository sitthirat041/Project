-- =====================================================================
-- Migration 003: Compulsory Insurance (พรบ.) & Vehicle Tax
-- -----------------------------------------------------------------------
-- One table, discriminated by compliance_type, since พรบ. and Vehicle
-- Tax share an identical shape (Status, Start Date, Expiry Date,
-- Reminder, Company, Price, Notes) and both hang off a vehicle. Keeping
-- them in one table means a single query answers "what's expiring
-- soon" across both types for the reminder dashboard in Phase E.
--
-- Safe to run against an existing database with data already in it.
--
-- Run with:
--   psql -U <user> -d <database> -f database/migrations/003_add_vehicle_compliance.sql
-- =====================================================================

CREATE TABLE IF NOT EXISTS vehicle_compliance (
    compliance_id    SERIAL PRIMARY KEY,
    vehicle_id       INTEGER NOT NULL REFERENCES vehicle(vehicle_id) ON DELETE CASCADE,
    compliance_type  VARCHAR(30) NOT NULL CHECK (compliance_type IN ('CompulsoryInsurance', 'VehicleTax')),
    status           VARCHAR(20) CHECK (status IN ('Active', 'Expired')) DEFAULT 'Active',
    start_date       DATE,
    expiry_date      DATE NOT NULL,
    reminder         BOOLEAN NOT NULL DEFAULT TRUE,
    company_id       INTEGER REFERENCES company(company_id),
    price            NUMERIC(10,2) DEFAULT 0.00,
    notes            TEXT,
    created_at       TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_vehicle_compliance_vehicle_id ON vehicle_compliance(vehicle_id);
CREATE INDEX IF NOT EXISTS idx_vehicle_compliance_expiry_date ON vehicle_compliance(expiry_date);
CREATE INDEX IF NOT EXISTS idx_vehicle_compliance_type ON vehicle_compliance(compliance_type);
