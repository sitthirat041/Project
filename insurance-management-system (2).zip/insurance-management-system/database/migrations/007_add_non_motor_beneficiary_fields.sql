-- =====================================================================
-- Migration 007: Non-Motor Insurance - Beneficiary / Sum Insured /
--                Coverage Limit
-- -----------------------------------------------------------------------
-- All three are free-text fields per spec (not constrained to numeric),
-- since real-world sum-insured/coverage-limit entries often include
-- currency notes, ranges, or per-item breakdowns that don't fit a
-- single NUMERIC column.
--
-- Safe to run against an existing database with data already in it.
--
-- Run with:
--   psql -U <user> -d <database> -f database/migrations/007_add_non_motor_beneficiary_fields.sql
-- =====================================================================

ALTER TABLE non_motor_policy ADD COLUMN IF NOT EXISTS beneficiary VARCHAR(200);
ALTER TABLE non_motor_policy ADD COLUMN IF NOT EXISTS sum_insured VARCHAR(100);
ALTER TABLE non_motor_policy ADD COLUMN IF NOT EXISTS coverage_limit VARCHAR(100);

-- Supports searching by beneficiary alongside the existing
-- customer_name / phone / policy_number search.
CREATE INDEX IF NOT EXISTS idx_non_motor_beneficiary ON non_motor_policy(beneficiary);
