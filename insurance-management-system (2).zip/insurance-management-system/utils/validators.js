/**
 * utils/validators.js
 * -----------------------------------------------------------------------
 * Small, dependency-free request-validation helpers shared across
 * controllers (NEW REQUIREMENT #12: "Validate every request"). Extracted
 * here instead of duplicating the same date/number checks in every
 * controller that accepts a date range or a currency amount
 * (policyController, complianceController, nonMotorController).
 * -----------------------------------------------------------------------
 */

/**
 * True if endDate is on/after startDate. Either side missing means
 * there's nothing to compare, so it passes (the "required" check for
 * a field is the caller's job, not this helper's).
 */
function isValidDateOrder(startDate, endDate) {
  if (!startDate || !endDate) return true;
  return new Date(endDate) >= new Date(startDate);
}

/**
 * True if value is a non-negative number, OR the value simply wasn't
 * provided (undefined/null/''). Use this for optional currency fields
 * (premium, price) where "not provided" should not fail validation but
 * a negative number should.
 */
function isNonNegativeNumberOrEmpty(value) {
  if (value === undefined || value === null || value === '') return true;
  const num = Number(value);
  return !Number.isNaN(num) && num >= 0;
}

module.exports = { isValidDateOrder, isNonNegativeNumberOrEmpty };
