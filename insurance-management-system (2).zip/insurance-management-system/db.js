/**
 * db.js
 * -----------------------------------------------------------------------
 * PostgreSQL Connection Pool Configuration
 * Uses the `pg` package's Pool to manage a set of reusable client
 * connections. Includes centralized error handling so that an unexpected
 * disconnection of an idle client does not crash the entire Node process.
 * -----------------------------------------------------------------------
 */

const { Pool } = require('pg');
require('dotenv').config();

const pool = new Pool({
  host: process.env.DB_HOST,
  port: parseInt(process.env.DB_PORT, 10) || 5432,
  database: process.env.DB_NAME,
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  max: 20,
  idleTimeoutMillis: 30000,
  connectionTimeoutMillis: 5000
});

// Handle unexpected errors on idle clients in the pool.
// Without this handler, an error on an idle client would crash the process.
pool.on('error', (err) => {
  console.error('[DB] Unexpected error on idle PostgreSQL client:', err.message);
});

pool.on('connect', () => {
  console.log('[DB] New client connected to PostgreSQL pool.');
});

/**
 * Verifies the database connection on startup.
 * Logs a clear success/failure message but does not exit the process,
 * allowing the developer to see the error and fix the .env configuration.
 */
const testConnection = async () => {
  try {
    const client = await pool.connect();
    const result = await client.query('SELECT NOW() AS current_time');
    console.log(`[DB] PostgreSQL connected successfully at ${result.rows[0].current_time}`);
    client.release();
  } catch (err) {
    console.error('[DB] Failed to connect to PostgreSQL:', err.message);
    console.error('[DB] Please verify your .env database configuration (DB_HOST, DB_PORT, DB_NAME, DB_USER, DB_PASSWORD).');
  }
};

testConnection();

/**
 * Generic query helper.
 * Wraps pool.query so controllers can simply do: const { rows } = await db.query(text, params)
 */
const query = (text, params) => pool.query(text, params);

module.exports = {
  pool,
  query
};
