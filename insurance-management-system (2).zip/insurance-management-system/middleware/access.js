/**
 * middleware/access.js
 * -----------------------------------------------------------------------
 * VIEW-level access control (record visibility by owner).
 *
 * Rule: Admin sees everything. An Agent sees only records they own
 * (customer.agent_id / non_motor_policy.agent_id, walked up from
 * vehicle/policy/compliance). Aggregated team sales are the only
 * cross-agent data and are served by dashboardController.
 *
 * Non-owners get 404 (not 403) so the existence of another agent's
 * record is not revealed.
 * -----------------------------------------------------------------------
 */

const db = require('../db');

const isAdmin = (req) => req.user && req.user.role === 'Admin';

/**
 * agentScope(req) -> null for Admin (no filter), agent_id for Agent.
 * Controllers use it to append "AND <owner column> = $n" when non-null.
 */
const agentScope = (req) => (isAdmin(req) ? null : req.user.agent_id);

/**
 * searchAgentFilter(req) - for list/search endpoints.
 *  Agent -> always their own agent_id (query param ignored, can't be spoofed)
 *  Admin -> optional ?agent_id=N filter, otherwise null (everyone)
 */
const searchAgentFilter = (req) => {
  if (!isAdmin(req)) return req.user.agent_id;
  const n = parseInt(req.query.agent_id, 10);
  return Number.isNaN(n) ? null : n;
};

/**
 * Factory: builds a middleware that resolves the owning agent_id of
 * req.params.id with the given SQL (must return one column: agent_id)
 * and returns 404 unless the caller is Admin or the owner.
 */
const makeViewGuard = (label, sql) => async (req, res, next) => {
  try {
    const id = parseInt(req.params.id, 10);
    if (Number.isNaN(id)) {
      return res.status(400).json({ success: false, message: `Invalid ${label} id parameter.` });
    }
    const result = await db.query(sql, [id]);
    if (result.rows.length === 0 ||
        (!isAdmin(req) && result.rows[0].agent_id !== req.user.agent_id)) {
      return res.status(404).json({ success: false, message: `${label} not found.` });
    }
    return next();
  } catch (error) {
    console.error(`[access.${label}] Error:`, error.message);
    return res.status(500).json({ success: false, message: 'Internal server error while checking access.' });
  }
};

const canViewCustomer = makeViewGuard('Customer',
  'SELECT agent_id FROM customer WHERE customer_id = $1');

const canViewVehicle = makeViewGuard('Vehicle',
  `SELECT c.agent_id FROM vehicle v
   INNER JOIN customer c ON v.customer_id = c.customer_id
   WHERE v.vehicle_id = $1`);

const canViewPolicy = makeViewGuard('Policy',
  `SELECT c.agent_id FROM policy p
   INNER JOIN vehicle v ON p.vehicle_id = v.vehicle_id
   INNER JOIN customer c ON v.customer_id = c.customer_id
   WHERE p.policy_id = $1`);

const canViewNonMotor = makeViewGuard('Non-motor record',
  'SELECT agent_id FROM non_motor_policy WHERE non_motor_id = $1');

module.exports = {
  agentScope,
  searchAgentFilter,
  canViewCustomer,
  canViewVehicle,
  canViewPolicy,
  canViewNonMotor
};
