/**
 * middleware/rateLimiter.js
 * -----------------------------------------------------------------------
 * NEW REQUIREMENT #6 (Security Audit - Rate Limiting). The login
 * endpoint had no brute-force protection at all. This is a small,
 * dependency-free in-memory limiter (sliding window per client IP) -
 * enough for a single-instance deployment. If this API is ever scaled
 * horizontally across multiple instances, replace the in-memory Map
 * with a shared store (e.g. Redis) since each instance would otherwise
 * track its own counts independently.
 * -----------------------------------------------------------------------
 */

function createRateLimiter({ windowMs, max, message }) {
  const hits = new Map(); // ip -> array of hit timestamps (ms)

  // Periodic cleanup so the Map doesn't grow forever from one-off IPs.
  const cleanupTimer = setInterval(() => {
    const now = Date.now();
    for (const [ip, timestamps] of hits.entries()) {
      const recent = timestamps.filter((t) => now - t < windowMs);
      if (recent.length === 0) hits.delete(ip);
      else hits.set(ip, recent);
    }
  }, windowMs);
  cleanupTimer.unref(); // don't keep the process alive just for this

  return (req, res, next) => {
    const ip = req.ip || (req.connection && req.connection.remoteAddress) || 'unknown';
    const now = Date.now();
    const timestamps = (hits.get(ip) || []).filter((t) => now - t < windowMs);

    if (timestamps.length >= max) {
      return res.status(429).json({
        success: false,
        message: message || 'Too many requests. Please try again later.'
      });
    }

    timestamps.push(now);
    hits.set(ip, timestamps);
    next();
  };
}

module.exports = { createRateLimiter };
