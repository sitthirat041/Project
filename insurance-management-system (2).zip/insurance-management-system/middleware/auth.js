/**
 * middleware/auth.js
 * -----------------------------------------------------------------------
 * Authentication & Authorization Middleware
 *  - verifyToken: extracts and validates JWT from Authorization header
 *  - checkCustomerOwnerOrAdmin: enforces the business rule that an Agent
 *    may only modify/delete customers they own, while Admins bypass
 *    this restriction entirely.
 * -----------------------------------------------------------------------
 */

const jwt = require('jsonwebtoken');
const db = require('../db');
require('dotenv').config();

/**
 * verifyToken
 * Extracts a Bearer token from the Authorization header, verifies it
 * using JWT_SECRET, then RE-CHECKS the agent in the database so that
 * deactivated/deleted agents lose access immediately (instead of
 * keeping a valid token until it expires) and role changes take effect
 * without waiting for a new login. req.user.role / status come from the DB.
 */
const verifyToken = (req, res, next) => {
  const authHeader = req.headers['authorization'];

  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({
      success: false,
      message: 'Access denied. No token provided or invalid format. Expected "Bearer <token>".'
    });
  }

  const token = authHeader.split(' ')[1];
  if (!token) {
    return res.status(401).json({ success: false, message: 'Access denied. Token is missing.' });
  }

  jwt.verify(token, process.env.JWT_SECRET, async (err, decoded) => {
    if (err) {
      if (err.name === 'TokenExpiredError') {
        return res.status(401).json({ success: false, message: 'Token has expired. Please log in again.' });
      }
      return res.status(403).json({ success: false, message: 'Invalid token.' });
    }

    try {
      const result = await db.query(
        'SELECT agent_id, role, status FROM agent WHERE agent_id = $1',
        [decoded.agent_id]
      );
      const agent = result.rows[0];

      if (!agent || agent.status !== 'Active') {
        return res.status(401).json({
          success: false,
          message: 'This account is no longer active. Please contact an administrator.'
        });
      }

      req.user = { ...decoded, role: agent.role };
      return next();
    } catch (error) {
      console.error('[auth.verifyToken] Error:', error.message);
      return res.status(500).json({
        success: false,
        message: 'Internal server error during token verification.'
      });
    }
  });
};

/**
 * checkCustomerOwnerOrAdmin
 * Must run AFTER verifyToken (relies on req.user being set).
 * Looks up the target customer by req.params.id and verifies that
 * the requesting agent is either the owning agent or an Admin.
 */
const checkCustomerOwnerOrAdmin = async (req, res, next) => {
  try {
    const customerId = req.params.id;

    if (!customerId || isNaN(parseInt(customerId, 10))) {
      return res.status(400).json({
        success: false,
        message: 'Invalid customer id parameter.'
      });
    }

    const result = await db.query(
      'SELECT customer_id, agent_id FROM customer WHERE customer_id = $1',
      [customerId]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({
        success: false,
        message: 'Customer not found.'
      });
    }

    const customer = result.rows[0];

    const isAdmin = req.user.role === 'Admin';
    const isOwner = customer.agent_id === req.user.agent_id;

    if (!isAdmin && !isOwner) {
      return res.status(403).json({
        success: false,
        message: 'Forbidden: You do not have permission to modify this customer. Only the assigned agent or an Admin may perform this action.'
      });
    }

    // Attach for downstream controller usage if needed
    req.targetCustomer = customer;
    next();
  } catch (error) {
    return res.status(500).json({
      success: false,
      message: 'Internal server error while checking customer ownership.'
    });
  }
};

/**
 * checkAdmin
 * Must run AFTER verifyToken. Restricts a route to Admin role only.
 * Used for agent-management endpoints.
 */
const checkAdmin = (req, res, next) => {
  if (!req.user || req.user.role !== 'Admin') {
    return res.status(403).json({
      success: false,
      message: 'Forbidden: This action requires Admin privileges.'
    });
  }
  next();
};

/**
 * checkVehicleOwnerOrAdmin
 * Must run AFTER verifyToken. Looks up the target vehicle by
 * req.params.id, walks up to its owning customer's agent_id, and
 * verifies that the requesting agent is either the owner or an Admin.
 */
const checkVehicleOwnerOrAdmin = async (req, res, next) => {
  try {
    const vehicleId = req.params.id;

    if (!vehicleId || isNaN(parseInt(vehicleId, 10))) {
      return res.status(400).json({
        success: false,
        message: 'Invalid vehicle id parameter.'
      });
    }

    const result = await db.query(
      `SELECT v.vehicle_id, v.customer_id, c.agent_id
       FROM vehicle v
       INNER JOIN customer c ON v.customer_id = c.customer_id
       WHERE v.vehicle_id = $1`,
      [vehicleId]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({
        success: false,
        message: 'Vehicle not found.'
      });
    }

    const vehicle = result.rows[0];
    const isAdmin = req.user.role === 'Admin';
    const isOwner = vehicle.agent_id === req.user.agent_id;

    if (!isAdmin && !isOwner) {
      return res.status(403).json({
        success: false,
        message: 'Forbidden: You do not have permission to modify this vehicle. Only the assigned agent or an Admin may perform this action.'
      });
    }

    req.targetVehicle = vehicle;
    next();
  } catch (error) {
    return res.status(500).json({
      success: false,
      message: 'Internal server error while checking vehicle ownership.'
    });
  }
};

/**
 * checkPolicyOwnerOrAdmin
 * Must run AFTER verifyToken. Looks up the target policy by
 * req.params.id, walks up through vehicle -> customer to find the
 * owning agent_id, and verifies ownership or Admin role.
 */
const checkPolicyOwnerOrAdmin = async (req, res, next) => {
  try {
    const policyId = req.params.id;

    if (!policyId || isNaN(parseInt(policyId, 10))) {
      return res.status(400).json({
        success: false,
        message: 'Invalid policy id parameter.'
      });
    }

    const result = await db.query(
      `SELECT p.policy_id, p.vehicle_id, c.agent_id
       FROM policy p
       INNER JOIN vehicle v ON p.vehicle_id = v.vehicle_id
       INNER JOIN customer c ON v.customer_id = c.customer_id
       WHERE p.policy_id = $1`,
      [policyId]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({
        success: false,
        message: 'Policy not found.'
      });
    }

    const policy = result.rows[0];
    const isAdmin = req.user.role === 'Admin';
    const isOwner = policy.agent_id === req.user.agent_id;

    if (!isAdmin && !isOwner) {
      return res.status(403).json({
        success: false,
        message: 'Forbidden: You do not have permission to modify this policy. Only the assigned agent or an Admin may perform this action.'
      });
    }

    req.targetPolicy = policy;
    next();
  } catch (error) {
    return res.status(500).json({
      success: false,
      message: 'Internal server error while checking policy ownership.'
    });
  }
};

/**
 * checkComplianceOwnerOrAdmin
 * Must run AFTER verifyToken. Looks up the target vehicle_compliance
 * record by req.params.id, walks up through vehicle -> customer to
 * find the owning agent_id, and verifies ownership or Admin role.
 * Used for พรบ. / Vehicle Tax records (NEW REQUIREMENT #7).
 */
const checkComplianceOwnerOrAdmin = async (req, res, next) => {
  try {
    const complianceId = req.params.id;

    if (!complianceId || isNaN(parseInt(complianceId, 10))) {
      return res.status(400).json({
        success: false,
        message: 'Invalid compliance record id parameter.'
      });
    }

    const result = await db.query(
      `SELECT vc.compliance_id, vc.vehicle_id, c.agent_id
       FROM vehicle_compliance vc
       INNER JOIN vehicle v ON vc.vehicle_id = v.vehicle_id
       INNER JOIN customer c ON v.customer_id = c.customer_id
       WHERE vc.compliance_id = $1`,
      [complianceId]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({
        success: false,
        message: 'Compliance record not found.'
      });
    }

    const record = result.rows[0];
    const isAdmin = req.user.role === 'Admin';
    const isOwner = record.agent_id === req.user.agent_id;

    if (!isAdmin && !isOwner) {
      return res.status(403).json({
        success: false,
        message: 'Forbidden: You do not have permission to modify this record. Only the assigned agent or an Admin may perform this action.'
      });
    }

    req.targetCompliance = record;
    next();
  } catch (error) {
    return res.status(500).json({
      success: false,
      message: 'Internal server error while checking compliance record ownership.'
    });
  }
};

/**
 * checkNonMotorOwnerOrAdmin
 * Must run AFTER verifyToken. Non-Motor records carry agent_id directly
 * (no vehicle/customer chain to walk, unlike motor policies) - see
 * NEW REQUIREMENT #8.
 */
const checkNonMotorOwnerOrAdmin = async (req, res, next) => {
  try {
    const nonMotorId = req.params.id;

    if (!nonMotorId || isNaN(parseInt(nonMotorId, 10))) {
      return res.status(400).json({
        success: false,
        message: 'Invalid non-motor record id parameter.'
      });
    }

    const result = await db.query(
      'SELECT non_motor_id, agent_id FROM non_motor_policy WHERE non_motor_id = $1',
      [nonMotorId]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({
        success: false,
        message: 'Non-motor record not found.'
      });
    }

    const record = result.rows[0];
    const isAdmin = req.user.role === 'Admin';
    const isOwner = record.agent_id === req.user.agent_id;

    if (!isAdmin && !isOwner) {
      return res.status(403).json({
        success: false,
        message: 'Forbidden: You do not have permission to modify this record. Only the assigned agent or an Admin may perform this action.'
      });
    }

    req.targetNonMotor = record;
    next();
  } catch (error) {
    return res.status(500).json({
      success: false,
      message: 'Internal server error while checking non-motor record ownership.'
    });
  }
};

module.exports = {
  verifyToken,
  checkCustomerOwnerOrAdmin,
  checkAdmin,
  checkVehicleOwnerOrAdmin,
  checkPolicyOwnerOrAdmin,
  checkComplianceOwnerOrAdmin,
  checkNonMotorOwnerOrAdmin
};
