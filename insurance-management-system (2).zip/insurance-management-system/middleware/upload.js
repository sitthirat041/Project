/**
 * middleware/upload.js
 * -----------------------------------------------------------------------
 * Multer configuration factory for file attachment uploads. Used by:
 *  - Policy File Attachments (NEW REQUIREMENT #5)
 *  - Non-Motor Insurance Attachments (NEW REQUIREMENT #8)
 *
 * Each caller gets its own subfolder under uploads/ and its own multer
 * instance, but shares the same file-type whitelist, size limit, and
 * directory-creation logic.
 * -----------------------------------------------------------------------
 */

const multer = require('multer');
const path = require('path');
const fs = require('fs');

const BASE_UPLOAD_DIR = path.join(__dirname, '..', 'uploads');
const ALLOWED_EXTENSIONS = ['.pdf', '.jpg', '.jpeg', '.png', '.gif', '.webp', '.docx'];
const MAX_FILE_SIZE_BYTES = 15 * 1024 * 1024; // 15 MB

/**
 * createAttachmentUploader(subfolder, paramName)
 * subfolder: directory name under uploads/ (e.g. "policy-attachments")
 * paramName: the route param holding the parent record's id, used only
 *            to make generated filenames traceable (e.g. "id").
 */
function createAttachmentUploader(subfolder, paramName = 'id') {
  const uploadDir = path.join(BASE_UPLOAD_DIR, subfolder);

  if (!fs.existsSync(uploadDir)) {
    fs.mkdirSync(uploadDir, { recursive: true });
  }

  const storage = multer.diskStorage({
    destination: (req, file, cb) => cb(null, uploadDir),
    filename: (req, file, cb) => {
      const ext = path.extname(file.originalname).toLowerCase();
      const recordId = req.params[paramName] || 'unknown';
      cb(null, `${subfolder}_${recordId}_${Date.now()}${ext}`);
    }
  });

  const fileFilter = (req, file, cb) => {
    const ext = path.extname(file.originalname).toLowerCase();
    if (!ALLOWED_EXTENSIONS.includes(ext)) {
      return cb(new Error('รองรับเฉพาะไฟล์ PDF, รูปภาพ (JPG/PNG/GIF/WEBP) และ DOCX เท่านั้น'));
    }
    cb(null, true);
  };

  const uploader = multer({ storage, fileFilter, limits: { fileSize: MAX_FILE_SIZE_BYTES } });

  return { uploader, uploadDir };
}

// Policy attachments (feature #5) - kept as pre-built singletons for
// backward compatibility with existing imports.
const { uploader: uploadPolicyAttachment, uploadDir: POLICY_UPLOAD_DIR } =
  createAttachmentUploader('policy-attachments', 'id');

// Non-motor policy attachments (feature #8).
const { uploader: uploadNonMotorAttachment, uploadDir: NON_MOTOR_UPLOAD_DIR } =
  createAttachmentUploader('non-motor-attachments', 'id');

module.exports = {
  createAttachmentUploader,
  uploadPolicyAttachment,
  UPLOAD_DIR: POLICY_UPLOAD_DIR, // kept for existing imports (policyController, attachmentController)
  uploadNonMotorAttachment,
  NON_MOTOR_UPLOAD_DIR
};
