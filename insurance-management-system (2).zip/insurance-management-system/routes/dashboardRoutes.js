/**
 * routes/dashboardRoutes.js
 * -----------------------------------------------------------------------
 * Sales Dashboard (#9) and Reminder System (#10). Both are read-only
 * aggregate views - scoped per caller inside the controller (see dashboardController), unlike the old
 * view-unrestricted endpoints in this app.
 * -----------------------------------------------------------------------
 */

const express = require('express');
const router = express.Router();

const { getSalesDashboard, getReminders, getDashboardStats } = require('../controllers/dashboardController');
const { verifyToken } = require('../middleware/auth');

// GET /api/dashboard/stats - summary cards (Active Policies = Motor + Non-Motor)
router.get('/stats', verifyToken, getDashboardStats);

// GET /api/dashboard/sales?year=YYYY&month=1-12(optional)
router.get('/sales', verifyToken, getSalesDashboard);

// GET /api/dashboard/reminders
router.get('/reminders', verifyToken, getReminders);

module.exports = router;
