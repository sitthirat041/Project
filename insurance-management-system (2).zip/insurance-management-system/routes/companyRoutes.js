/**
 * routes/companyRoutes.js
 * -----------------------------------------------------------------------
 * Insurance company reference-data routes.
 * -----------------------------------------------------------------------
 */

const express = require('express');
const router = express.Router();

const { listCompanies, createCompany, updateCompany } = require('../controllers/companyController');
const { verifyToken, checkAdmin } = require('../middleware/auth');

router.get('/', verifyToken, listCompanies);
router.post('/', verifyToken, createCompany);
router.put('/:id', verifyToken, checkAdmin, updateCompany);

module.exports = router;
