/**
 * routes/vehicleRoutes.js
 * -----------------------------------------------------------------------
 * Vehicle management routes. Update/Delete require ownership or Admin.
 * -----------------------------------------------------------------------
 */

const express = require('express');
const router = express.Router();

const { createVehicle, updateVehicle, deleteVehicle } = require('../controllers/vehicleController');
const { listComplianceForVehicle } = require('../controllers/complianceController');
const { verifyToken, checkVehicleOwnerOrAdmin } = require('../middleware/auth');
const { canViewVehicle } = require('../middleware/access');

router.post('/', verifyToken, createVehicle);
router.put('/:id', verifyToken, checkVehicleOwnerOrAdmin, updateVehicle);
router.delete('/:id', verifyToken, checkVehicleOwnerOrAdmin, deleteVehicle);

// GET /api/vehicles/:id/compliance - พรบ. & Vehicle Tax records for this vehicle (NEW REQUIREMENT #7)
router.get('/:id/compliance', verifyToken, canViewVehicle, listComplianceForVehicle);

module.exports = router;
