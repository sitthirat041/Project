/**
 * routes/complianceRoutes.js
 * -----------------------------------------------------------------------
 * Compulsory Insurance (พรบ.) & Vehicle Tax mutation routes (NEW
 * REQUIREMENT #7). Listing lives under /api/vehicles/:id/compliance
 * (see routes/vehicleRoutes.js) since it's naturally vehicle-scoped;
 * create/update/delete live here since they operate on the record's
 * own id (or take vehicle_id in the body for creation).
 * -----------------------------------------------------------------------
 */

const express = require('express');
const router = express.Router();

const { createCompliance, updateCompliance, deleteCompliance, listExpiringCompliance } = require('../controllers/complianceController');
const { verifyToken, checkComplianceOwnerOrAdmin } = require('../middleware/auth');

// GET /api/compliance/expiring - พรบ./tax records expiring within 30 days
router.get('/expiring', verifyToken, listExpiringCompliance);

// POST /api/compliance - create a พรบ./tax record (ownership checked inline via vehicle_id)
router.post('/', verifyToken, createCompliance);

// PUT /api/compliance/:id - update (owner agent or Admin)
router.put('/:id', verifyToken, checkComplianceOwnerOrAdmin, updateCompliance);

// DELETE /api/compliance/:id - delete (owner agent or Admin)
router.delete('/:id', verifyToken, checkComplianceOwnerOrAdmin, deleteCompliance);

module.exports = router;
