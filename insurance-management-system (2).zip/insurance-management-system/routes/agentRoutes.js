/**
 * routes/agentRoutes.js
 * -----------------------------------------------------------------------
 * Agent management routes. All routes require Admin role.
 * -----------------------------------------------------------------------
 */

const express = require('express');
const router = express.Router();

const { listAgents, createAgent, updateAgent, deleteAgent, transferAgentWork } = require('../controllers/agentController');
const { verifyToken, checkAdmin } = require('../middleware/auth');

router.get('/', verifyToken, checkAdmin, listAgents);
router.post('/', verifyToken, checkAdmin, createAgent);
router.put('/:id', verifyToken, checkAdmin, updateAgent);
router.delete('/:id', verifyToken, checkAdmin, deleteAgent);

// POST /api/agents/:id/transfer - move all customers + non-motor records to another agent
router.post('/:id/transfer', verifyToken, checkAdmin, transferAgentWork);

module.exports = router;
