/**
 * routes/customerRoutes.js
 * -----------------------------------------------------------------------
 * Customer routes.
 * All routes require a valid JWT (verifyToken).
 * Update/Delete additionally require checkCustomerOwnerOrAdmin.
 * -----------------------------------------------------------------------
 */

const express = require('express');
const router = express.Router();

const {
  searchCustomers,
  getCustomerById,
  createCustomer,
  updateCustomer,
  deleteCustomer
} = require('../controllers/customerController');

const { verifyToken, checkCustomerOwnerOrAdmin } = require('../middleware/auth');
const { canViewCustomer } = require('../middleware/access');

// GET /api/customers/search?q=keyword - Admin & Agent can search all data
router.get('/search', verifyToken, searchCustomers);

// GET /api/customers/:id - Admin & Agent can view any customer
router.get('/:id', verifyToken, canViewCustomer, getCustomerById);

// POST /api/customers - Admin & Agent can create (auto-bound to req.user.agent_id for Agent)
router.post('/', verifyToken, createCustomer);

// PUT /api/customers/:id - Admin (any) or Agent (owner only)
router.put('/:id', verifyToken, checkCustomerOwnerOrAdmin, updateCustomer);

// DELETE /api/customers/:id - Admin (any) or Agent (owner only)
router.delete('/:id', verifyToken, checkCustomerOwnerOrAdmin, deleteCustomer);

module.exports = router;
