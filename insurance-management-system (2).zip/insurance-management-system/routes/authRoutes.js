/**
 * routes/authRoutes.js
 * -----------------------------------------------------------------------
 * Authentication routes.
 * -----------------------------------------------------------------------
 */

const express = require('express');
const router = express.Router();

const { login, getProfile } = require('../controllers/authController');
const { verifyToken } = require('../middleware/auth');
const { createRateLimiter } = require('../middleware/rateLimiter');

// Max 10 attempts per 15 minutes per IP (NEW REQUIREMENT #6: Security
// Audit - Rate Limiting). Login had no brute-force protection before.
const loginRateLimiter = createRateLimiter({
  windowMs: 15 * 60 * 1000,
  max: 10,
  message: 'พยายามเข้าสู่ระบบบ่อยเกินไป กรุณาลองใหม่อีกครั้งในอีก 15 นาที'
});

// POST /api/auth/login - public
router.post('/login', loginRateLimiter, login);

// GET /api/auth/me - protected, returns the logged-in agent's profile
router.get('/me', verifyToken, getProfile);

module.exports = router;
