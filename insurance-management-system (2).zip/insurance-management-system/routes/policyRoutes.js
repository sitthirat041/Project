/**
 * routes/policyRoutes.js
 * -----------------------------------------------------------------------
 * Policy routes. Currently exposes the "expiring soon" dashboard widget
 * endpoint. The underlying logic lives in customerController.js per the
 * project specification.
 * -----------------------------------------------------------------------
 */

const express = require('express');
const router = express.Router();

const { getExpiringPolicies } = require('../controllers/customerController');
const { createPolicy, updatePolicy, deletePolicy, searchPoliciesByMonth } = require('../controllers/policyController');
const {
  uploadAttachment, getAttachmentInfo, getAttachmentFile, deleteAttachment
} = require('../controllers/attachmentController');
const { verifyToken, checkPolicyOwnerOrAdmin } = require('../middleware/auth');
const { canViewPolicy } = require('../middleware/access');
const { uploadPolicyAttachment } = require('../middleware/upload');

// Wraps multer so file-type/size errors come back as clean 400 JSON
// responses instead of falling through to the generic 500 handler.
const handleAttachmentUpload = (req, res, next) => {
  uploadPolicyAttachment.single('file')(req, res, (err) => {
    if (err) {
      return res.status(400).json({
        success: false,
        message: err.message || 'อัปโหลดไฟล์ไม่สำเร็จ'
      });
    }
    next();
  });
};

// GET /api/policies/expiring - policies expiring within 30 days
router.get('/expiring', verifyToken, getExpiringPolicies);

// GET /api/policies/search-by-month?month=1-12&year=YYYY&sort_by=&sort_dir=
router.get('/search-by-month', verifyToken, searchPoliciesByMonth);

// POST /api/policies - create a policy for a vehicle (ownership checked inline)
router.post('/', verifyToken, createPolicy);

// PUT /api/policies/:id - update a policy (owner agent or Admin)
router.put('/:id', verifyToken, checkPolicyOwnerOrAdmin, updatePolicy);

// DELETE /api/policies/:id - delete a policy (owner agent or Admin)
router.delete('/:id', verifyToken, checkPolicyOwnerOrAdmin, deletePolicy);

// -----------------------------------------------------------------------
// Policy File Attachments (NEW REQUIREMENT #5)
// Viewing is unrestricted for any authenticated user, consistent with
// the rest of the app; mutations require ownership or Admin.
// -----------------------------------------------------------------------

// GET /api/policies/:id/attachment - metadata (file_name, uploaded_at, ...)
router.get('/:id/attachment', verifyToken, canViewPolicy, getAttachmentInfo);

// GET /api/policies/:id/attachment/file - raw file bytes (view/download)
router.get('/:id/attachment/file', verifyToken, canViewPolicy, getAttachmentFile);

// POST /api/policies/:id/attachment - upload or replace (owner agent or Admin)
router.post('/:id/attachment', verifyToken, checkPolicyOwnerOrAdmin, handleAttachmentUpload, uploadAttachment);

// DELETE /api/policies/:id/attachment - delete (owner agent or Admin)
router.delete('/:id/attachment', verifyToken, checkPolicyOwnerOrAdmin, deleteAttachment);

module.exports = router;
