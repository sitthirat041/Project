/**
 * routes/nonMotorRoutes.js
 * -----------------------------------------------------------------------
 * Non-Motor Insurance module routes (NEW REQUIREMENT #8). Viewing is
 * unrestricted for any authenticated user; create/update/delete and
 * attachment mutation require ownership (agent_id on the record) or
 * Admin, same pattern as the rest of the app.
 * -----------------------------------------------------------------------
 */

const express = require('express');
const router = express.Router();

const {
  searchNonMotor, getNonMotorById, createNonMotor, updateNonMotor, deleteNonMotor,
  uploadNonMotorAttachmentFile, getNonMotorAttachmentFile, deleteNonMotorAttachment
} = require('../controllers/nonMotorController');
const { verifyToken, checkNonMotorOwnerOrAdmin } = require('../middleware/auth');
const { canViewNonMotor } = require('../middleware/access');
const { uploadNonMotorAttachment } = require('../middleware/upload');

// Wraps multer so file-type/size errors come back as clean 400 JSON
// responses instead of falling through to the generic 500 handler.
const handleAttachmentUpload = (req, res, next) => {
  uploadNonMotorAttachment.single('file')(req, res, (err) => {
    if (err) {
      return res.status(400).json({ success: false, message: err.message || 'อัปโหลดไฟล์ไม่สำเร็จ' });
    }
    next();
  });
};

// GET /api/non-motor/search?q=&type=&status=
router.get('/search', verifyToken, searchNonMotor);

// GET /api/non-motor/:id
router.get('/:id', verifyToken, canViewNonMotor, getNonMotorById);

// POST /api/non-motor
router.post('/', verifyToken, createNonMotor);

// PUT /api/non-motor/:id - owner agent or Admin
router.put('/:id', verifyToken, checkNonMotorOwnerOrAdmin, updateNonMotor);

// DELETE /api/non-motor/:id - owner agent or Admin
router.delete('/:id', verifyToken, checkNonMotorOwnerOrAdmin, deleteNonMotor);

// -----------------------------------------------------------------------
// Attachment sub-routes (view/download/replace/delete)
// -----------------------------------------------------------------------
router.post('/:id/attachment', verifyToken, checkNonMotorOwnerOrAdmin, handleAttachmentUpload, uploadNonMotorAttachmentFile);
router.get('/:id/attachment/file', verifyToken, canViewNonMotor, getNonMotorAttachmentFile);
router.delete('/:id/attachment', verifyToken, checkNonMotorOwnerOrAdmin, deleteNonMotorAttachment);

module.exports = router;
