# Insurance Management System (FairDee) — Backend API

ระบบบริหารจัดการกรมธรรม์ประกันภัยรถยนต์ — Node.js (Express) + PostgreSQL + JWT

## 📁 Folder Structure

```
insurance-management-system/
├── controllers/
│   ├── authController.js       # Login / profile logic
│   └── customerController.js   # Search, CRUD, expiring-policies logic
├── database/
│   └── schema.sql               # PostgreSQL DDL (agent, customer, vehicle, company, policy)
├── middleware/
│   └── auth.js                  # verifyToken, checkCustomerOwnerOrAdmin
├── routes/
│   ├── authRoutes.js
│   ├── customerRoutes.js
│   └── policyRoutes.js
├── .env.example                 # Copy to .env and fill in real values
├── db.js                        # PostgreSQL pool + connection test
├── package.json
├── server.js                    # App entry point
└── README.md
```

## 🚀 Getting Started

### 1. Install dependencies
```bash
cd insurance-management-system
npm install
```

### 2. Configure environment variables
```bash
cp .env.example .env
```
Edit `.env` and set your PostgreSQL credentials and a strong `JWT_SECRET`.

### 3. Create the database & load schema
```bash
createdb insurance_management
psql -d insurance_management -f database/schema.sql
```

### 4. Create an Admin account
The schema does not seed users by default (password must be a real bcrypt
hash). Generate one quickly with Node:
```bash
node -e "console.log(require('bcryptjs').hashSync('admin1234', 10))"
```
Then insert manually:
```sql
INSERT INTO agent (agent_code, first_name, last_name, phone, email, username, password, role, status)
VALUES ('A001', 'System', 'Administrator', '0800000000', 'admin@fairdee.com',
        'admin', '<paste_generated_hash_here>', 'Admin', 'Active');
```

### 5. Run the server
```bash
npm start
# or during development
npm run dev
```
Server runs at `http://localhost:5000` (or the `PORT` set in `.env`).

## 🔑 Authentication

`POST /api/auth/login`
```json
{ "username": "admin", "password": "admin1234" }
```
Response contains a JWT — send it as `Authorization: Bearer <token>` on all
protected routes.

## 📌 API Endpoints

| Method | Endpoint                     | Auth                 | Description                                   |
|--------|-------------------------------|----------------------|------------------------------------------------|
| POST   | /api/auth/login                | Public               | Login, returns JWT                             |
| GET    | /api/auth/me                   | Token                | Current agent profile                          |
| GET    | /api/customers/search?q=       | Token                | Global search (customer/vehicle/policy)        |
| GET    | /api/customers/:id             | Token                | Customer detail incl. vehicles & policies      |
| POST   | /api/customers                 | Token                | Create customer                                |
| PUT    | /api/customers/:id             | Token + Owner/Admin  | Update customer                                |
| DELETE | /api/customers/:id             | Token + Owner/Admin  | Delete customer                                |
| GET    | /api/policies/expiring         | Token                | Policies expiring within 30 days               |
| POST   | /api/vehicles                  | Token (owner/Admin)  | Add a vehicle to a customer                    |
| PUT    | /api/vehicles/:id               | Token + Owner/Admin  | Update a vehicle                               |
| DELETE | /api/vehicles/:id               | Token + Owner/Admin  | Delete a vehicle (cascades its policies)       |
| POST   | /api/policies                  | Token (owner/Admin)  | Add a policy to a vehicle                      |
| PUT    | /api/policies/:id               | Token + Owner/Admin  | Update a policy                                |
| DELETE | /api/policies/:id               | Token + Owner/Admin  | Delete a policy                                |
| GET    | /api/companies                 | Token                | List insurance companies (reference data)      |
| POST   | /api/companies                 | Token                | Add a new insurance company                    |
| GET    | /api/agents                    | Token + Admin        | List all agents with customer counts           |
| POST   | /api/agents                    | Token + Admin        | Create a new agent/admin account               |
| PUT    | /api/agents/:id                 | Token + Admin        | Update an agent (password optional)            |
| DELETE | /api/agents/:id                 | Token + Admin        | Delete an agent (blocked if they own customers)|

## 🎨 Frontend (Step 2)

```
frontend/
├── index.html              # Redirects to login.html or dashboard.html based on token
├── login.html               # Split-screen branded login
├── dashboard.html           # Stat cards + "expiring within 30 days" widget
├── customers.html           # Global search + "add customer" modal
├── customer-detail.html     # Customer profile, vehicles/policies, edit & delete
├── agents.html               # Admin-only: manage agent/admin accounts
└── assets/
    ├── css/style.css        # Design tokens, fonts, countdown-pill component
    └── js/
        ├── api.js            # apiFetch wrapper, token/auth helpers, UI helpers
        ├── dashboard.js
        ├── customers.js
        ├── customer-detail.js  # Also handles vehicle & policy add/edit/delete modals
        └── agents.js
```


### Run the frontend
It's static HTML/JS, so any static file server works:
```bash
cd frontend
python3 -m http.server 5500
# then open http://localhost:5500


### Upgrade steps for an existing database
```bash
psql -d insurance_management -f database/migrations/008_snapshot_commission_rate.sql
npm install          # adds helmet
```
Then **rotate secrets**: generate a new `JWT_SECRET`
(`node -e "console.log(require('crypto').randomBytes(48).toString('hex'))"`) and
change the DB password - the previous `.env` / `.env.example` contained real values.
