/**
 * assets/js/api.js
 * -----------------------------------------------------------------------
 * Shared frontend utilities:
 *  - API_BASE_URL configuration
 *  - Token storage helpers (localStorage) + JWT payload decoding
 *  - apiFetch(): fetch wrapper that attaches Authorization header,
 *    parses JSON, and normalizes error handling
 *  - Route guard for protected pages
 *  - Small UI helpers: toast, days-remaining pill renderer, formatters
 * -----------------------------------------------------------------------
 */

// Change this if your backend runs on a different host/port.
const API_BASE_URL = 'http://localhost:5000/api';

/* ---------------------------------------------------------------------
   Token helpers
   --------------------------------------------------------------------- */
const TOKEN_KEY = 'happy_prakanphai_token';

function saveToken(token) {
  localStorage.setItem(TOKEN_KEY, token);
}

function getToken() {
  return localStorage.getItem(TOKEN_KEY);
}

function clearToken() {
  localStorage.removeItem(TOKEN_KEY);
}

/**
 * Decodes the JWT payload (base64url) WITHOUT verifying the signature.
 * Safe for UI-only decisions (e.g. showing/hiding buttons); the backend
 * is always the source of truth for actual authorization.
 */
function decodeToken(token) {
  try {
    const payload = token.split('.')[1];
    const base64 = payload.replace(/-/g, '+').replace(/_/g, '/');
    const json = decodeURIComponent(
      atob(base64)
        .split('')
        .map((c) => '%' + c.charCodeAt(0).toString(16).padStart(2, '0'))
        .join('')
    );
    return JSON.parse(json);
  } catch (err) {
    return null;
  }
}

function getCurrentUser() {
  const token = getToken();
  if (!token) return null;
  return decodeToken(token);
}

function logout() {
  clearToken();
  window.location.href = 'login.html';
}

/**
 * Redirects to login.html if no valid token is present.
 * Call at the top of every protected page.
 */
function requireAuth() {
  const token = getToken();
  const user = token ? decodeToken(token) : null;

  if (!token || !user || !user.exp || user.exp * 1000 < Date.now()) {
    clearToken();
    window.location.href = 'login.html';
    return null;
  }
  return user;
}

/**
 * If already logged in, skip the login page and go to the dashboard.
 */
function redirectIfAuthenticated() {
  const token = getToken();
  if (!token) return;
  const user = decodeToken(token);
  if (user && user.exp && user.exp * 1000 > Date.now()) {
    window.location.href = 'dashboard.html';
  }
}

/* ---------------------------------------------------------------------
   apiFetch — central fetch wrapper
   --------------------------------------------------------------------- */
async function apiFetch(path, options = {}) {
  const token = getToken();

  const headers = {
    'Content-Type': 'application/json',
    ...(options.headers || {})
  };

  if (token) {
    headers['Authorization'] = `Bearer ${token}`;
  }

  let response;
  try {
    response = await fetch(`${API_BASE_URL}${path}`, {
      ...options,
      headers
    });
  } catch (networkErr) {
    throw new Error('ไม่สามารถเชื่อมต่อกับเซิร์ฟเวอร์ได้ กรุณาตรวจสอบว่า Backend API กำลังทำงานอยู่');
  }

  let body = null;
  try {
    body = await response.json();
  } catch (parseErr) {
    // Response had no JSON body (e.g. plain 204)
  }

  if (response.status === 401) {
    clearToken();
    window.location.href = 'login.html';
    throw new Error((body && body.message) || 'เซสชันหมดอายุ กรุณาเข้าสู่ระบบใหม่');
  }

  if (!response.ok) {
    const message = (body && body.message) || `เกิดข้อผิดพลาด (HTTP ${response.status})`;
    const error = new Error(message);
    error.status = response.status;
    error.body = body;
    throw error;
  }

  return body;
}

/**
 * apiUpload — like apiFetch, but for multipart/form-data uploads.
 * Never sets Content-Type manually; the browser must set it (including
 * the multipart boundary) itself when the body is a FormData instance.
 */
async function apiUpload(path, formData, method = 'POST') {
  const token = getToken();
  const headers = {};
  if (token) headers['Authorization'] = `Bearer ${token}`;

  let response;
  try {
    response = await fetch(`${API_BASE_URL}${path}`, { method, headers, body: formData });
  } catch (networkErr) {
    throw new Error('ไม่สามารถเชื่อมต่อกับเซิร์ฟเวอร์ได้ กรุณาตรวจสอบว่า Backend API กำลังทำงานอยู่');
  }

  let body = null;
  try {
    body = await response.json();
  } catch (parseErr) {
    // no JSON body
  }

  if (response.status === 401) {
    clearToken();
    window.location.href = 'login.html';
    throw new Error((body && body.message) || 'เซสชันหมดอายุ กรุณาเข้าสู่ระบบใหม่');
  }

  if (!response.ok) {
    const message = (body && body.message) || `เกิดข้อผิดพลาด (HTTP ${response.status})`;
    const error = new Error(message);
    error.status = response.status;
    error.body = body;
    throw error;
  }

  return body;
}

/**
 * apiFetchBlob — fetches a binary response (e.g. a policy attachment
 * file) as a Blob, with the same auth/error handling as apiFetch.
 */
async function apiFetchBlob(path) {
  const token = getToken();
  const headers = {};
  if (token) headers['Authorization'] = `Bearer ${token}`;

  let response;
  try {
    response = await fetch(`${API_BASE_URL}${path}`, { headers });
  } catch (networkErr) {
    throw new Error('ไม่สามารถเชื่อมต่อกับเซิร์ฟเวอร์ได้ กรุณาตรวจสอบว่า Backend API กำลังทำงานอยู่');
  }

  if (response.status === 401) {
    clearToken();
    window.location.href = 'login.html';
    throw new Error('เซสชันหมดอายุ กรุณาเข้าสู่ระบบใหม่');
  }

  if (!response.ok) {
    let message = `เกิดข้อผิดพลาด (HTTP ${response.status})`;
    try {
      const body = await response.json();
      message = body.message || message;
    } catch (parseErr) {
      // response wasn't JSON either
    }
    throw new Error(message);
  }

  return response.blob();
}

/**
 * Pagination helpers (NEW REQUIREMENT #13). Lists here are typically
 * small-to-moderate for a single agency, so pagination is done
 * client-side against an already-fetched result array rather than
 * adding page/limit params to every list endpoint.
 */
function paginateArray(items, page, pageSize) {
  const totalPages = Math.max(1, Math.ceil(items.length / pageSize));
  const safePage = Math.min(Math.max(1, page), totalPages);
  const start = (safePage - 1) * pageSize;
  return {
    pageItems: items.slice(start, start + pageSize),
    page: safePage,
    totalPages,
    totalItems: items.length
  };
}

/**
 * Renders Prev / page-number / Next controls into a container element.
 * onPageChange(newPage) is called when the user picks a different page;
 * the caller owns re-rendering the list itself.
 */
function renderPaginationControls(container, page, totalPages, onPageChange) {
  if (totalPages <= 1) {
    container.innerHTML = '';
    return;
  }

  const pageNumbers = [];
  for (let p = 1; p <= totalPages; p++) {
    if (p === 1 || p === totalPages || Math.abs(p - page) <= 1) pageNumbers.push(p);
    else if (pageNumbers[pageNumbers.length - 1] !== '...') pageNumbers.push('...');
  }

  container.innerHTML = `
    <div class="flex items-center justify-center gap-1.5 py-4 flex-wrap">
      <button data-page="${page - 1}" ${page <= 1 ? 'disabled' : ''} class="pagination-btn px-2.5 py-1.5 text-xs rounded-lg border border-slate-200 disabled:opacity-40 hover:bg-slate-50">ก่อนหน้า</button>
      ${pageNumbers.map((p) => p === '...'
        ? `<span class="px-1.5 text-slate-400 text-xs">...</span>`
        : `<button data-page="${p}" class="pagination-btn w-7 h-7 text-xs rounded-lg ${p === page ? 'bg-navy text-white' : 'border border-slate-200 hover:bg-slate-50 text-slate-600'}">${p}</button>`
      ).join('')}
      <button data-page="${page + 1}" ${page >= totalPages ? 'disabled' : ''} class="pagination-btn px-2.5 py-1.5 text-xs rounded-lg border border-slate-200 disabled:opacity-40 hover:bg-slate-50">ถัดไป</button>
    </div>
  `;

  container.querySelectorAll('.pagination-btn[data-page]').forEach((btn) => {
    btn.addEventListener('click', () => onPageChange(parseInt(btn.dataset.page, 10)));
  });
}

/* ---------------------------------------------------------------------
   UI helpers
   --------------------------------------------------------------------- */

/**
 * Returns { className, label, iconTitle } for a renewal countdown pill
 * based on days_remaining and policy status.
 */
function renewalPillInfo(daysRemaining, policyStatus) {
  const days = Number(daysRemaining);

  if (policyStatus === 'Expired' || days < 0) {
    return { cls: 'pill-expired', label: 'หมดอายุแล้ว' };
  }
  if (days <= 7) {
    return { cls: 'pill-critical', label: `เหลือ ${days} วัน` };
  }
  if (days <= 30) {
    return { cls: 'pill-soon', label: `เหลือ ${days} วัน` };
  }
  return { cls: 'pill-ok', label: `เหลือ ${days} วัน` };
}

function renderPillHTML(daysRemaining, policyStatus) {
  if (daysRemaining === null || daysRemaining === undefined) {
    return '<span class="pill pill-expired"><span class="pill-dot"></span>ไม่มีกรมธรรม์</span>';
  }
  const { cls, label } = renewalPillInfo(daysRemaining, policyStatus);
  return `<span class="pill ${cls}"><span class="pill-dot"></span>${label}</span>`;
}

function formatCurrency(value) {
  const num = Number(value || 0);
  return num.toLocaleString('th-TH', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

function formatDate(dateStr) {
  if (!dateStr) return '-';
  const d = new Date(dateStr);
  if (isNaN(d.getTime())) return '-';
  return d.toLocaleDateString('th-TH', { year: 'numeric', month: 'short', day: 'numeric' });
}

function escapeHTML(str) {
  if (str === null || str === undefined) return '';
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}

/**
 * Lightweight toast notification. Container expected: <div id="toast-root">
 */
function showToast(message, type = 'info') {
  const root = document.getElementById('toast-root');
  if (!root) {
    alert(message);
    return;
  }

  const colors = {
    success: 'bg-emerald-600',
    error: 'bg-red-600',
    info: 'bg-[#0B1953]'
  };

  const toast = document.createElement('div');
  toast.className = `toast ${colors[type] || colors.info} text-white text-sm font-medium px-4 py-3 rounded-xl shadow-lg mb-2 max-w-sm`;
  toast.textContent = message;
  root.appendChild(toast);

  setTimeout(() => {
    toast.style.transition = 'opacity .25s ease';
    toast.style.opacity = '0';
    setTimeout(() => toast.remove(), 250);
  }, 3200);
}

/**
 * Mobile sidebar drawer (UX fix: on small screens the sidebar was
 * simply hidden with no way to open it - #open-sidebar-btn now slides
 * it in as an overlay with a backdrop). Runs on every page since
 * api.js is loaded everywhere; pages without a #sidebar (login, index)
 * simply skip this.
 */
document.addEventListener('DOMContentLoaded', () => {
  const sidebar = document.getElementById('sidebar');
  const backdrop = document.getElementById('sidebar-backdrop');
  const openBtn = document.getElementById('open-sidebar-btn');
  const closeBtn = document.getElementById('close-sidebar-btn');
  if (!sidebar || !openBtn) return;

  const openSidebar = () => {
    sidebar.classList.remove('-translate-x-full');
    if (backdrop) backdrop.classList.remove('hidden');
  };
  const closeSidebar = () => {
    sidebar.classList.add('-translate-x-full');
    if (backdrop) backdrop.classList.add('hidden');
  };

  openBtn.addEventListener('click', openSidebar);
  if (closeBtn) closeBtn.addEventListener('click', closeSidebar);
  if (backdrop) backdrop.addEventListener('click', closeSidebar);

  // Closing on nav-link tap keeps the drawer from staying open across
  // page loads on mobile (fresh page load resets it anyway, but this
  // avoids a flash of the open state on the outgoing page).
  sidebar.querySelectorAll('a.nav-link').forEach((link) => {
    link.addEventListener('click', closeSidebar);
  });
});


/* ---------------------------------------------------------------------
   Owner (agent) helpers - Admin sees whose job each record is and can
   filter by agent; Agents only ever receive their own records from the
   API, so these UI bits are Admin-only conveniences.
   --------------------------------------------------------------------- */
function isAdminUser(u) {
  return !!u && u.role === 'Admin';
}

/** Reveals every element marked class="admin-only hidden". */
function showAdminOnlyElements() {
  document.querySelectorAll('.admin-only').forEach((el) => el.classList.remove('hidden'));
}

/** Display name of the agent that owns a record row (several API shapes). */
function ownerNameOf(row) {
  if (row.agent_name) return row.agent_name;
  const name = `${row.agent_first_name || ''} ${row.agent_last_name || ''}`.trim();
  return name || '-';
}

/** Fills an Admin-only <select> with "all agents" + every agent. */
async function loadAgentFilterOptions(selectEl, onChange) {
  if (!selectEl) return;
  try {
    const result = await apiFetch('/agents');
    selectEl.innerHTML = '<option value="">ทุกตัวแทน</option>' + result.data
      .map((a) => `<option value="${a.agent_id}">${escapeHTML(a.first_name)} ${escapeHTML(a.last_name)} (${escapeHTML(a.agent_code)})</option>`)
      .join('');
    if (onChange) selectEl.addEventListener('change', onChange);
  } catch (err) {
    selectEl.classList.add('hidden');
  }
}
