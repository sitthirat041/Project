/**
 * assets/js/agents.js
 * -----------------------------------------------------------------------
 * Agent management page logic (Admin only). Guards the route both by
 * requiring a valid token and by checking role === 'Admin' client-side
 * (the backend's checkAdmin middleware is the real enforcement).
 * -----------------------------------------------------------------------
 */

const user = requireAuth();
let deleteTargetAgentId = null;
let transferSourceAgent = null;
let allAgents = [];

document.addEventListener('DOMContentLoaded', () => {
  if (!user) return;

  if (user.role !== 'Admin') {
    showToast('หน้านี้สำหรับผู้ดูแลระบบเท่านั้น', 'error');
    window.location.href = 'dashboard.html';
    return;
  }

  document.getElementById('sidebar-user-name').textContent = `${user.first_name} ${user.last_name}`;
  document.getElementById('sidebar-user-role').textContent = 'ผู้ดูแลระบบ';
  document.getElementById('logout-btn').addEventListener('click', logout);

  setupAgentModal();
  setupDeleteModal();
  setupTransferModal();
  loadAgents();
});

async function loadAgents() {
  const tbody = document.getElementById('agents-tbody');
  const loadingEl = document.getElementById('agents-loading');
  const emptyEl = document.getElementById('agents-empty');
  const countEl = document.getElementById('agent-count');

  tbody.innerHTML = '';
  emptyEl.classList.add('hidden');
  loadingEl.classList.remove('hidden');

  try {
    const result = await apiFetch('/agents');
    loadingEl.classList.add('hidden');
    countEl.textContent = `ทั้งหมด ${result.data.length.toLocaleString('th-TH')} คน`;

    if (result.data.length === 0) {
      emptyEl.classList.remove('hidden');
      return;
    }

    allAgents = result.data;
    tbody.innerHTML = result.data.map(renderAgentRow).join('');
    attachRowHandlers(result.data);
  } catch (err) {
    loadingEl.classList.add('hidden');
    showToast(err.message || 'ไม่สามารถโหลดรายชื่อตัวแทนได้', 'error');
  }
}

function renderAgentRow(a) {
  const roleBadge = a.role === 'Admin'
    ? '<span class="pill pill-soon"><span class="pill-dot"></span>Admin</span>'
    : '<span class="pill pill-expired"><span class="pill-dot"></span>Agent</span>';
  const statusBadge = a.status === 'Active'
    ? '<span class="pill pill-ok"><span class="pill-dot"></span>Active</span>'
    : '<span class="pill pill-expired"><span class="pill-dot"></span>Inactive</span>';

  return `
    <tr class="hover:bg-slate-50 transition-colors">
      <td class="px-5 sm:px-6 py-3.5">
        <p class="font-medium text-slate-800">${escapeHTML(a.first_name)} ${escapeHTML(a.last_name)}</p>
        <p class="text-xs text-slate-400 font-mono">${escapeHTML(a.agent_code)}</p>
      </td>
      <td class="px-4 py-3.5 text-slate-600 font-mono">${escapeHTML(a.username)}</td>
      <td class="px-4 py-3.5 text-slate-600">
        <p>${escapeHTML(a.phone || '-')}</p>
        <p class="text-xs text-slate-400">${escapeHTML(a.email || '-')}</p>
      </td>
      <td class="px-4 py-3.5">${roleBadge}</td>
      <td class="px-4 py-3.5">${statusBadge}</td>
      <td class="px-4 py-3.5 text-slate-600">
        <span class="font-mono">${a.customer_count}</span> <span class="text-xs text-slate-400">ลูกค้า</span>
        <span class="font-mono ml-2">${a.non_motor_count || 0}</span> <span class="text-xs text-slate-400">Non-Motor</span>
      </td>
      <td class="px-5 sm:px-6 py-3.5 text-right whitespace-nowrap">
        <button data-edit-id="${a.agent_id}" class="text-navy hover:text-orange-dark font-medium text-xs mr-3">แก้ไข</button>
        <button data-transfer-id="${a.agent_id}" class="text-navy hover:text-orange-dark font-medium text-xs mr-3">โอนงาน</button>
        <button data-delete-id="${a.agent_id}" class="text-red-600 hover:text-red-700 font-medium text-xs">ลบ</button>
      </td>
    </tr>
  `;
}

function attachRowHandlers(agents) {
  document.querySelectorAll('[data-edit-id]').forEach((btn) => {
    btn.addEventListener('click', () => {
      const agent = agents.find((a) => a.agent_id === parseInt(btn.dataset.editId, 10));
      if (agent) openAgentModal(agent);
    });
  });

  document.querySelectorAll('[data-transfer-id]').forEach((btn) => {
    btn.addEventListener('click', () => {
      const agent = agents.find((a) => a.agent_id === parseInt(btn.dataset.transferId, 10));
      if (agent) openTransferModal(agent);
    });
  });

  document.querySelectorAll('[data-delete-id]').forEach((btn) => {
    btn.addEventListener('click', () => {
      deleteTargetAgentId = parseInt(btn.dataset.deleteId, 10);
      document.getElementById('delete-agent-modal-backdrop').classList.remove('hidden');
    });
  });
}

/* ---------------------------------------------------------------------
   Add / Edit Modal
   --------------------------------------------------------------------- */
function setupAgentModal() {
  const backdrop = document.getElementById('agent-modal-backdrop');
  const openBtn = document.getElementById('open-add-modal-btn');
  const closeBtn = document.getElementById('close-agent-modal-btn');
  const cancelBtn = document.getElementById('cancel-agent-btn');
  const form = document.getElementById('agent-form');
  const errorEl = document.getElementById('agent-form-error');
  const submitBtn = document.getElementById('submit-agent-btn');
  const title = document.getElementById('agent-modal-title');

  openBtn.addEventListener('click', () => openAgentModal(null));
  closeBtn.addEventListener('click', closeAgentModal);
  cancelBtn.addEventListener('click', closeAgentModal);
  backdrop.addEventListener('click', (e) => { if (e.target === backdrop) closeAgentModal(); });

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    errorEl.classList.add('hidden');

    const agentId = document.getElementById('a-agent-id').value;
    const isEdit = !!agentId;
    const password = document.getElementById('a-password').value;

    if (!isEdit && !password) {
      errorEl.textContent = 'กรุณากำหนดรหัสผ่านสำหรับตัวแทนใหม่';
      errorEl.classList.remove('hidden');
      return;
    }

    const payload = {
      agent_code: document.getElementById('a-agent-code').value.trim(),
      first_name: document.getElementById('a-first-name').value.trim(),
      last_name: document.getElementById('a-last-name').value.trim(),
      phone: document.getElementById('a-phone').value.trim() || null,
      email: document.getElementById('a-email').value.trim() || null,
      username: document.getElementById('a-username').value.trim(),
      role: document.getElementById('a-role').value,
      status: document.getElementById('a-status').value
    };
    if (password) payload.password = password;

    submitBtn.disabled = true;
    submitBtn.textContent = 'กำลังบันทึก...';

    try {
      if (isEdit) {
        await apiFetch(`/agents/${agentId}`, { method: 'PUT', body: JSON.stringify(payload) });
        showToast('แก้ไขข้อมูลตัวแทนเรียบร้อยแล้ว', 'success');
      } else {
        await apiFetch('/agents', { method: 'POST', body: JSON.stringify(payload) });
        showToast('เพิ่มตัวแทนใหม่เรียบร้อยแล้ว', 'success');
      }
      closeAgentModal();
      loadAgents();
    } catch (err) {
      errorEl.textContent = err.message || 'บันทึกไม่สำเร็จ กรุณาลองใหม่';
      errorEl.classList.remove('hidden');
    } finally {
      submitBtn.disabled = false;
      submitBtn.textContent = 'บันทึก';
    }
  });

  function openAgentModal(agent) {
    form.reset();
    errorEl.classList.add('hidden');
    const passwordRequiredEl = document.getElementById('a-password-required');
    const passwordHintEl = document.getElementById('a-password-hint');

    if (agent) {
      title.textContent = 'แก้ไขข้อมูลตัวแทน';
      document.getElementById('a-agent-id').value = agent.agent_id;
      document.getElementById('a-agent-code').value = agent.agent_code;
      document.getElementById('a-first-name').value = agent.first_name;
      document.getElementById('a-last-name').value = agent.last_name;
      document.getElementById('a-phone').value = agent.phone || '';
      document.getElementById('a-email').value = agent.email || '';
      document.getElementById('a-username').value = agent.username;
      document.getElementById('a-role').value = agent.role;
      document.getElementById('a-status').value = agent.status;
      passwordRequiredEl.classList.add('hidden');
      passwordHintEl.classList.remove('hidden');
    } else {
      title.textContent = 'เพิ่มตัวแทนใหม่';
      document.getElementById('a-agent-id').value = '';
      document.getElementById('a-status').value = 'Active';
      document.getElementById('a-role').value = 'Agent';
      passwordRequiredEl.classList.remove('hidden');
      passwordHintEl.classList.add('hidden');
    }

    backdrop.classList.remove('hidden');
  }

  function closeAgentModal() {
    backdrop.classList.add('hidden');
    form.reset();
  }
}

/* ---------------------------------------------------------------------
   Delete Modal
   --------------------------------------------------------------------- */
function setupDeleteModal() {
  const backdrop = document.getElementById('delete-agent-modal-backdrop');
  const cancelBtn = document.getElementById('cancel-delete-agent-btn');
  const confirmBtn = document.getElementById('confirm-delete-agent-btn');

  cancelBtn.addEventListener('click', () => {
    backdrop.classList.add('hidden');
    deleteTargetAgentId = null;
  });
  backdrop.addEventListener('click', (e) => {
    if (e.target === backdrop) {
      backdrop.classList.add('hidden');
      deleteTargetAgentId = null;
    }
  });

  confirmBtn.addEventListener('click', async () => {
    if (!deleteTargetAgentId) return;

    confirmBtn.disabled = true;
    confirmBtn.textContent = 'กำลังลบ...';

    try {
      await apiFetch(`/agents/${deleteTargetAgentId}`, { method: 'DELETE' });
      showToast('ลบตัวแทนเรียบร้อยแล้ว', 'success');
      backdrop.classList.add('hidden');
      loadAgents();
    } catch (err) {
      showToast(err.message || 'ลบไม่สำเร็จ', 'error');
      backdrop.classList.add('hidden');
    } finally {
      confirmBtn.disabled = false;
      confirmBtn.textContent = 'ลบตัวแทน';
      deleteTargetAgentId = null;
    }
  });
}


/* ---------------------------------------------------------------------
   Transfer Work Modal - move all customers + Non-Motor records from one
   agent to another (e.g. when an agent leaves).
   --------------------------------------------------------------------- */
function openTransferModal(agent) {
  transferSourceAgent = agent;
  document.getElementById('transfer-summary').textContent =
    `จาก ${agent.first_name} ${agent.last_name} (${agent.agent_code}) — ลูกค้า ${agent.customer_count} ราย, Non-Motor ${agent.non_motor_count || 0} รายการ`;

  const targets = allAgents.filter((a) => a.agent_id !== agent.agent_id && a.status === 'Active');
  document.getElementById('transfer-target').innerHTML = targets.length === 0
    ? '<option value="">ไม่มีตัวแทนที่ใช้งานอยู่</option>'
    : targets.map((a) => `<option value="${a.agent_id}">${escapeHTML(a.first_name)} ${escapeHTML(a.last_name)} (${escapeHTML(a.agent_code)})</option>`).join('');
  document.getElementById('confirm-transfer-btn').disabled = targets.length === 0;
  document.getElementById('transfer-modal-backdrop').classList.remove('hidden');
}

function setupTransferModal() {
  const backdrop = document.getElementById('transfer-modal-backdrop');
  const confirmBtn = document.getElementById('confirm-transfer-btn');
  const close = () => { backdrop.classList.add('hidden'); transferSourceAgent = null; };

  document.getElementById('cancel-transfer-btn').addEventListener('click', close);
  backdrop.addEventListener('click', (e) => { if (e.target === backdrop) close(); });

  confirmBtn.addEventListener('click', async () => {
    const toId = parseInt(document.getElementById('transfer-target').value, 10);
    if (!transferSourceAgent || !toId) return;

    confirmBtn.disabled = true;
    confirmBtn.textContent = 'กำลังโอน...';
    try {
      const result = await apiFetch(`/agents/${transferSourceAgent.agent_id}/transfer`, {
        method: 'POST',
        body: JSON.stringify({ to_agent_id: toId })
      });
      showToast(`โอนแล้ว: ลูกค้า ${result.data.customers} ราย, Non-Motor ${result.data.non_motor} รายการ`, 'success');
      close();
      loadAgents();
    } catch (err) {
      showToast(err.message || 'โอนงานไม่สำเร็จ', 'error');
    } finally {
      confirmBtn.disabled = false;
      confirmBtn.textContent = 'ยืนยันการโอน';
    }
  });
}
