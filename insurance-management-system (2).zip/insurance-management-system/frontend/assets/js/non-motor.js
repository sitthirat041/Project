/**
 * assets/js/non-motor.js
 * -----------------------------------------------------------------------
 * Non-Motor Insurance module page (NEW REQUIREMENT #8): search/list,
 * add/edit/delete, and file attachment (view/download/replace/delete).
 * Records are independent of the `customer` table (customer_name /
 * address / phone are captured directly), and ownership follows
 * agent_id on the record itself.
 * -----------------------------------------------------------------------
 */

const user = requireAuth();
let companiesList = [];
let currentResults = [];
let pendingDeleteId = null;
let currentPage = 1;
const PAGE_SIZE = 15;

const TYPE_LABELS = {
  Fire: 'Fire (อัคคีภัย)',
  Health: 'Health (สุขภาพ)',
  'Personal Accident': 'Personal Accident (อุบัติเหตุ)',
  'Marine Cargo': 'Marine Cargo (สินค้าทางทะเล)',
  Travel: 'Travel (เดินทาง)',
  Others: 'Others (อื่นๆ)'
};

document.addEventListener('DOMContentLoaded', () => {
  if (!user) return;

  document.getElementById('sidebar-user-name').textContent = `${user.first_name} ${user.last_name}`;
  document.getElementById('sidebar-user-role').textContent = user.role === 'Admin' ? 'ผู้ดูแลระบบ' : `ตัวแทน (${user.agent_code})`;
  if (user.role === 'Admin') {
    document.getElementById('nav-agents-link').classList.remove('hidden');
    showAdminOnlyElements();
    loadAgentFilterOptions(document.getElementById('filter-agent'), () => runSearch());
  }
  document.getElementById('logout-btn').addEventListener('click', logout);

  document.getElementById('filter-form').addEventListener('submit', (e) => {
    e.preventDefault();
    runSearch();
  });

  document.getElementById('open-add-non-motor-btn').addEventListener('click', () => openNonMotorModal(null));

  setupNonMotorModal();
  setupDeleteModal();
  setupAttachmentInput();

  loadCompanies();
  runSearch();
});

async function loadCompanies() {
  try {
    const result = await apiFetch('/companies');
    companiesList = result.data;
    populateCompanySelect();
  } catch (err) {
    companiesList = [];
  }
}

function populateCompanySelect() {
  document.querySelectorAll('.company-select').forEach((select) => {
    const currentValue = select.value;
    select.innerHTML = '<option value="">- เลือกบริษัทประกัน -</option>' +
      companiesList.map((c) => `<option value="${c.company_id}">${escapeHTML(c.company_name)}</option>`).join('');
    if (currentValue) select.value = currentValue;
  });
}

/* ---------------------------------------------------------------------
   Search / list
   --------------------------------------------------------------------- */
async function runSearch() {
  const q = document.getElementById('filter-q').value.trim();
  const type = document.getElementById('filter-type').value;
  const status = document.getElementById('filter-status').value;

  const tbody = document.getElementById('results-tbody');
  const loadingEl = document.getElementById('results-loading');
  const emptyEl = document.getElementById('results-empty');
  const countEl = document.getElementById('result-count');

  tbody.innerHTML = '';
  emptyEl.classList.add('hidden');
  loadingEl.innerHTML = '<span class="spinner"></span>กำลังค้นหา...';
  loadingEl.classList.remove('hidden');
  countEl.textContent = '-';

  const params = new URLSearchParams();
  if (q) params.set('q', q);
  if (type) params.set('type', type);
  if (status) params.set('status', status);
  const agentSel = document.getElementById('filter-agent');
  if (isAdminUser(user) && agentSel && agentSel.value) params.set('agent_id', agentSel.value);

  try {
    const result = await apiFetch(`/non-motor/search?${params.toString()}`);
    currentResults = result.data;
    currentPage = 1;
    loadingEl.classList.add('hidden');
    countEl.textContent = `พบ ${currentResults.length.toLocaleString('th-TH')} รายการ`;

    if (currentResults.length === 0) {
      emptyEl.classList.remove('hidden');
      document.getElementById('results-pagination').innerHTML = '';
      return;
    }
    renderResultsPage();
  } catch (err) {
    loadingEl.classList.add('hidden');
    showToast(err.message || 'ค้นหาไม่สำเร็จ', 'error');
  }
}

function renderResultsPage() {
  const tbody = document.getElementById('results-tbody');
  const { pageItems, page, totalPages } = paginateArray(currentResults, currentPage, PAGE_SIZE);
  currentPage = page;

  tbody.innerHTML = pageItems.map(renderRow).join('');
  attachRowHandlers();

  renderPaginationControls(document.getElementById('results-pagination'), page, totalPages, (newPage) => {
    currentPage = newPage;
    renderResultsPage();
  });
}

function renderRow(row) {
  const modifyAllowed = user.role === 'Admin' || row.agent_id === user.agent_id;
  return `
    <tr class="hover:bg-slate-50 transition-colors">
      <td class="px-5 sm:px-6 py-3.5 font-medium text-slate-800">${escapeHTML(row.customer_name)}</td>
      <td class="px-4 py-3.5 font-mono text-slate-600">${escapeHTML(row.phone || '-')}</td>
      <td class="px-4 py-3.5 text-slate-600">${escapeHTML(TYPE_LABELS[row.insurance_type] || row.insurance_type)}</td>
      <td class="px-4 py-3.5 text-slate-600">${escapeHTML(row.company_name || '-')}</td>
      <td class="px-4 py-3.5 text-slate-600">${formatDate(row.coverage_end)}</td>
      <td class="px-4 py-3.5">${renderPillHTML(row.days_remaining, row.status)}</td>
      ${isAdminUser(user) ? `<td class="px-4 py-3.5 text-slate-600">${escapeHTML(ownerNameOf(row))}</td>` : ''}
      <td class="px-5 sm:px-6 py-3.5 text-right">
        <div class="flex items-center justify-end gap-3">
          <button data-view-nm="${row.non_motor_id}" class="text-navy hover:text-orange-dark font-medium text-xs">${modifyAllowed ? 'แก้ไข' : 'ดู'}</button>
          ${modifyAllowed ? `<button data-delete-nm="${row.non_motor_id}" class="text-red-600 hover:text-red-700 font-medium text-xs">ลบ</button>` : ''}
        </div>
      </td>
    </tr>
  `;
}

function attachRowHandlers() {
  document.querySelectorAll('[data-view-nm]').forEach((btn) => {
    btn.addEventListener('click', () => {
      const id = parseInt(btn.dataset.viewNm, 10);
      const record = currentResults.find((r) => r.non_motor_id === id);
      if (record) openNonMotorModal(record);
    });
  });

  document.querySelectorAll('[data-delete-nm]').forEach((btn) => {
    btn.addEventListener('click', () => {
      pendingDeleteId = parseInt(btn.dataset.deleteNm, 10);
      document.getElementById('nm-delete-modal-title').textContent = 'ยืนยันการลบกรมธรรม์';
      document.getElementById('nm-delete-modal-message').textContent = 'การลบกรมธรรม์ Non-Motor นี้ไม่สามารถย้อนกลับได้';
      document.getElementById('nm-delete-modal-backdrop').classList.remove('hidden');
    });
  });
}

/* ---------------------------------------------------------------------
   Add/Edit/View modal
   --------------------------------------------------------------------- */
let currentRecordId = null; // used by the attachment buttons

function setupNonMotorModal() {
  const backdrop = document.getElementById('non-motor-modal-backdrop');
  const closeBtn = document.getElementById('close-nm-modal-btn');
  const cancelBtn = document.getElementById('cancel-nm-btn');
  const form = document.getElementById('nm-form');
  const errorEl = document.getElementById('nm-form-error');
  const submitBtn = document.getElementById('submit-nm-btn');
  const title = document.getElementById('nm-modal-title');
  const toggleNewCompanyBtn = document.getElementById('nm-toggle-new-company-btn');
  const newCompanyRow = document.getElementById('nm-new-company-row');
  const saveNewCompanyBtn = document.getElementById('nm-save-new-company-btn');

  const close = () => { backdrop.classList.add('hidden'); form.reset(); };
  closeBtn.addEventListener('click', close);
  cancelBtn.addEventListener('click', close);
  backdrop.addEventListener('click', (e) => { if (e.target === backdrop) close(); });

  toggleNewCompanyBtn.addEventListener('click', () => newCompanyRow.classList.toggle('hidden'));

  saveNewCompanyBtn.addEventListener('click', async () => {
    const nameInput = document.getElementById('nm-new-company-name');
    const name = nameInput.value.trim();
    if (!name) return;
    saveNewCompanyBtn.disabled = true;
    saveNewCompanyBtn.textContent = '...';
    try {
      const result = await apiFetch('/companies', { method: 'POST', body: JSON.stringify({ company_name: name }) });
      companiesList.push(result.data);
      populateCompanySelect();
      document.getElementById('nm-company-id').value = result.data.company_id;
      nameInput.value = '';
      newCompanyRow.classList.add('hidden');
      showToast('เพิ่มบริษัทประกันใหม่เรียบร้อยแล้ว', 'success');
    } catch (err) {
      showToast(err.message || 'เพิ่มบริษัทไม่สำเร็จ', 'error');
    } finally {
      saveNewCompanyBtn.disabled = false;
      saveNewCompanyBtn.textContent = 'เพิ่ม';
    }
  });

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    errorEl.classList.add('hidden');

    const idValue = document.getElementById('nm-id').value;
    const isEdit = !!idValue;

    const payload = {
      customer_name: document.getElementById('nm-customer-name').value.trim(),
      address: document.getElementById('nm-address').value.trim() || null,
      phone: document.getElementById('nm-phone').value.trim() || null,
      insurance_type: document.getElementById('nm-insurance-type').value,
      company_id: document.getElementById('nm-company-id').value || null,
      policy_number: document.getElementById('nm-policy-number').value.trim() || null,
      premium: document.getElementById('nm-premium').value || 0,
      coverage_start: document.getElementById('nm-coverage-start').value || null,
      coverage_end: document.getElementById('nm-coverage-end').value,
      source: document.getElementById('nm-source').value.trim() || null,
      broker: document.getElementById('nm-broker').value.trim() || null,
      direct_company: document.getElementById('nm-direct-company').value.trim() || null,
      beneficiary: document.getElementById('nm-beneficiary').value.trim() || null,
      sum_insured: document.getElementById('nm-sum-insured').value.trim() || null,
      coverage_limit: document.getElementById('nm-coverage-limit').value.trim() || null,
      status: document.getElementById('nm-status').value,
      notes: document.getElementById('nm-notes').value.trim() || null
    };

    submitBtn.disabled = true;
    submitBtn.textContent = 'กำลังบันทึก...';

    try {
      let record;
      if (isEdit) {
        const result = await apiFetch(`/non-motor/${idValue}`, { method: 'PUT', body: JSON.stringify(payload) });
        record = result.data;
        showToast('แก้ไขกรมธรรม์เรียบร้อยแล้ว', 'success');
      } else {
        const result = await apiFetch('/non-motor', { method: 'POST', body: JSON.stringify(payload) });
        record = result.data;
        showToast('เพิ่มกรมธรรม์เรียบร้อยแล้ว', 'success');
      }
      // Now that the record exists, unlock the attachment section and
      // keep the modal open so the agent can attach a file right away.
      document.getElementById('nm-id').value = record.non_motor_id;
      currentRecordId = record.non_motor_id;
      title.textContent = 'แก้ไขกรมธรรม์ Non-Motor';
      showAttachmentSection(record);
      runSearch();
    } catch (err) {
      errorEl.textContent = err.message || 'บันทึกไม่สำเร็จ กรุณาลองใหม่';
      errorEl.classList.remove('hidden');
    } finally {
      submitBtn.disabled = false;
      submitBtn.textContent = 'บันทึก';
    }
  });
}

function openNonMotorModal(record) {
  const backdrop = document.getElementById('non-motor-modal-backdrop');
  const form = document.getElementById('nm-form');
  const title = document.getElementById('nm-modal-title');
  const errorEl = document.getElementById('nm-form-error');

  form.reset();
  errorEl.classList.add('hidden');
  document.getElementById('nm-new-company-row').classList.add('hidden');

  const modifyAllowed = !record || user.role === 'Admin' || record.agent_id === user.agent_id;
  setFormReadOnly(!modifyAllowed);

  if (record) {
    title.textContent = modifyAllowed ? 'แก้ไขกรมธรรม์ Non-Motor' : 'ดูรายละเอียดกรมธรรม์ Non-Motor';
    currentRecordId = record.non_motor_id;
    document.getElementById('nm-id').value = record.non_motor_id;
    document.getElementById('nm-customer-name').value = record.customer_name || '';
    document.getElementById('nm-address').value = record.address || '';
    document.getElementById('nm-phone').value = record.phone || '';
    document.getElementById('nm-insurance-type').value = record.insurance_type || 'Fire';
    document.getElementById('nm-company-id').value = record.company_id || '';
    document.getElementById('nm-policy-number').value = record.policy_number || '';
    document.getElementById('nm-premium').value = record.premium || '';
    document.getElementById('nm-coverage-start').value = (record.coverage_start || '').slice(0, 10);
    document.getElementById('nm-coverage-end').value = (record.coverage_end || '').slice(0, 10);
    document.getElementById('nm-source').value = record.source || '';
    document.getElementById('nm-broker').value = record.broker || '';
    document.getElementById('nm-direct-company').value = record.direct_company || '';
    document.getElementById('nm-beneficiary').value = record.beneficiary || '';
    document.getElementById('nm-sum-insured').value = record.sum_insured || '';
    document.getElementById('nm-coverage-limit').value = record.coverage_limit || '';
    document.getElementById('nm-status').value = record.status || 'Active';
    document.getElementById('nm-notes').value = record.notes || '';
    showAttachmentSection(record);
  } else {
    title.textContent = 'เพิ่มกรมธรรม์ Non-Motor';
    currentRecordId = null;
    document.getElementById('nm-id').value = '';
    document.getElementById('nm-status').value = 'Active';
    hideAttachmentSection();
  }

  document.getElementById('submit-nm-btn').classList.toggle('hidden', !modifyAllowed);

  backdrop.classList.remove('hidden');
}

function setFormReadOnly(readOnly) {
  const form = document.getElementById('nm-form');
  form.querySelectorAll('input, select, textarea, button:not(#cancel-nm-btn):not(#close-nm-modal-btn)').forEach((el) => {
    if (el.id === 'cancel-nm-btn' || el.id === 'close-nm-modal-btn') return;
    el.disabled = readOnly;
  });
}

/* ---------------------------------------------------------------------
   Attachment section (view/download/replace/delete)
   --------------------------------------------------------------------- */
function hideAttachmentSection() {
  document.getElementById('nm-attachment-section').classList.add('hidden');
  document.getElementById('nm-attachment-hint').classList.remove('hidden');
}

function showAttachmentSection(record) {
  document.getElementById('nm-attachment-section').classList.remove('hidden');
  document.getElementById('nm-attachment-hint').classList.add('hidden');

  const infoEl = document.getElementById('nm-attachment-info');
  const viewBtn = document.getElementById('nm-view-attachment-btn');
  const downloadBtn = document.getElementById('nm-download-attachment-btn');
  const deleteBtn = document.getElementById('nm-delete-attachment-btn');
  const uploadBtn = document.getElementById('nm-upload-attachment-btn');

  const hasAttachment = !!record.attachment_id;
  if (hasAttachment) {
    infoEl.textContent = `${record.attachment_file_name} (${formatDate(record.attachment_uploaded_at)})`;
    infoEl.classList.remove('text-slate-400');
    viewBtn.classList.remove('hidden');
    downloadBtn.classList.remove('hidden');
    deleteBtn.classList.remove('hidden');
    uploadBtn.textContent = 'แทนที่ไฟล์';
  } else {
    infoEl.textContent = 'ยังไม่มีไฟล์แนบ';
    infoEl.classList.add('text-slate-400');
    viewBtn.classList.add('hidden');
    downloadBtn.classList.add('hidden');
    deleteBtn.classList.add('hidden');
    uploadBtn.textContent = 'แนบไฟล์';
  }
}

function setupAttachmentInput() {
  document.getElementById('nm-upload-attachment-btn').addEventListener('click', () => {
    document.getElementById('nm-attachment-file-input').click();
  });

  document.getElementById('nm-attachment-file-input').addEventListener('change', async (e) => {
    const file = e.target.files[0];
    e.target.value = '';
    if (!file || !currentRecordId) return;

    const formData = new FormData();
    formData.append('file', file);
    try {
      const result = await apiUpload(`/non-motor/${currentRecordId}/attachment`, formData);
      showToast('บันทึกไฟล์แนบเรียบร้อยแล้ว', 'success');
      const fresh = await apiFetch(`/non-motor/${currentRecordId}`);
      showAttachmentSection(fresh.data);
      runSearch();
    } catch (err) {
      showToast(err.message || 'อัปโหลดไฟล์ไม่สำเร็จ', 'error');
    }
  });

  document.getElementById('nm-view-attachment-btn').addEventListener('click', async () => {
    if (!currentRecordId) return;
    try {
      const blob = await apiFetchBlob(`/non-motor/${currentRecordId}/attachment/file`);
      const url = URL.createObjectURL(blob);
      window.open(url, '_blank');
      setTimeout(() => URL.revokeObjectURL(url), 60000);
    } catch (err) {
      showToast(err.message || 'ไม่สามารถเปิดไฟล์ได้', 'error');
    }
  });

  document.getElementById('nm-download-attachment-btn').addEventListener('click', async () => {
    if (!currentRecordId) return;
    try {
      const blob = await apiFetchBlob(`/non-motor/${currentRecordId}/attachment/file`);
      const record = currentResults.find((r) => r.non_motor_id === currentRecordId);
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = (record && record.attachment_file_name) || 'attachment';
      document.body.appendChild(a);
      a.click();
      a.remove();
      URL.revokeObjectURL(url);
    } catch (err) {
      showToast(err.message || 'ไม่สามารถดาวน์โหลดไฟล์ได้', 'error');
    }
  });

  document.getElementById('nm-delete-attachment-btn').addEventListener('click', async () => {
    if (!currentRecordId) return;
    try {
      await apiFetch(`/non-motor/${currentRecordId}/attachment`, { method: 'DELETE' });
      showToast('ลบไฟล์แนบเรียบร้อยแล้ว', 'success');
      const fresh = await apiFetch(`/non-motor/${currentRecordId}`);
      showAttachmentSection(fresh.data);
      runSearch();
    } catch (err) {
      showToast(err.message || 'ลบไฟล์ไม่สำเร็จ', 'error');
    }
  });
}

/* ---------------------------------------------------------------------
   Delete confirm modal
   --------------------------------------------------------------------- */
function setupDeleteModal() {
  const backdrop = document.getElementById('nm-delete-modal-backdrop');
  const cancelBtn = document.getElementById('nm-delete-cancel-btn');
  const confirmBtn = document.getElementById('nm-delete-confirm-btn');

  const close = () => { backdrop.classList.add('hidden'); pendingDeleteId = null; };
  cancelBtn.addEventListener('click', close);
  backdrop.addEventListener('click', (e) => { if (e.target === backdrop) close(); });

  confirmBtn.addEventListener('click', async () => {
    if (!pendingDeleteId) return;
    confirmBtn.disabled = true;
    confirmBtn.textContent = 'กำลังลบ...';
    try {
      await apiFetch(`/non-motor/${pendingDeleteId}`, { method: 'DELETE' });
      showToast('ลบกรมธรรม์เรียบร้อยแล้ว', 'success');
      close();
      runSearch();
    } catch (err) {
      showToast(err.message || 'ลบไม่สำเร็จ', 'error');
    } finally {
      confirmBtn.disabled = false;
      confirmBtn.textContent = 'ลบ';
    }
  });
}
