/**
 * assets/js/policy-search.js
 * -----------------------------------------------------------------------
 * Policy Expiration Search page (NEW REQUIREMENT #2).
 * Filters every policy in the system by the calendar month (and
 * optionally the year) its coverage ends, and lets the agent sort the
 * results by any column. Sorting is delegated to the backend
 * (GET /api/policies/search-by-month) so it stays correct even for
 * large result sets, but we keep the current sort state client-side
 * and re-fetch on each header click.
 * -----------------------------------------------------------------------
 */

const user = requireAuth();

let currentSort = { by: 'end_date', dir: 'asc' };
let currentResults = [];
let currentPage = 1;
const PAGE_SIZE = 15;

document.addEventListener('DOMContentLoaded', () => {
  if (!user) return;

  document.getElementById('sidebar-user-name').textContent = `${user.first_name} ${user.last_name}`;
  document.getElementById('sidebar-user-role').textContent = user.role === 'Admin' ? 'ผู้ดูแลระบบ' : `ตัวแทน (${user.agent_code})`;
  if (user.role === 'Admin') {
    document.getElementById('nav-agents-link').classList.remove('hidden');
    showAdminOnlyElements();
    loadAgentFilterOptions(document.getElementById('filter-agent'), () => runSearch());
  }
  document.getElementById('logout-btn').addEventListener('click', logout);

  // Default filter is "All Months" (the HTML <select>'s first option
  // already has value="") so the page shows every expiring policy the
  // moment it loads, matching the "no month selected = return every
  // policy" requirement.

  document.getElementById('filter-form').addEventListener('submit', (e) => {
    e.preventDefault();
    runSearch();
  });

  document.querySelectorAll('.sort-th').forEach((btn) => {
    btn.addEventListener('click', () => {
      const sortKey = btn.dataset.sort;
      if (currentSort.by === sortKey) {
        currentSort.dir = currentSort.dir === 'asc' ? 'desc' : 'asc';
      } else {
        currentSort = { by: sortKey, dir: 'asc' };
      }
      updateSortIndicators();
      runSearch();
    });
  });

  updateSortIndicators();
  setupDetailsModal();
  runSearch();
});

function updateSortIndicators() {
  document.querySelectorAll('.sort-th').forEach((btn) => {
    btn.classList.remove('sort-asc', 'sort-desc');
    if (btn.dataset.sort === currentSort.by) {
      btn.classList.add(currentSort.dir === 'asc' ? 'sort-asc' : 'sort-desc');
    }
  });
}

async function runSearch() {
  const month = document.getElementById('filter-month').value;
  const year = document.getElementById('filter-year').value.trim();

  const tbody = document.getElementById('results-tbody');
  const loadingEl = document.getElementById('results-loading');
  const emptyEl = document.getElementById('results-empty');
  const countEl = document.getElementById('result-count');

  tbody.innerHTML = '';
  emptyEl.classList.add('hidden');
  loadingEl.innerHTML = '<span class="spinner"></span>กำลังค้นหา...';
  loadingEl.classList.remove('hidden');
  countEl.textContent = '-';

  const params = new URLSearchParams({
    sort_by: currentSort.by,
    sort_dir: currentSort.dir
  });
  if (month) params.set('month', month);
  if (year) params.set('year', year);
  const agentSel = document.getElementById('filter-agent');
  if (isAdminUser(user) && agentSel && agentSel.value) params.set('agent_id', agentSel.value);

  try {
    const result = await apiFetch(`/policies/search-by-month?${params.toString()}`);
    loadingEl.classList.add('hidden');

    currentResults = result.data;
    currentPage = 1;
    countEl.textContent = `พบ ${currentResults.length.toLocaleString('th-TH')} รายการ`;

    if (currentResults.length === 0) {
      emptyEl.classList.remove('hidden');
      document.getElementById('results-pagination').innerHTML = '';
      return;
    }

    renderResultsPage();
  } catch (err) {
    loadingEl.classList.add('hidden');
    showToast(err.message || 'ค้นหาไม่สำเร็จ', 'error');
  }
}

function renderResultsPage() {
  const tbody = document.getElementById('results-tbody');
  const { pageItems, page, totalPages } = paginateArray(currentResults, currentPage, PAGE_SIZE);
  currentPage = page;

  tbody.innerHTML = pageItems.map(renderRow).join('');
  attachDetailButtons();

  renderPaginationControls(document.getElementById('results-pagination'), page, totalPages, (newPage) => {
    currentPage = newPage;
    renderResultsPage();
  });
}

function renderRow(row) {
  const customerName = `${row.customer_first_name || ''} ${row.customer_last_name || ''}`.trim();
  const vehicleLabel = `${escapeHTML(row.license_plate || '-')} ${escapeHTML(row.plate_province || '')}`.trim();

  return `
    <tr class="hover:bg-slate-50 transition-colors">
      <td class="px-5 sm:px-6 py-3.5">
        <a href="customer-detail.html?id=${row.customer_id}" class="font-medium text-slate-800 hover:text-orange-dark">${escapeHTML(customerName)}</a>
      </td>
      <td class="px-4 py-3.5 font-mono text-slate-600">${escapeHTML(row.customer_phone || '-')}</td>
      <td class="px-4 py-3.5">
        <p class="font-mono text-slate-700">${vehicleLabel}</p>
        <p class="text-xs text-slate-400">${escapeHTML(row.vehicle_brand || '')} ${escapeHTML(row.vehicle_model || '')}</p>
      </td>
      <td class="px-4 py-3.5 font-mono text-slate-600">${escapeHTML(row.policy_number || '-')}</td>
      <td class="px-4 py-3.5 text-slate-600">${escapeHTML(row.company_name || '-')}</td>
      <td class="px-4 py-3.5 text-slate-600">${formatDate(row.end_date)}</td>
      <td class="px-5 sm:px-6 py-3.5">${renderPillHTML(row.days_remaining, row.policy_status)}</td>
      ${isAdminUser(user) ? `<td class="px-4 py-3.5 text-slate-600">${escapeHTML(ownerNameOf(row))}</td>` : ''}
      <td class="px-4 py-3.5 text-right">
        <button data-view-details="${row.policy_id}" class="text-navy hover:text-orange-dark font-medium text-xs">รายละเอียด →</button>
      </td>
    </tr>
  `;
}

function attachDetailButtons() {
  document.querySelectorAll('[data-view-details]').forEach((btn) => {
    btn.addEventListener('click', () => {
      const policyId = parseInt(btn.dataset.viewDetails, 10);
      const row = currentResults.find((r) => r.policy_id === policyId);
      if (row) openDetailsModal(row);
    });
  });
}

/* ---------------------------------------------------------------------
   View Details modal: Customer, Vehicle, Policy, Insurance Company,
   Coverage, Notes, Attachments (NEW REQUIREMENT: Vehicle and Policy List)
   --------------------------------------------------------------------- */
function openDetailsModal(row) {
  const customerName = `${row.customer_first_name || ''} ${row.customer_last_name || ''}`.trim();

  document.getElementById('dm-customer-name').textContent = customerName || '-';
  document.getElementById('dm-customer-phone').textContent = row.customer_phone || '-';
  document.getElementById('dm-vehicle').textContent = `${row.license_plate || '-'} ${row.plate_province || ''}`.trim();
  document.getElementById('dm-vehicle-detail').textContent =
    `${row.vehicle_brand || ''} ${row.vehicle_model || ''} ${row.vehicle_production_year ? `(${row.vehicle_production_year})` : ''}`.trim() || '-';
  document.getElementById('dm-company').textContent = row.company_name || '-';
  document.getElementById('dm-policy-number').textContent = row.policy_number || '-';
  document.getElementById('dm-insurance-type').textContent = row.insurance_type || '-';
  document.getElementById('dm-coverage').textContent = row.start_date
    ? `${formatDate(row.start_date)} - ${formatDate(row.end_date)}`
    : formatDate(row.end_date);
  document.getElementById('dm-premium').textContent = `฿${formatCurrency(row.premium)}`;
  document.getElementById('dm-notes').textContent = row.notes || '-';
  document.getElementById('dm-full-detail-link').href = `customer-detail.html?id=${row.customer_id}`;

  const infoEl = document.getElementById('dm-attachment-info');
  const viewBtn = document.getElementById('dm-view-attachment-btn');
  const downloadBtn = document.getElementById('dm-download-attachment-btn');

  if (row.attachment_id) {
    infoEl.textContent = `${row.attachment_file_name} (${formatDate(row.attachment_uploaded_at)})`;
    infoEl.classList.remove('text-slate-400');
    viewBtn.classList.remove('hidden');
    downloadBtn.classList.remove('hidden');
    viewBtn.onclick = () => viewOrDownloadAttachment(row.policy_id, row.attachment_file_name, false);
    downloadBtn.onclick = () => viewOrDownloadAttachment(row.policy_id, row.attachment_file_name, true);
  } else {
    infoEl.textContent = 'ยังไม่มีไฟล์แนบ';
    infoEl.classList.add('text-slate-400');
    viewBtn.classList.add('hidden');
    downloadBtn.classList.add('hidden');
  }

  document.getElementById('details-modal-backdrop').classList.remove('hidden');
}

async function viewOrDownloadAttachment(policyId, fileName, download) {
  try {
    const blob = await apiFetchBlob(`/policies/${policyId}/attachment/file`);
    const url = URL.createObjectURL(blob);
    if (download) {
      const a = document.createElement('a');
      a.href = url;
      a.download = fileName || 'attachment';
      document.body.appendChild(a);
      a.click();
      a.remove();
      URL.revokeObjectURL(url);
    } else {
      window.open(url, '_blank');
      setTimeout(() => URL.revokeObjectURL(url), 60000);
    }
  } catch (err) {
    showToast(err.message || 'ไม่สามารถเปิดไฟล์ได้', 'error');
  }
}

function setupDetailsModal() {
  const backdrop = document.getElementById('details-modal-backdrop');
  const closeBtn = document.getElementById('close-details-modal-btn');
  const close = () => backdrop.classList.add('hidden');
  closeBtn.addEventListener('click', close);
  backdrop.addEventListener('click', (e) => { if (e.target === backdrop) close(); });
}
