/**
 * assets/js/customers.js
 * -----------------------------------------------------------------------
 * Customers search page logic: guards the route, runs global search
 * (customer/vehicle/policy), renders results, and handles the
 * "add customer" modal.
 * -----------------------------------------------------------------------
 */

const user = requireAuth();

document.addEventListener('DOMContentLoaded', () => {
  if (!user) return;

  document.getElementById('sidebar-user-name').textContent = `${user.first_name} ${user.last_name}`;
  document.getElementById('sidebar-user-role').textContent = user.role === 'Admin' ? 'ผู้ดูแลระบบ' : `ตัวแทน (${user.agent_code})`;
  if (user.role === 'Admin') {
    document.getElementById('nav-agents-link').classList.remove('hidden');
    showAdminOnlyElements();
    loadAgentFilterOptions(document.getElementById('filter-agent'),
      () => runSearch(document.getElementById('search-input').value.trim()));
  }
  document.getElementById('logout-btn').addEventListener('click', logout);

  const params = new URLSearchParams(window.location.search);
  const initialQuery = params.get('q') || '';
  document.getElementById('search-input').value = initialQuery;

  document.getElementById('search-form').addEventListener('submit', (e) => {
    e.preventDefault();
    const q = document.getElementById('search-input').value.trim();
    const url = new URL(window.location.href);
    url.searchParams.set('q', q);
    window.history.replaceState({}, '', url);
    runSearch(q);
  });

  setupAddCustomerModal();

  runSearch(initialQuery);
});

async function runSearch(query) {
  const tbody = document.getElementById('results-tbody');
  const loadingEl = document.getElementById('results-loading');
  const emptyEl = document.getElementById('results-empty');
  const countEl = document.getElementById('result-count');

  tbody.innerHTML = '';
  emptyEl.classList.add('hidden');
  loadingEl.classList.remove('hidden');
  countEl.textContent = '-';

  try {
    const agentSel = document.getElementById('filter-agent');
    const agentParam = isAdminUser(user) && agentSel && agentSel.value ? `&agent_id=${encodeURIComponent(agentSel.value)}` : '';
    const result = await apiFetch(`/customers/search?q=${encodeURIComponent(query)}${agentParam}`);
    loadingEl.classList.add('hidden');

    countEl.textContent = `พบ ${result.data.length.toLocaleString('th-TH')} รายการ`;

    if (result.data.length === 0) {
      emptyEl.classList.remove('hidden');
      return;
    }

    tbody.innerHTML = result.data.map(renderRow).join('');
  } catch (err) {
    loadingEl.classList.add('hidden');
    showToast(err.message || 'ค้นหาไม่สำเร็จ', 'error');
  }
}

function renderRow(row) {
  const customerName = `${row.customer_first_name || ''} ${row.customer_last_name || ''}`.trim();
  const agentName = ownerNameOf(row);
  const statusHTML = row.policy_id
    ? renderPillHTML(row.days_remaining, row.policy_status)
    : '<span class="pill pill-expired"><span class="pill-dot"></span>ยังไม่มีกรมธรรม์</span>';

  return `
    <tr class="hover:bg-slate-50 transition-colors">
      <td class="px-5 sm:px-6 py-3.5">
        <p class="font-medium text-slate-800">${escapeHTML(row.title || '')} ${escapeHTML(customerName)}</p>
      </td>
      <td class="px-4 py-3.5 font-mono text-slate-600">${escapeHTML(row.customer_phone || '-')}</td>
      <td class="px-4 py-3.5 font-mono text-slate-700">${escapeHTML(row.license_plate || '-')}</td>
      <td class="px-4 py-3.5 text-slate-600">${escapeHTML(row.company_name || '-')}</td>
      <td class="px-4 py-3.5 font-mono text-slate-600">${escapeHTML(row.policy_number || '-')}</td>
      ${isAdminUser(user) ? `<td class="px-4 py-3.5 text-slate-600">${escapeHTML(agentName)}</td>` : ''}
      <td class="px-4 py-3.5">${statusHTML}</td>
      <td class="px-5 sm:px-6 py-3.5 text-right">
        <a href="customer-detail.html?id=${row.customer_id}" class="text-navy hover:text-orange-dark font-medium text-xs">ดูรายละเอียด →</a>
      </td>
    </tr>
  `;
}

/* ---------------------------------------------------------------------
   Add Customer Modal
   --------------------------------------------------------------------- */
function setupAddCustomerModal() {
  const backdrop = document.getElementById('add-modal-backdrop');
  const openBtn = document.getElementById('open-add-modal-btn');
  const closeBtn = document.getElementById('close-add-modal-btn');
  const cancelBtn = document.getElementById('cancel-add-btn');
  const form = document.getElementById('add-customer-form');
  const errorEl = document.getElementById('add-error');
  const submitBtn = document.getElementById('submit-add-btn');

  const openModal = () => {
    backdrop.classList.remove('hidden');
    errorEl.classList.add('hidden');
  };
  const closeModal = () => {
    backdrop.classList.add('hidden');
    form.reset();
  };

  openBtn.addEventListener('click', openModal);
  closeBtn.addEventListener('click', closeModal);
  cancelBtn.addEventListener('click', closeModal);
  backdrop.addEventListener('click', (e) => {
    if (e.target === backdrop) closeModal();
  });

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    errorEl.classList.add('hidden');

    const payload = {
      title: document.getElementById('c-title').value || null,
      first_name: document.getElementById('c-first-name').value.trim(),
      last_name: document.getElementById('c-last-name').value.trim(),
      phone: document.getElementById('c-phone').value.trim(),
      line_id: document.getElementById('c-line-id').value.trim() || null,
      email: document.getElementById('c-email').value.trim() || null,
      occupation: document.getElementById('c-occupation').value.trim() || null,
      address: document.getElementById('c-address').value.trim() || null
    };

    submitBtn.disabled = true;
    submitBtn.textContent = 'กำลังบันทึก...';

    try {
      await apiFetch('/customers', {
        method: 'POST',
        body: JSON.stringify(payload)
      });

      showToast('เพิ่มลูกค้าใหม่เรียบร้อยแล้ว', 'success');
      closeModal();
      runSearch(document.getElementById('search-input').value.trim());
    } catch (err) {
      errorEl.textContent = err.message || 'บันทึกไม่สำเร็จ กรุณาลองใหม่';
      errorEl.classList.remove('hidden');
    } finally {
      submitBtn.disabled = false;
      submitBtn.textContent = 'บันทึกลูกค้า';
    }
  });
}
