/**
 * assets/js/customer-detail.js
 * -----------------------------------------------------------------------
 * Customer detail page logic: fetches a single customer with vehicles &
 * policies, renders the profile and vehicle cards, and wires up the
 * edit/delete flows. Action buttons are shown only when the current
 * agent owns the customer or is an Admin (UI convenience only — the
 * backend's checkCustomerOwnerOrAdmin middleware is the real gate).
 * -----------------------------------------------------------------------
 */

const user = requireAuth();
let currentCustomer = null;
let companiesList = [];

const customerId = new URLSearchParams(window.location.search).get('id');

document.addEventListener('DOMContentLoaded', () => {
  if (!user) return;

  document.getElementById('sidebar-user-name').textContent = `${user.first_name} ${user.last_name}`;
  document.getElementById('sidebar-user-role').textContent = user.role === 'Admin' ? 'ผู้ดูแลระบบ' : `ตัวแทน (${user.agent_code})`;
  if (user.role === 'Admin') {
    document.getElementById('nav-agents-link').classList.remove('hidden');
  }
  document.getElementById('logout-btn').addEventListener('click', logout);

  if (!customerId) {
    showToast('ไม่พบรหัสลูกค้าที่ต้องการเปิดดู', 'error');
    window.location.href = 'customers.html';
    return;
  }

  setupEditModal();
  setupGenericDeleteModal();
  setupVehicleModal();
  setupPolicyModal();
  setupComplianceModal();
  setupAttachmentUploadInput();
  loadCompanies();
  loadCustomer();
});

async function loadCompanies() {
  try {
    const result = await apiFetch('/companies');
    companiesList = result.data;
    populateCompanySelect();
  } catch (err) {
    // Non-fatal: the policy form will simply show an empty company list.
    companiesList = [];
  }
}

function populateCompanySelect() {
  document.querySelectorAll('.company-select').forEach((select) => {
    const currentValue = select.value;
    select.innerHTML = '<option value="">- เลือกบริษัทประกัน -</option>' +
      companiesList.map((c) => `<option value="${c.company_id}">${escapeHTML(c.company_name)}</option>`).join('');
    if (currentValue) select.value = currentValue;
  });
}

async function loadCustomer() {
  const loadingEl = document.getElementById('loading-state');
  const contentEl = document.getElementById('content-state');

  loadingEl.classList.remove('hidden');
  contentEl.classList.add('hidden');

  try {
    const result = await apiFetch(`/customers/${customerId}`);
    currentCustomer = result.data;
    renderCustomer(currentCustomer);
    loadingEl.classList.add('hidden');
    contentEl.classList.remove('hidden');
  } catch (err) {
    loadingEl.classList.add('hidden');
    showToast(err.message || 'ไม่พบข้อมูลลูกค้ารายนี้', 'error');
    setTimeout(() => { window.location.href = 'customers.html'; }, 1200);
  }
}

function canModify(customer) {
  return user.role === 'Admin' || customer.agent_id === user.agent_id;
}

function renderCustomer(c) {
  const fullName = `${c.first_name} ${c.last_name}`;
  const initials = `${c.first_name?.[0] || ''}${c.last_name?.[0] || ''}`.toUpperCase();

  document.getElementById('customer-avatar').textContent = initials || '?';
  document.getElementById('customer-name').textContent = `${c.title || ''} ${fullName}`.trim();
  document.getElementById('customer-meta').textContent = `รหัสลูกค้า #${c.customer_id} · เพิ่มเมื่อ ${formatDate(c.created_at)}`;

  document.getElementById('info-phone').textContent = c.phone || '-';
  document.getElementById('info-line').textContent = c.line_id || '-';
  document.getElementById('info-email').textContent = c.email || '-';
  document.getElementById('info-occupation').textContent = c.occupation || '-';
  document.getElementById('info-address').textContent = c.address || '-';
  document.getElementById('info-agent').textContent = c.agent_first_name
    ? `${c.agent_first_name} ${c.agent_last_name} (${c.agent_code})`
    : 'ยังไม่มีตัวแทนผู้ดูแล';

  const ownerBadge = document.getElementById('owner-badge');
  const isOwner = c.agent_id === user.agent_id;
  if (user.role === 'Admin') {
    ownerBadge.className = 'pill pill-ok';
    ownerBadge.innerHTML = '<span class="pill-dot"></span>สิทธิ์ผู้ดูแลระบบ';
  } else if (isOwner) {
    ownerBadge.className = 'pill pill-ok';
    ownerBadge.innerHTML = '<span class="pill-dot"></span>ลูกค้าของฉัน';
  } else {
    ownerBadge.className = 'pill pill-expired';
    ownerBadge.innerHTML = '<span class="pill-dot"></span>ดูอย่างเดียว';
  }

  const modifyAllowed = canModify(c);
  document.getElementById('action-buttons').classList.toggle('hidden', !modifyAllowed);
  document.getElementById('open-add-vehicle-btn').classList.toggle('hidden', !modifyAllowed);

  renderVehicles(c.vehicles || [], modifyAllowed);
}

function renderVehicles(vehicles, modifyAllowed) {
  const listEl = document.getElementById('vehicles-list');
  const emptyEl = document.getElementById('vehicles-empty');

  if (vehicles.length === 0) {
    listEl.innerHTML = '';
    emptyEl.classList.remove('hidden');
    return;
  }

  emptyEl.classList.add('hidden');

  listEl.innerHTML = vehicles.map((v) => {
    const hasPolicy = !!v.policy_id;
    const pillHTML = hasPolicy
      ? renderPillHTML(v.days_remaining, v.policy_status)
      : '<span class="pill pill-expired"><span class="pill-dot"></span>ยังไม่มีกรมธรรม์</span>';

    const vehicleActionsHTML = modifyAllowed ? `
      <div class="flex items-center gap-3 mt-1">
        <button data-edit-vehicle="${v.vehicle_id}" class="text-navy hover:text-orange-dark font-medium text-xs">แก้ไขรถ</button>
        <button data-delete-vehicle="${v.vehicle_id}" class="text-red-600 hover:text-red-700 font-medium text-xs">ลบรถ</button>
      </div>
    ` : '';

    const policyActionsHTML = modifyAllowed ? (
      hasPolicy
        ? `<div class="flex items-center gap-3">
             <button data-edit-policy="${v.policy_id}" class="text-navy hover:text-orange-dark font-medium text-xs">แก้ไขกรมธรรม์</button>
             <button data-delete-policy="${v.policy_id}" class="text-red-600 hover:text-red-700 font-medium text-xs">ลบกรมธรรม์</button>
           </div>`
        : `<button data-add-policy-vehicle="${v.vehicle_id}" class="btn-secondary px-3 py-1.5 text-xs">+ เพิ่มกรมธรรม์</button>`
    ) : '';

    return `
      <div class="card p-5">
        <div class="flex items-start justify-between flex-wrap gap-3 mb-3">
          <div class="flex items-center gap-3">
            <div class="w-10 h-10 rounded-lg bg-[#F1F5F9] flex items-center justify-center shrink-0">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#0B1953" stroke-width="1.8"><path d="M3 13l1.5-5A2 2 0 016.4 6.5h11.2A2 2 0 0119.5 8l1.5 5"/><path d="M3 13h18v4a1 1 0 01-1 1h-1a1 1 0 01-1-1v-1H6v1a1 1 0 01-1 1H4a1 1 0 01-1-1v-4z"/><circle cx="7" cy="17.5" r="1.2"/><circle cx="17" cy="17.5" r="1.2"/></svg>
            </div>
            <div>
              <p class="font-mono font-semibold text-slate-800">${escapeHTML(v.license_plate)} <span class="text-slate-400 font-normal">${escapeHTML(v.plate_province || '')}</span></p>
              <p class="text-xs text-slate-400">${escapeHTML(v.vehicle_brand)} ${escapeHTML(v.vehicle_model)} · ${escapeHTML(String(v.production_year || '-'))} · ${escapeHTML(v.color || '-')}</p>
            </div>
          </div>
          <div class="flex flex-col items-end gap-1.5">
            ${pillHTML}
            ${vehicleActionsHTML}
          </div>
        </div>

        ${hasPolicy ? `
        <div class="grid sm:grid-cols-3 lg:grid-cols-6 gap-4 pt-4 border-t border-slate-100 text-sm">
          <div>
            <p class="text-xs text-slate-400 mb-1">บริษัทประกัน</p>
            <p class="font-medium text-slate-700">${escapeHTML(v.company_name || '-')}</p>
          </div>
          <div>
            <p class="text-xs text-slate-400 mb-1">เลขกรมธรรม์</p>
            <p class="font-medium text-slate-700 font-mono">${escapeHTML(v.policy_number || '-')}</p>
          </div>
          <div>
            <p class="text-xs text-slate-400 mb-1">ประเภทประกัน</p>
            <p class="font-medium text-slate-700">${escapeHTML(v.insurance_type || '-')}</p>
          </div>
          <div>
            <p class="text-xs text-slate-400 mb-1">เบี้ยประกัน</p>
            <p class="font-medium text-slate-700 font-mono">฿${formatCurrency(v.premium)}</p>
          </div>
          <div>
            <p class="text-xs text-slate-400 mb-1">วันที่คุ้มครอง</p>
            <p class="font-medium text-slate-700">${formatDate(v.start_date)} - ${formatDate(v.end_date)}</p>
          </div>
          <div>
            <p class="text-xs text-slate-400 mb-1">สถานะต่ออายุ</p>
            <p class="font-medium text-slate-700">${escapeHTML(translateRenewalStatus(v.renewal_status))}</p>
          </div>
        </div>
        ${v.notes ? `
        <div class="mt-3 pt-3 border-t border-slate-100">
          <p class="text-xs text-slate-400 mb-1">หมายเหตุ</p>
          <p class="text-sm text-slate-600 whitespace-pre-line">${escapeHTML(v.notes)}</p>
        </div>` : ''}
        ${renderAttachmentSectionHTML(v, modifyAllowed)}
        ` : ''}

        ${policyActionsHTML ? `<div class="flex justify-end pt-3 ${hasPolicy ? '' : 'border-t border-slate-100 mt-3'}">${policyActionsHTML}</div>` : ''}

        ${renderComplianceSectionHTML(v, modifyAllowed)}
      </div>
    `;
  }).join('');

  attachVehicleCardHandlers(vehicles);
}

/* ---------------------------------------------------------------------
   Policy File Attachment section (NEW REQUIREMENT #5)
   --------------------------------------------------------------------- */
function renderAttachmentSectionHTML(v, modifyAllowed) {
  const hasAttachment = !!v.attachment_id;

  const infoHTML = hasAttachment
    ? `<p class="text-sm text-slate-700">${escapeHTML(v.attachment_file_name)}
         <span class="text-slate-400 text-xs">(${formatFileSize(v.attachment_file_size)} · ${formatDate(v.attachment_uploaded_at)})</span></p>`
    : `<p class="text-sm text-slate-400">ยังไม่มีไฟล์แนบ</p>`;

  const viewDownloadHTML = hasAttachment ? `
    <button data-view-attachment="${v.policy_id}" class="text-navy hover:text-orange-dark font-medium text-xs">ดู</button>
    <button data-download-attachment="${v.policy_id}" class="text-navy hover:text-orange-dark font-medium text-xs">ดาวน์โหลด</button>
  ` : '';

  const manageHTML = modifyAllowed ? `
    <button data-upload-attachment="${v.policy_id}" class="text-navy hover:text-orange-dark font-medium text-xs">${hasAttachment ? 'แทนที่ไฟล์' : 'แนบไฟล์'}</button>
    ${hasAttachment ? `<button data-delete-attachment="${v.policy_id}" class="text-red-600 hover:text-red-700 font-medium text-xs">ลบไฟล์</button>` : ''}
  ` : '';

  return `
    <div class="mt-3 pt-3 border-t border-slate-100 flex items-center justify-between flex-wrap gap-2">
      <div>
        <p class="text-xs text-slate-400 mb-1">ไฟล์แนบกรมธรรม์</p>
        ${infoHTML}
      </div>
      <div class="flex items-center gap-3 shrink-0">
        ${viewDownloadHTML}
        ${manageHTML}
      </div>
    </div>
  `;
}

function formatFileSize(bytes) {
  const num = Number(bytes || 0);
  if (num < 1024) return `${num} B`;
  if (num < 1024 * 1024) return `${(num / 1024).toFixed(1)} KB`;
  return `${(num / (1024 * 1024)).toFixed(1)} MB`;
}

/* ---------------------------------------------------------------------
   พรบ. / Vehicle Tax section (NEW REQUIREMENT #7)
   Shows the most recent record of each type (v.compliance is already
   sorted newest-expiry-first by the backend) with Add/Edit/Delete.
   --------------------------------------------------------------------- */
const COMPLIANCE_TYPES = [
  { key: 'CompulsoryInsurance', label: 'พรบ.' },
  { key: 'VehicleTax', label: 'ภาษีรถยนต์' }
];

function renderComplianceSectionHTML(v, modifyAllowed) {
  const rowsHTML = COMPLIANCE_TYPES.map(({ key, label }) => {
    const record = (v.compliance || []).find((c) => c.compliance_type === key);

    const statusHTML = record
      ? `${renderPillHTML(record.days_remaining, record.status)}<span class="text-xs text-slate-400">หมดอายุ ${formatDate(record.expiry_date)}</span>`
      : `<span class="text-xs text-slate-400">ยังไม่มีข้อมูล</span>`;

    const actionsHTML = modifyAllowed ? `
      <button data-edit-compliance="${v.vehicle_id}|${key}" class="text-navy hover:text-orange-dark text-xs font-medium">${record ? 'แก้ไข' : '+ เพิ่ม'}</button>
      ${record ? `<button data-delete-compliance="${record.compliance_id}" class="text-red-600 hover:text-red-700 text-xs font-medium">ลบ</button>` : ''}
    ` : '';

    return `
      <div class="flex items-center justify-between gap-2 flex-wrap">
        <div class="flex items-center gap-2">
          <span class="text-xs font-medium text-slate-600 w-20 shrink-0">${label}</span>
          ${statusHTML}
        </div>
        <div class="flex items-center gap-3">${actionsHTML}</div>
      </div>
    `;
  }).join('');

  return `
    <div class="mt-3 pt-3 border-t border-slate-100">
      <p class="text-xs text-slate-400 mb-2">พรบ. และภาษีรถยนต์</p>
      <div class="space-y-2">${rowsHTML}</div>
    </div>
  `;
}

function attachVehicleCardHandlers(vehicles) {
  document.querySelectorAll('[data-edit-vehicle]').forEach((btn) => {
    btn.addEventListener('click', () => {
      const vehicle = vehicles.find((v) => v.vehicle_id === parseInt(btn.dataset.editVehicle, 10));
      if (vehicle) openVehicleModal(vehicle);
    });
  });

  document.querySelectorAll('[data-delete-vehicle]').forEach((btn) => {
    btn.addEventListener('click', () => {
      const vehicleId = parseInt(btn.dataset.deleteVehicle, 10);
      openConfirmModal({
        title: 'ยืนยันการลบรถยนต์',
        message: 'การลบรถยนต์คันนี้จะลบกรมธรรม์ที่ผูกอยู่ทั้งหมดด้วย และไม่สามารถย้อนกลับได้',
        confirmLabel: 'ลบรถยนต์',
        onConfirm: async () => {
          await apiFetch(`/vehicles/${vehicleId}`, { method: 'DELETE' });
          showToast('ลบรถยนต์เรียบร้อยแล้ว', 'success');
          loadCustomer();
        }
      });
    });
  });

  document.querySelectorAll('[data-add-policy-vehicle]').forEach((btn) => {
    btn.addEventListener('click', () => {
      openPolicyModal(null, parseInt(btn.dataset.addPolicyVehicle, 10));
    });
  });

  document.querySelectorAll('[data-edit-policy]').forEach((btn) => {
    btn.addEventListener('click', () => {
      const vehicle = vehicles.find((v) => v.policy_id === parseInt(btn.dataset.editPolicy, 10));
      if (vehicle) openPolicyModal(vehicle, vehicle.vehicle_id);
    });
  });

  document.querySelectorAll('[data-delete-policy]').forEach((btn) => {
    btn.addEventListener('click', () => {
      const policyId = parseInt(btn.dataset.deletePolicy, 10);
      openConfirmModal({
        title: 'ยืนยันการลบกรมธรรม์',
        message: 'การลบกรมธรรม์นี้ไม่สามารถย้อนกลับได้',
        confirmLabel: 'ลบกรมธรรม์',
        onConfirm: async () => {
          await apiFetch(`/policies/${policyId}`, { method: 'DELETE' });
          showToast('ลบกรมธรรม์เรียบร้อยแล้ว', 'success');
          loadCustomer();
        }
      });
    });
  });

  document.querySelectorAll('[data-view-attachment]').forEach((btn) => {
    btn.addEventListener('click', () => viewAttachment(parseInt(btn.dataset.viewAttachment, 10)));
  });

  document.querySelectorAll('[data-download-attachment]').forEach((btn) => {
    btn.addEventListener('click', () => {
      const policy = vehicles.find((v) => v.policy_id === parseInt(btn.dataset.downloadAttachment, 10));
      downloadAttachment(parseInt(btn.dataset.downloadAttachment, 10), policy ? policy.attachment_file_name : 'attachment');
    });
  });

  document.querySelectorAll('[data-upload-attachment]').forEach((btn) => {
    btn.addEventListener('click', () => triggerAttachmentUpload(parseInt(btn.dataset.uploadAttachment, 10)));
  });

  document.querySelectorAll('[data-delete-attachment]').forEach((btn) => {
    btn.addEventListener('click', () => {
      const policyId = parseInt(btn.dataset.deleteAttachment, 10);
      openConfirmModal({
        title: 'ยืนยันการลบไฟล์แนบ',
        message: 'การลบไฟล์แนบนี้ไม่สามารถย้อนกลับได้',
        confirmLabel: 'ลบไฟล์',
        onConfirm: async () => {
          await apiFetch(`/policies/${policyId}/attachment`, { method: 'DELETE' });
          showToast('ลบไฟล์แนบเรียบร้อยแล้ว', 'success');
          loadCustomer();
        }
      });
    });
  });

  document.querySelectorAll('[data-edit-compliance]').forEach((btn) => {
    btn.addEventListener('click', () => {
      const [vehicleIdStr, type] = btn.dataset.editCompliance.split('|');
      const vehicleId = parseInt(vehicleIdStr, 10);
      const vehicle = vehicles.find((v) => v.vehicle_id === vehicleId);
      const record = vehicle ? (vehicle.compliance || []).find((c) => c.compliance_type === type) : null;
      window.openComplianceModal(vehicleId, type, record || null);
    });
  });

  document.querySelectorAll('[data-delete-compliance]').forEach((btn) => {
    btn.addEventListener('click', () => {
      const complianceId = parseInt(btn.dataset.deleteCompliance, 10);
      openConfirmModal({
        title: 'ยืนยันการลบข้อมูล',
        message: 'การลบข้อมูลนี้ไม่สามารถย้อนกลับได้',
        confirmLabel: 'ลบ',
        onConfirm: async () => {
          await apiFetch(`/compliance/${complianceId}`, { method: 'DELETE' });
          showToast('ลบข้อมูลเรียบร้อยแล้ว', 'success');
          loadCustomer();
        }
      });
    });
  });
}

/**
 * viewAttachment / downloadAttachment fetch the file as a Blob (carrying
 * the Authorization header, since a plain <a href> or window.open can't
 * attach custom headers) and hand it to the browser as an object URL.
 */
async function viewAttachment(policyId) {
  try {
    const blob = await apiFetchBlob(`/policies/${policyId}/attachment/file`);
    const url = URL.createObjectURL(blob);
    window.open(url, '_blank');
    setTimeout(() => URL.revokeObjectURL(url), 60000);
  } catch (err) {
    showToast(err.message || 'ไม่สามารถเปิดไฟล์ได้', 'error');
  }
}

async function downloadAttachment(policyId, fileName) {
  try {
    const blob = await apiFetchBlob(`/policies/${policyId}/attachment/file`);
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = fileName || 'attachment';
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
  } catch (err) {
    showToast(err.message || 'ไม่สามารถดาวน์โหลดไฟล์ได้', 'error');
  }
}

let pendingAttachmentPolicyId = null;

function triggerAttachmentUpload(policyId) {
  pendingAttachmentPolicyId = policyId;
  document.getElementById('attachment-file-input').click();
}

function setupAttachmentUploadInput() {
  const input = document.getElementById('attachment-file-input');
  input.addEventListener('change', async () => {
    const file = input.files[0];
    input.value = ''; // allow re-selecting the same file later
    if (!file || !pendingAttachmentPolicyId) return;

    const formData = new FormData();
    formData.append('file', file);

    try {
      await apiUpload(`/policies/${pendingAttachmentPolicyId}/attachment`, formData);
      showToast('บันทึกไฟล์แนบเรียบร้อยแล้ว', 'success');
      loadCustomer();
    } catch (err) {
      showToast(err.message || 'อัปโหลดไฟล์ไม่สำเร็จ', 'error');
    } finally {
      pendingAttachmentPolicyId = null;
    }
  });
}

function translateRenewalStatus(status) {
  const map = { Pending: 'รอดำเนินการ', Renewed: 'ต่ออายุแล้ว', 'Not Renewed': 'ไม่ต่ออายุ' };
  return map[status] || status || '-';
}

/* ---------------------------------------------------------------------
   Edit Modal
   --------------------------------------------------------------------- */
function setupEditModal() {
  const backdrop = document.getElementById('edit-modal-backdrop');
  const openBtn = document.getElementById('edit-customer-btn');
  const closeBtn = document.getElementById('close-edit-modal-btn');
  const cancelBtn = document.getElementById('cancel-edit-btn');
  const form = document.getElementById('edit-customer-form');
  const errorEl = document.getElementById('edit-error');
  const submitBtn = document.getElementById('submit-edit-btn');

  const openModal = () => {
    if (!currentCustomer) return;
    document.getElementById('e-title').value = currentCustomer.title || '';
    document.getElementById('e-first-name').value = currentCustomer.first_name || '';
    document.getElementById('e-last-name').value = currentCustomer.last_name || '';
    document.getElementById('e-phone').value = currentCustomer.phone || '';
    document.getElementById('e-line-id').value = currentCustomer.line_id || '';
    document.getElementById('e-email').value = currentCustomer.email || '';
    document.getElementById('e-occupation').value = currentCustomer.occupation || '';
    document.getElementById('e-address').value = currentCustomer.address || '';
    errorEl.classList.add('hidden');
    backdrop.classList.remove('hidden');
  };
  const closeModal = () => backdrop.classList.add('hidden');

  openBtn.addEventListener('click', openModal);
  closeBtn.addEventListener('click', closeModal);
  cancelBtn.addEventListener('click', closeModal);
  backdrop.addEventListener('click', (e) => { if (e.target === backdrop) closeModal(); });

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    errorEl.classList.add('hidden');

    const payload = {
      title: document.getElementById('e-title').value || null,
      first_name: document.getElementById('e-first-name').value.trim(),
      last_name: document.getElementById('e-last-name').value.trim(),
      phone: document.getElementById('e-phone').value.trim(),
      line_id: document.getElementById('e-line-id').value.trim() || null,
      email: document.getElementById('e-email').value.trim() || null,
      occupation: document.getElementById('e-occupation').value.trim() || null,
      address: document.getElementById('e-address').value.trim() || null
    };

    submitBtn.disabled = true;
    submitBtn.textContent = 'กำลังบันทึก...';

    try {
      await apiFetch(`/customers/${customerId}`, {
        method: 'PUT',
        body: JSON.stringify(payload)
      });

      showToast('บันทึกการแก้ไขเรียบร้อยแล้ว', 'success');
      closeModal();
      loadCustomer();
    } catch (err) {
      errorEl.textContent = err.message || 'บันทึกไม่สำเร็จ กรุณาลองใหม่';
      errorEl.classList.remove('hidden');
    } finally {
      submitBtn.disabled = false;
      submitBtn.textContent = 'บันทึกการแก้ไข';
    }
  });
}

/* ---------------------------------------------------------------------
   Generic Delete Confirm Modal
   Reused for deleting the customer, a vehicle, or a policy — the caller
   supplies title/message/confirmLabel and an async onConfirm callback.
   --------------------------------------------------------------------- */
let pendingConfirmAction = null;

function setupGenericDeleteModal() {
  const backdrop = document.getElementById('delete-modal-backdrop');
  const cancelBtn = document.getElementById('cancel-delete-btn');
  const confirmBtn = document.getElementById('confirm-delete-btn');

  cancelBtn.addEventListener('click', () => closeConfirmModal());
  backdrop.addEventListener('click', (e) => { if (e.target === backdrop) closeConfirmModal(); });

  confirmBtn.addEventListener('click', async () => {
    if (!pendingConfirmAction) return;

    const originalLabel = confirmBtn.textContent;
    confirmBtn.disabled = true;
    confirmBtn.textContent = 'กำลังลบ...';

    try {
      await pendingConfirmAction();
      closeConfirmModal();
    } catch (err) {
      showToast(err.message || 'ลบไม่สำเร็จ กรุณาลองใหม่', 'error');
      closeConfirmModal();
    } finally {
      confirmBtn.disabled = false;
      confirmBtn.textContent = originalLabel;
    }
  });

  // Wire the customer delete button (on the page topbar) to this generic modal.
  document.getElementById('delete-customer-btn').addEventListener('click', () => {
    openConfirmModal({
      title: 'ยืนยันการลบลูกค้า',
      message: 'การลบจะลบข้อมูลรถยนต์และกรมธรรม์ของลูกค้ารายนี้ทั้งหมด และไม่สามารถย้อนกลับได้',
      confirmLabel: 'ลบลูกค้า',
      onConfirm: async () => {
        await apiFetch(`/customers/${customerId}`, { method: 'DELETE' });
        showToast('ลบข้อมูลลูกค้าเรียบร้อยแล้ว', 'success');
        setTimeout(() => { window.location.href = 'customers.html'; }, 800);
      }
    });
  });
}

function openConfirmModal({ title, message, confirmLabel, onConfirm }) {
  document.getElementById('delete-modal-title').textContent = title;
  document.getElementById('delete-modal-message').textContent = message;
  document.getElementById('confirm-delete-btn').textContent = confirmLabel;
  pendingConfirmAction = onConfirm;
  document.getElementById('delete-modal-backdrop').classList.remove('hidden');
}

function closeConfirmModal() {
  document.getElementById('delete-modal-backdrop').classList.add('hidden');
  pendingConfirmAction = null;
}

/* ---------------------------------------------------------------------
   Add / Edit Vehicle Modal
   --------------------------------------------------------------------- */
function setupVehicleModal() {
  const backdrop = document.getElementById('vehicle-modal-backdrop');
  const openBtn = document.getElementById('open-add-vehicle-btn');
  const closeBtn = document.getElementById('close-vehicle-modal-btn');
  const cancelBtn = document.getElementById('cancel-vehicle-btn');
  const form = document.getElementById('vehicle-form');
  const errorEl = document.getElementById('vehicle-form-error');
  const submitBtn = document.getElementById('submit-vehicle-btn');
  const title = document.getElementById('vehicle-modal-title');

  openBtn.addEventListener('click', () => openVehicleModal(null));
  closeBtn.addEventListener('click', closeVehicleModal);
  cancelBtn.addEventListener('click', closeVehicleModal);
  backdrop.addEventListener('click', (e) => { if (e.target === backdrop) closeVehicleModal(); });

  function openVehicleModalInner(vehicle) {
    form.reset();
    errorEl.classList.add('hidden');

    if (vehicle) {
      title.textContent = 'แก้ไขข้อมูลรถยนต์';
      document.getElementById('v-vehicle-id').value = vehicle.vehicle_id;
      document.getElementById('v-license-plate').value = vehicle.license_plate || '';
      document.getElementById('v-plate-province').value = vehicle.plate_province || '';
      document.getElementById('v-brand').value = vehicle.brand || '';
      document.getElementById('v-model').value = vehicle.model || '';
      document.getElementById('v-production-year').value = vehicle.production_year || '';
      document.getElementById('v-color').value = vehicle.color || '';
      document.getElementById('v-chassis-no').value = vehicle.chassis_no || '';
      document.getElementById('v-engine-no').value = vehicle.engine_no || '';
    } else {
      title.textContent = 'เพิ่มรถยนต์';
      document.getElementById('v-vehicle-id').value = '';
    }

    backdrop.classList.remove('hidden');
  }
  window.openVehicleModal = openVehicleModalInner;

  function closeVehicleModal() {
    backdrop.classList.add('hidden');
    form.reset();
  }

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    errorEl.classList.add('hidden');

    const vehicleIdValue = document.getElementById('v-vehicle-id').value;
    const isEdit = !!vehicleIdValue;

    const payload = {
      license_plate: document.getElementById('v-license-plate').value.trim(),
      plate_province: document.getElementById('v-plate-province').value.trim(),
      brand: document.getElementById('v-brand').value.trim(),
      model: document.getElementById('v-model').value.trim(),
      production_year: document.getElementById('v-production-year').value || null,
      color: document.getElementById('v-color').value.trim() || null,
      chassis_no: document.getElementById('v-chassis-no').value.trim() || null,
      engine_no: document.getElementById('v-engine-no').value.trim() || null
    };
    if (!isEdit) payload.customer_id = customerId;

    submitBtn.disabled = true;
    submitBtn.textContent = 'กำลังบันทึก...';

    try {
      if (isEdit) {
        await apiFetch(`/vehicles/${vehicleIdValue}`, { method: 'PUT', body: JSON.stringify(payload) });
        showToast('แก้ไขข้อมูลรถยนต์เรียบร้อยแล้ว', 'success');
        closeVehicleModal();
        loadCustomer();
      } else {
        const result = await apiFetch('/vehicles', { method: 'POST', body: JSON.stringify(payload) });
        showToast('เพิ่มรถยนต์เรียบร้อยแล้ว', 'success');
        closeVehicleModal();
        loadCustomer();
        openPostVehicleSaveModal(result.data.vehicle_id);
      }
    } catch (err) {
      errorEl.textContent = err.message || 'บันทึกไม่สำเร็จ กรุณาลองใหม่';
      errorEl.classList.remove('hidden');
    } finally {
      submitBtn.disabled = false;
      submitBtn.textContent = 'บันทึก';
    }
  });
}

/* ---------------------------------------------------------------------
   Post-Vehicle-Save Popup — "Add a policy now?" (NEW REQUIREMENT #3)
   After a NEW vehicle is saved (not on edit), offer to jump straight
   into the Add Policy form with the customer and vehicle already set.
   --------------------------------------------------------------------- */
function openPostVehicleSaveModal(newVehicleId) {
  const backdrop = document.getElementById('post-vehicle-save-modal-backdrop');
  const yesBtn = document.getElementById('post-vehicle-save-yes-btn');
  const noBtn = document.getElementById('post-vehicle-save-no-btn');

  const close = () => backdrop.classList.add('hidden');

  const onYes = () => {
    close();
    // The customer is already fixed by the page (customerId in scope);
    // passing the new vehicle id pre-selects it on the policy form.
    window.openPolicyModal(null, newVehicleId);
    cleanup();
  };
  const onNo = () => {
    close();
    cleanup();
  };
  function cleanup() {
    yesBtn.removeEventListener('click', onYes);
    noBtn.removeEventListener('click', onNo);
  }

  yesBtn.addEventListener('click', onYes);
  noBtn.addEventListener('click', onNo);
  backdrop.classList.remove('hidden');
}

/* ---------------------------------------------------------------------
   Add / Edit Policy Modal
   --------------------------------------------------------------------- */
function setupPolicyModal() {
  const backdrop = document.getElementById('policy-modal-backdrop');
  const closeBtn = document.getElementById('close-policy-modal-btn');
  const cancelBtn = document.getElementById('cancel-policy-btn');
  const form = document.getElementById('policy-form');
  const errorEl = document.getElementById('policy-form-error');
  const submitBtn = document.getElementById('submit-policy-btn');
  const title = document.getElementById('policy-modal-title');
  const toggleNewCompanyBtn = document.getElementById('toggle-new-company-btn');
  const newCompanyRow = document.getElementById('new-company-row');
  const saveNewCompanyBtn = document.getElementById('save-new-company-btn');

  closeBtn.addEventListener('click', closePolicyModal);
  cancelBtn.addEventListener('click', closePolicyModal);
  backdrop.addEventListener('click', (e) => { if (e.target === backdrop) closePolicyModal(); });

  toggleNewCompanyBtn.addEventListener('click', () => {
    newCompanyRow.classList.toggle('hidden');
  });

  saveNewCompanyBtn.addEventListener('click', async () => {
    const nameInput = document.getElementById('p-new-company-name');
    const name = nameInput.value.trim();
    if (!name) return;

    saveNewCompanyBtn.disabled = true;
    saveNewCompanyBtn.textContent = '...';
    try {
      const result = await apiFetch('/companies', { method: 'POST', body: JSON.stringify({ company_name: name }) });
      companiesList.push(result.data);
      populateCompanySelect();
      document.getElementById('p-company-id').value = result.data.company_id;
      nameInput.value = '';
      newCompanyRow.classList.add('hidden');
      showToast('เพิ่มบริษัทประกันใหม่เรียบร้อยแล้ว', 'success');
    } catch (err) {
      showToast(err.message || 'เพิ่มบริษัทไม่สำเร็จ', 'error');
    } finally {
      saveNewCompanyBtn.disabled = false;
      saveNewCompanyBtn.textContent = 'เพิ่ม';
    }
  });

  function openPolicyModalInner(policy, vehicleId) {
    form.reset();
    errorEl.classList.add('hidden');
    newCompanyRow.classList.add('hidden');
    document.getElementById('p-vehicle-id').value = vehicleId;

    if (policy) {
      title.textContent = 'แก้ไขกรมธรรม์';
      document.getElementById('p-policy-id').value = policy.policy_id;
      document.getElementById('p-company-id').value = policy.company_id || '';
      document.getElementById('p-policy-number').value = policy.policy_number || '';
      document.getElementById('p-insurance-type').value = policy.insurance_type || 'ชั้น 1';
      document.getElementById('p-premium').value = policy.premium || '';
      document.getElementById('p-start-date').value = (policy.start_date || '').slice(0, 10);
      document.getElementById('p-end-date').value = (policy.end_date || '').slice(0, 10);
      document.getElementById('p-renewal-status').value = policy.renewal_status || 'Pending';
      document.getElementById('p-status').value = policy.policy_status || 'Active';
      document.getElementById('p-notes').value = policy.notes || '';
    } else {
      title.textContent = 'เพิ่มกรมธรรม์';
      document.getElementById('p-policy-id').value = '';
      document.getElementById('p-renewal-status').value = 'Pending';
      document.getElementById('p-status').value = 'Active';
      document.getElementById('p-notes').value = '';
    }

    backdrop.classList.remove('hidden');
  }
  window.openPolicyModal = openPolicyModalInner;

  function closePolicyModal() {
    backdrop.classList.add('hidden');
    form.reset();
  }

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    errorEl.classList.add('hidden');

    const policyIdValue = document.getElementById('p-policy-id').value;
    const isEdit = !!policyIdValue;
    const startDate = document.getElementById('p-start-date').value;
    const endDate = document.getElementById('p-end-date').value;

    if (endDate < startDate) {
      errorEl.textContent = 'วันสิ้นสุดต้องไม่ก่อนวันเริ่มคุ้มครอง';
      errorEl.classList.remove('hidden');
      return;
    }

    const payload = {
      company_id: document.getElementById('p-company-id').value || null,
      policy_number: document.getElementById('p-policy-number').value.trim(),
      insurance_type: document.getElementById('p-insurance-type').value,
      premium: document.getElementById('p-premium').value || 0,
      start_date: startDate,
      end_date: endDate,
      renewal_status: document.getElementById('p-renewal-status').value,
      status: document.getElementById('p-status').value,
      notes: document.getElementById('p-notes').value.trim() || null
    };
    if (!isEdit) payload.vehicle_id = document.getElementById('p-vehicle-id').value;

    submitBtn.disabled = true;
    submitBtn.textContent = 'กำลังบันทึก...';

    try {
      if (isEdit) {
        await apiFetch(`/policies/${policyIdValue}`, { method: 'PUT', body: JSON.stringify(payload) });
        showToast('แก้ไขกรมธรรม์เรียบร้อยแล้ว', 'success');
      } else {
        await apiFetch('/policies', { method: 'POST', body: JSON.stringify(payload) });
        showToast('เพิ่มกรมธรรม์เรียบร้อยแล้ว', 'success');
      }
      closePolicyModal();
      loadCustomer();
    } catch (err) {
      errorEl.textContent = err.message || 'บันทึกไม่สำเร็จ กรุณาลองใหม่';
      errorEl.classList.remove('hidden');
    } finally {
      submitBtn.disabled = false;
      submitBtn.textContent = 'บันทึก';
    }
  });
}

/* ---------------------------------------------------------------------
   Compliance Modal: พรบ. / ภาษีรถยนต์ (NEW REQUIREMENT #7)
   One shared modal for both types - the type is fixed by which "+
   เพิ่ม" / "แก้ไข" button was clicked and stored in a hidden field.
   --------------------------------------------------------------------- */
function setupComplianceModal() {
  const backdrop = document.getElementById('compliance-modal-backdrop');
  const closeBtn = document.getElementById('close-compliance-modal-btn');
  const cancelBtn = document.getElementById('cancel-compliance-btn');
  const form = document.getElementById('compliance-form');
  const errorEl = document.getElementById('compliance-form-error');
  const submitBtn = document.getElementById('submit-compliance-btn');
  const title = document.getElementById('compliance-modal-title');
  const toggleNewCompanyBtn = document.getElementById('c-toggle-new-company-btn');
  const newCompanyRow = document.getElementById('c-new-company-row');
  const saveNewCompanyBtn = document.getElementById('c-save-new-company-btn');

  const typeLabels = { CompulsoryInsurance: 'พรบ.', VehicleTax: 'ภาษีรถยนต์' };

  closeBtn.addEventListener('click', closeComplianceModal);
  cancelBtn.addEventListener('click', closeComplianceModal);
  backdrop.addEventListener('click', (e) => { if (e.target === backdrop) closeComplianceModal(); });

  toggleNewCompanyBtn.addEventListener('click', () => {
    newCompanyRow.classList.toggle('hidden');
  });

  saveNewCompanyBtn.addEventListener('click', async () => {
    const nameInput = document.getElementById('c-new-company-name');
    const name = nameInput.value.trim();
    if (!name) return;

    saveNewCompanyBtn.disabled = true;
    saveNewCompanyBtn.textContent = '...';
    try {
      const result = await apiFetch('/companies', { method: 'POST', body: JSON.stringify({ company_name: name }) });
      companiesList.push(result.data);
      populateCompanySelect();
      document.getElementById('c-company-id').value = result.data.company_id;
      nameInput.value = '';
      newCompanyRow.classList.add('hidden');
      showToast('เพิ่มบริษัทใหม่เรียบร้อยแล้ว', 'success');
    } catch (err) {
      showToast(err.message || 'เพิ่มบริษัทไม่สำเร็จ', 'error');
    } finally {
      saveNewCompanyBtn.disabled = false;
      saveNewCompanyBtn.textContent = 'เพิ่ม';
    }
  });

  function openComplianceModalInner(vehicleId, type, record) {
    form.reset();
    errorEl.classList.add('hidden');
    newCompanyRow.classList.add('hidden');
    document.getElementById('c-vehicle-id').value = vehicleId;
    document.getElementById('c-compliance-type').value = type;
    document.getElementById('c-reminder').checked = true;

    if (record) {
      title.textContent = `แก้ไข${typeLabels[type] || ''}`;
      document.getElementById('c-compliance-id').value = record.compliance_id;
      document.getElementById('c-company-id').value = record.company_id || '';
      document.getElementById('c-start-date').value = (record.start_date || '').slice(0, 10);
      document.getElementById('c-expiry-date').value = (record.expiry_date || '').slice(0, 10);
      document.getElementById('c-price').value = record.price || '';
      document.getElementById('c-status').value = record.status || 'Active';
      document.getElementById('c-reminder').checked = record.reminder !== false;
      document.getElementById('c-notes').value = record.notes || '';
    } else {
      title.textContent = `เพิ่ม${typeLabels[type] || ''}`;
      document.getElementById('c-compliance-id').value = '';
      document.getElementById('c-status').value = 'Active';
      document.getElementById('c-notes').value = '';
    }

    backdrop.classList.remove('hidden');
  }
  window.openComplianceModal = openComplianceModalInner;

  function closeComplianceModal() {
    backdrop.classList.add('hidden');
    form.reset();
  }

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    errorEl.classList.add('hidden');

    const complianceIdValue = document.getElementById('c-compliance-id').value;
    const isEdit = !!complianceIdValue;
    const startDate = document.getElementById('c-start-date').value;
    const expiryDate = document.getElementById('c-expiry-date').value;

    if (startDate && expiryDate < startDate) {
      errorEl.textContent = 'วันหมดอายุต้องไม่ก่อนวันเริ่มคุ้มครอง';
      errorEl.classList.remove('hidden');
      return;
    }

    const payload = {
      company_id: document.getElementById('c-company-id').value || null,
      start_date: startDate || null,
      expiry_date: expiryDate,
      price: document.getElementById('c-price').value || 0,
      status: document.getElementById('c-status').value,
      reminder: document.getElementById('c-reminder').checked,
      notes: document.getElementById('c-notes').value.trim() || null
    };
    if (!isEdit) {
      payload.vehicle_id = document.getElementById('c-vehicle-id').value;
      payload.compliance_type = document.getElementById('c-compliance-type').value;
    }

    submitBtn.disabled = true;
    submitBtn.textContent = 'กำลังบันทึก...';

    try {
      if (isEdit) {
        await apiFetch(`/compliance/${complianceIdValue}`, { method: 'PUT', body: JSON.stringify(payload) });
        showToast('แก้ไขข้อมูลเรียบร้อยแล้ว', 'success');
      } else {
        await apiFetch('/compliance', { method: 'POST', body: JSON.stringify(payload) });
        showToast('เพิ่มข้อมูลเรียบร้อยแล้ว', 'success');
      }
      closeComplianceModal();
      loadCustomer();
    } catch (err) {
      errorEl.textContent = err.message || 'บันทึกไม่สำเร็จ กรุณาลองใหม่';
      errorEl.classList.remove('hidden');
    } finally {
      submitBtn.disabled = false;
      submitBtn.textContent = 'บันทึก';
    }
  });
}
