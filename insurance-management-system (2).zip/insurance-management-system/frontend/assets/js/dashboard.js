/**
 * assets/js/dashboard.js
 * -----------------------------------------------------------------------
 * Dashboard page logic: guards the route, populates the sidebar user
 * card, computes summary stats, and renders three sections:
 *   1. Stat cards + legacy "expiring within 30 days" motor widget
 *   2. Sales Dashboard (NEW REQUIREMENT #9) - monthly/yearly, summary
 *      cards, line/pie/bar charts, top companies/agents
 *   3. Reminder System (NEW REQUIREMENT #10) - Motor/พรบ./Vehicle Tax/
 *      Non-Motor items expiring within a selectable 7-90 day threshold
 * -----------------------------------------------------------------------
 */

const user = requireAuth();

let reminderItems = [];
let reminderThreshold = 30;
let reminderCategory = 'all';

let salesMode = 'monthly';
let salesScope = 'personal'; // 'personal' | 'team'
let salesData = null;        // last /dashboard/sales payload (both scopes)
let trendChart = null;
let typePieChart = null;
let companyBarChart = null;

const REMINDER_CATEGORY_LABELS = {
  Motor: 'Motor',
  CompulsoryInsurance: 'พรบ.',
  VehicleTax: 'ภาษีรถยนต์',
  NonMotor: 'Non-Motor'
};

const MONTH_NAMES_TH = [
  'มกราคม', 'กุมภาพันธ์', 'มีนาคม', 'เมษายน', 'พฤษภาคม', 'มิถุนายน',
  'กรกฎาคม', 'สิงหาคม', 'กันยายน', 'ตุลาคม', 'พฤศจิกายน', 'ธันวาคม'
];

document.addEventListener('DOMContentLoaded', () => {
  if (!user) return;

  document.getElementById('sidebar-user-name').textContent = `${user.first_name} ${user.last_name}`;
  document.getElementById('sidebar-user-role').textContent = user.role === 'Admin' ? 'ผู้ดูแลระบบ' : `ตัวแทน (${user.agent_code})`;
  if (user.role === 'Admin') {
    document.getElementById('nav-agents-link').classList.remove('hidden');
    document.getElementById('commission-rate-section').classList.remove('hidden');
    showAdminOnlyElements();
    loadCommissionRates();
  }

  document.getElementById('today-date').textContent = new Date().toLocaleDateString('th-TH', {
    weekday: 'long', year: 'numeric', month: 'long', day: 'numeric'
  });

  document.getElementById('logout-btn').addEventListener('click', logout);

  document.getElementById('quick-search-form').addEventListener('submit', (e) => {
    e.preventDefault();
    const q = document.getElementById('quick-search-input').value.trim();
    window.location.href = `customers.html?q=${encodeURIComponent(q)}`;
  });

  setupSalesDashboardControls();
  setupReminderControls();

  loadDashboard();
  loadSalesDashboard();
  loadReminders();
});

/* =======================================================================
   Section 1: Stat cards + legacy 30-day expiring motor widget
   ======================================================================= */
async function loadDashboard() {
  try {
    const [statsResult, expiringResult] = await Promise.all([
      apiFetch('/dashboard/stats'),
      apiFetch('/policies/expiring')
    ]);

    renderStats(statsResult.data);
    renderExpiringTable(expiringResult.data);
  } catch (err) {
    showToast(err.message || 'ไม่สามารถโหลดข้อมูลแดชบอร์ดได้', 'error');
    document.getElementById('expiring-tbody').innerHTML = '';
    document.getElementById('expiring-empty').classList.remove('hidden');
  }
}

function renderStats(stats) {
  document.getElementById('stat-customers').textContent = stats.total_customers.toLocaleString('th-TH');
  // Active Policies = Motor Active + Non-Motor Active (previously this
  // card only counted Motor policies - see dashboardController.getDashboardStats).
  document.getElementById('stat-active-policies').textContent = stats.active_policies.toLocaleString('th-TH');
  document.getElementById('stat-expiring').textContent = stats.expiring_30_days.toLocaleString('th-TH');
  document.getElementById('stat-pending-renewal').textContent = stats.pending_renewal.toLocaleString('th-TH');
}

function renderExpiringTable(rows) {
  const tbody = document.getElementById('expiring-tbody');
  const emptyState = document.getElementById('expiring-empty');
  const badge = document.getElementById('expiring-count-badge');

  badge.innerHTML = `<span class="pill-dot"></span>${rows.length} รายการ`;

  if (rows.length === 0) {
    tbody.innerHTML = '';
    emptyState.classList.remove('hidden');
    return;
  }

  emptyState.classList.add('hidden');

  tbody.innerHTML = rows.map((row) => {
    const customerName = `${row.customer_first_name || ''} ${row.customer_last_name || ''}`.trim();
    const agentName = ownerNameOf(row);

    return `
      <tr class="hover:bg-slate-50 transition-colors">
        <td class="px-5 sm:px-6 py-3.5">
          <p class="font-medium text-slate-800">${escapeHTML(customerName)}</p>
          <p class="text-xs text-slate-400">${escapeHTML(row.customer_phone || '-')}</p>
        </td>
        <td class="px-4 py-3.5 font-mono text-slate-700">${escapeHTML(row.license_plate || '-')}</td>
        <td class="px-4 py-3.5 text-slate-600">${escapeHTML(row.company_name || '-')}</td>
        <td class="px-4 py-3.5 font-mono text-slate-600">${escapeHTML(row.policy_number || '-')}</td>
        <td class="px-4 py-3.5 text-slate-600">${formatDate(row.end_date)}</td>
        ${user.role === 'Admin' ? `<td class="px-4 py-3.5 text-slate-600">${escapeHTML(agentName)}</td>` : ''}
        <td class="px-4 py-3.5">${renderPillHTML(row.days_remaining, row.policy_status)}</td>
        <td class="px-5 sm:px-6 py-3.5 text-right">
          <a href="customer-detail.html?id=${row.customer_id}" class="text-navy hover:text-orange-dark font-medium text-xs">ดูรายละเอียด →</a>
        </td>
      </tr>
    `;
  }).join('');
}

/* =======================================================================
   Section 2: Sales Dashboard (NEW REQUIREMENT #9)
   ======================================================================= */
function setupSalesDashboardControls() {
  const yearSelect = document.getElementById('sales-year-select');
  const monthSelect = document.getElementById('sales-month-select');
  const currentYear = new Date().getFullYear();

  for (let y = currentYear; y >= currentYear - 4; y--) {
    yearSelect.innerHTML += `<option value="${y}">${y + 543}</option>`; // พ.ศ. label
  }
  MONTH_NAMES_TH.forEach((name, i) => {
    monthSelect.innerHTML += `<option value="${i + 1}">${name}</option>`;
  });
  monthSelect.value = String(new Date().getMonth() + 1);

  document.getElementById('sales-mode-monthly').addEventListener('click', () => setSalesMode('monthly'));
  document.getElementById('sales-mode-yearly').addEventListener('click', () => setSalesMode('yearly'));
  document.getElementById('sales-scope-personal').addEventListener('click', () => setSalesScope('personal'));
  document.getElementById('sales-scope-team').addEventListener('click', () => setSalesScope('team'));
  updateSalesScopeUI();
  yearSelect.addEventListener('change', loadSalesDashboard);
  monthSelect.addEventListener('change', loadSalesDashboard);
}

function setSalesMode(mode) {
  salesMode = mode;
  const monthlyBtn = document.getElementById('sales-mode-monthly');
  const yearlyBtn = document.getElementById('sales-mode-yearly');
  const monthSelect = document.getElementById('sales-month-select');

  if (mode === 'monthly') {
    monthlyBtn.className = 'px-3 py-1.5 bg-navy text-white';
    yearlyBtn.className = 'px-3 py-1.5 bg-white text-slate-600 hover:bg-slate-50';
    monthSelect.classList.remove('hidden');
  } else {
    yearlyBtn.className = 'px-3 py-1.5 bg-navy text-white';
    monthlyBtn.className = 'px-3 py-1.5 bg-white text-slate-600 hover:bg-slate-50';
    monthSelect.classList.add('hidden');
  }
  loadSalesDashboard();
}

function setSalesScope(scope) {
  salesScope = scope;
  updateSalesScopeUI();
  if (salesData) renderSalesView(); // both views arrive in one response - no refetch
}

function updateSalesScopeUI() {
  const personalBtn = document.getElementById('sales-scope-personal');
  const teamBtn = document.getElementById('sales-scope-team');
  const active = 'px-3 py-1.5 bg-navy text-white';
  const idle = 'px-3 py-1.5 bg-white text-slate-600 hover:bg-slate-50';
  personalBtn.className = salesScope === 'personal' ? active : idle;
  teamBtn.className = salesScope === 'team' ? active : idle;

  const hint = document.getElementById('sales-scope-hint');
  if (salesScope === 'personal') {
    hint.textContent = 'เฉพาะงานที่คุณเป็นผู้รับผิดชอบ';
  } else {
    hint.textContent = user.role === 'Admin'
      ? 'ยอดรวมของทุกตัวแทน'
      : 'ยอดรวมของทีมทุกคน · ค่าคอมมิชชั่นแสดงเฉพาะของคุณ';
  }
  document.getElementById('top-agents-card').classList.toggle('hidden', salesScope !== 'team');
}

function renderSalesView() {
  const view = salesData[salesScope];
  renderSalesSummary(view.summary);
  renderTrendChart(view.monthlyTrend);
  renderTypePieChart(view.typeBreakdown);
  renderCompanyBarChart(view.byCompany);
  if (salesScope === 'team') renderTopAgentsTable(view.byAgent || []);
}

async function loadSalesDashboard() {
  const year = document.getElementById('sales-year-select').value;
  const month = document.getElementById('sales-month-select').value;

  const params = new URLSearchParams({ year });
  if (salesMode === 'monthly') params.set('month', month);

  try {
    const result = await apiFetch(`/dashboard/sales?${params.toString()}`);
    salesData = result.data;
    renderSalesView();
  } catch (err) {
    showToast(err.message || 'ไม่สามารถโหลดแดชบอร์ดยอดขายได้', 'error');
  }
}

function summaryCardHTML(agg) {
  return `
    <div><p class="text-slate-400">เบี้ยประกัน</p><p class="font-display font-semibold text-navy text-sm">฿${formatCurrency(agg.premium)}</p></div>
    <div><p class="text-slate-400">ค่าคอมมิชชั่น</p><p class="font-display font-semibold text-navy text-sm">${agg.commission === null ? '—' : '฿' + formatCurrency(agg.commission)}</p></div>
    <div><p class="text-slate-400">จำนวนกรมธรรม์</p><p class="font-display font-semibold text-navy text-sm">${agg.policy_count.toLocaleString('th-TH')}</p></div>
    <div><p class="text-slate-400">ต่ออายุแล้ว</p><p class="font-display font-semibold text-navy text-sm">${agg.renewal_count.toLocaleString('th-TH')}</p></div>
  `;
}

function renderSalesSummary(summary) {
  document.getElementById('summary-motor').innerHTML = summaryCardHTML(summary.motor);
  document.getElementById('summary-non-motor').innerHTML = summaryCardHTML(summary.nonMotor);
  document.getElementById('summary-total').innerHTML = summaryCardHTML(summary.total);
}

function renderTrendChart(monthlyTrend) {
  const ctx = document.getElementById('trend-chart');
  const labels = monthlyTrend.map((m) => MONTH_NAMES_TH[m.month - 1].slice(0, 3));
  const data = monthlyTrend.map((m) => m.premium);

  if (trendChart) trendChart.destroy();
  trendChart = new Chart(ctx, {
    type: 'line',
    data: {
      labels,
      datasets: [{
        label: 'เบี้ยประกัน (บาท)',
        data,
        borderColor: '#0B1953',
        backgroundColor: 'rgba(11,25,83,0.08)',
        tension: 0.3,
        fill: true,
        pointRadius: 3
      }]
    },
    options: {
      responsive: true,
      plugins: { legend: { display: false } },
      scales: { y: { beginAtZero: true } }
    }
  });
}

function renderTypePieChart(typeBreakdown) {
  const ctx = document.getElementById('type-pie-chart');
  if (typePieChart) typePieChart.destroy();
  typePieChart = new Chart(ctx, {
    type: 'pie',
    data: {
      labels: typeBreakdown.map((t) => t.type),
      datasets: [{
        data: typeBreakdown.map((t) => t.premium),
        backgroundColor: ['#0B1953', '#FF9F1C']
      }]
    },
    options: { responsive: true, plugins: { legend: { position: 'bottom' } } }
  });
}

function renderCompanyBarChart(byCompany) {
  const ctx = document.getElementById('company-bar-chart');
  if (companyBarChart) companyBarChart.destroy();
  companyBarChart = new Chart(ctx, {
    type: 'bar',
    data: {
      labels: byCompany.map((c) => c.label),
      datasets: [{
        label: 'เบี้ยประกัน (บาท)',
        data: byCompany.map((c) => c.premium),
        backgroundColor: '#FF9F1C'
      }]
    },
    options: {
      responsive: true,
      plugins: { legend: { display: false } },
      scales: { y: { beginAtZero: true } }
    }
  });

  document.getElementById('top-companies-table').innerHTML = byCompany.length === 0
    ? '<p class="text-slate-400">ไม่มีข้อมูล</p>'
    : byCompany.map((c) => `
        <div class="flex items-center justify-between">
          <span class="text-slate-600 truncate">${escapeHTML(c.label)}</span>
          <span class="font-mono text-slate-800">฿${formatCurrency(c.premium)} · ${c.policy_count} กรมธรรม์</span>
        </div>
      `).join('');
}

function renderTopAgentsTable(byAgent) {
  document.getElementById('top-agents-table').innerHTML = byAgent.length === 0
    ? '<p class="text-slate-400">ไม่มีข้อมูล</p>'
    : byAgent.map((a, i) => {
        const isMe = a.key === user.agent_id;
        const commissionText = a.commission === null ? '' : ` · คอม ฿${formatCurrency(a.commission)}`;
        return `
        <div class="flex items-center justify-between ${isMe ? 'font-semibold' : ''}">
          <span class="text-slate-600 truncate">${i + 1}. ${escapeHTML(a.label)}${isMe ? ' (คุณ)' : ''}</span>
          <span class="font-mono text-slate-800">฿${formatCurrency(a.premium)} · ${a.policy_count} กรมธรรม์${commissionText}</span>
        </div>`;
      }).join('');
}

async function loadCommissionRates() {
  try {
    const result = await apiFetch('/companies');
    renderCommissionRateTable(result.data);
  } catch (err) {
    showToast(err.message || 'ไม่สามารถโหลดรายชื่อบริษัทได้', 'error');
  }
}

function renderCommissionRateTable(companies) {
  const container = document.getElementById('commission-rate-table');
  if (companies.length === 0) {
    container.innerHTML = '<p class="text-slate-400 text-xs">ยังไม่มีบริษัทประกันในระบบ</p>';
    return;
  }

  container.innerHTML = companies.map((c) => `
    <div class="flex items-center gap-3">
      <span class="flex-1 text-slate-700 truncate">${escapeHTML(c.company_name)}</span>
      <div class="flex items-center gap-1.5">
        <input type="number" min="0" max="100" step="0.1" value="${(Number(c.commission_rate) * 100).toFixed(1)}"
          data-company-id="${c.company_id}" class="commission-rate-input input-field w-20 text-xs py-1.5">
        <span class="text-slate-400 text-xs">%</span>
        <button data-save-rate="${c.company_id}" class="text-navy hover:text-orange-dark text-xs font-medium">บันทึก</button>
      </div>
    </div>
  `).join('');

  container.querySelectorAll('[data-save-rate]').forEach((btn) => {
    btn.addEventListener('click', async () => {
      const companyId = btn.dataset.saveRate;
      const input = container.querySelector(`.commission-rate-input[data-company-id="${companyId}"]`);
      const percent = parseFloat(input.value);
      if (isNaN(percent) || percent < 0 || percent > 100) {
        showToast('กรุณาระบุอัตราค่าคอมมิชชั่นระหว่าง 0-100%', 'error');
        return;
      }
      try {
        await apiFetch(`/companies/${companyId}`, {
          method: 'PUT',
          body: JSON.stringify({ commission_rate: percent / 100 })
        });
        showToast('บันทึกอัตราค่าคอมมิชชั่นเรียบร้อยแล้ว', 'success');
        loadSalesDashboard();
      } catch (err) {
        showToast(err.message || 'บันทึกไม่สำเร็จ', 'error');
      }
    });
  });
}

/* =======================================================================
   Section 3: Reminder System (NEW REQUIREMENT #10)
   ======================================================================= */
function setupReminderControls() {
  document.querySelectorAll('.reminder-threshold-btn').forEach((btn) => {
    btn.addEventListener('click', () => {
      reminderThreshold = parseInt(btn.dataset.threshold, 10);
      document.querySelectorAll('.reminder-threshold-btn').forEach((b) => {
        b.className = 'reminder-threshold-btn px-3 py-1.5 bg-white text-slate-600 hover:bg-slate-50';
      });
      btn.className = 'reminder-threshold-btn px-3 py-1.5 bg-navy text-white';
      renderReminderTable();
    });
  });

  document.querySelectorAll('.reminder-category-btn').forEach((btn) => {
    btn.addEventListener('click', () => {
      reminderCategory = btn.dataset.category;
      document.querySelectorAll('.reminder-category-btn').forEach((b) => {
        b.className = 'reminder-category-btn rounded-full px-3 py-1 text-xs font-medium bg-slate-100 text-slate-600 hover:bg-slate-200';
      });
      btn.className = 'reminder-category-btn rounded-full px-3 py-1 text-xs font-medium bg-navy text-white';
      renderReminderTable();
    });
  });
}

async function loadReminders() {
  try {
    const result = await apiFetch('/dashboard/reminders');
    reminderItems = result.data;
    renderReminderTable();
  } catch (err) {
    showToast(err.message || 'ไม่สามารถโหลดข้อมูลแจ้งเตือนได้', 'error');
  }
}

function renderReminderTable() {
  const tbody = document.getElementById('reminder-tbody');
  const emptyEl = document.getElementById('reminder-empty');

  const filtered = reminderItems.filter((item) => {
    if (item.days_remaining > reminderThreshold) return false;
    if (reminderCategory !== 'all' && item.category !== reminderCategory) return false;
    return true;
  });

  if (filtered.length === 0) {
    tbody.innerHTML = '';
    emptyEl.classList.remove('hidden');
    return;
  }
  emptyEl.classList.add('hidden');

  tbody.innerHTML = filtered.map((item) => {
    const reference = item.license_plate || item.reference || '-';
    const rowContent = `
      <td class="px-5 sm:px-6 py-3.5">
        <p class="font-medium text-slate-800">${escapeHTML(item.customer_name || '-')}</p>
        <p class="text-xs text-slate-400">${escapeHTML(item.customer_phone || '-')}</p>
      </td>
      <td class="px-4 py-3.5 text-slate-600">${escapeHTML(REMINDER_CATEGORY_LABELS[item.category] || item.category)}</td>
      <td class="px-4 py-3.5 font-mono text-slate-700">${escapeHTML(reference)}</td>
      <td class="px-4 py-3.5 text-slate-600">${escapeHTML(item.company_name || '-')}</td>
      <td class="px-4 py-3.5 text-slate-600">${formatDate(item.expiry_date)}</td>
      ${user.role === 'Admin' ? `<td class="px-4 py-3.5 text-slate-600">${escapeHTML(item.agent_name || '-')}</td>` : ''}
      <td class="px-5 sm:px-6 py-3.5">${renderPillHTML(item.days_remaining, 'Active')}</td>
    `;
    return item.customer_id
      ? `<tr class="hover:bg-slate-50 transition-colors cursor-pointer" onclick="window.location.href='customer-detail.html?id=${item.customer_id}'">${rowContent}</tr>`
      : `<tr class="hover:bg-slate-50 transition-colors">${rowContent}</tr>`;
  }).join('');
}
